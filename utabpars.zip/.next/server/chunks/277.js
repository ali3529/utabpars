"use strict";
exports.id = 277;
exports.ids = [277];
exports.modules = {

/***/ 73:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgWhyUtabBack = function SvgWhyUtabBack(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 1208.967 618.252"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 1272",
    d: "m31.126 531.39 1099.8 86.862c17.19 0 36.554-21.1 36.554-47.611l41.485-474.645c0-26.508-13.935-48-31.126-48L64.091 0c-17.19 0-31.126 21.489-31.126 48L0 483.392c0 26.509 13.934 47.998 31.126 47.998Z",
    fill: "red"
  })));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgWhyUtabBack);

/***/ }),

/***/ 104:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _defs, _g;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgWhyUtabVector = function SvgWhyUtabVector(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: 369.964,
    height: 486.497
  }, props), _defs || (_defs = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("defs", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "why_utab_vector_svg__a",
    x1: 0.5,
    x2: 0.5,
    y2: 1,
    gradientUnits: "objectBoundingBox"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 0,
    stopColor: "#ffdcdc"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 1,
    stopColor: "#fff",
    stopOpacity: 0
  })))), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Layer 2"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Layer 1"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "At the office-amico (2)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("ellipse", {
    "data-name": "freepik--floor--inject-3",
    cx: 184.982,
    cy: 121.308,
    rx: 184.982,
    ry: 121.308,
    fill: "#f5f5f5",
    transform: "translate(0 243.881)"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    transform: "translate(19.168 293.523)",
    fill: "#ebebeb"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "m178.448 188.439 84.233-48.722-134.072-77.395-84.233 48.715Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "freepik--shadow--inject-3",
    d: "m17.9 49.102 47.165-27.229c.517-.3.517-.76 0-1.079l-3.388-1.953a2.074 2.074 0 0 0-1.869 0L40.661 29.896a2.059 2.059 0 0 1-1.861 0L3.89 9.74a2.059 2.059 0 0 0-1.861 0l-1.641.95c-.517.3-.517.76 0 1.079L35.336 31.94a.57.57 0 0 1 0 1.079L12.65 46.071a.57.57 0 0 0 0 1.079l3.388 1.952a2.013 2.013 0 0 0 1.861 0Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("ellipse", {
    "data-name": "freepik--shadow--inject-3",
    cx: 29.189,
    cy: 18.302,
    rx: 29.189,
    ry: 18.302,
    transform: "translate(214.08 143.105)"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("ellipse", {
    "data-name": "freepik--shadow--inject-3",
    cx: 35.548,
    cy: 22.291,
    rx: 35.548,
    ry: 22.291,
    transform: "translate(24.365 120.662)"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("ellipse", {
    "data-name": "freepik--shadow--inject-3",
    cx: 31.894,
    cy: 19.996,
    rx: 31.894,
    ry: 19.996,
    transform: "translate(76.825)"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2525",
    d: "M69.95 298.142v-.638l-25.125 14.595.539.319Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2526",
    d: "M31.003 261.994a.152.152 0 0 1 .076.167l-9.376 41.619-.243 1.155a.684.684 0 0 1-.372-.076l-.631-.365a.16.16 0 0 1-.068-.167l9.626-42.728a.152.152 0 0 1 .22-.1Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2527",
    d: "m32.183 261.394-9.672 42.933a.273.273 0 0 1-.122.167l-.631.365a.63.63 0 0 1-.327.076l.274-1.178 9.4-41.763Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2528",
    d: "M44.255 335.932v1.276a.76.76 0 0 1-.349-.076l-.585-.334a.251.251 0 0 1-.137-.205v-70.656l1.071.615Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2529",
    d: "M45.364 265.907v70.656a.258.258 0 0 1-.144.19l-.585.334a.661.661 0 0 1-.38.122v-70.652Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2530",
    d: "M74.728 319.544a.714.714 0 0 1-.334-.1l-.6-.342a.3.3 0 0 1-.144-.213l-11.465-60.215 1.079.623 11.237 59.039Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2531",
    d: "M75.808 318.921a.251.251 0 0 1-.144.205l-.555.319a.691.691 0 0 1-.357.084l-.228-1.208-11.275-59.024 1.086-.623 11.449 60.194Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2532",
    d: "m44.992 313.869 26.036-15.1v-1.25l-26.036 15.1Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2533",
    d: "M22.481 283.089v.934a1.6 1.6 0 0 0 .707 1.238l7.483 4.315a1.58 1.58 0 0 0 1.428 0l47.864-27.586a1.6 1.6 0 0 0 .707-1.238v-.927a1.58 1.58 0 0 0-.707-1.231l-7.483-4.323a1.58 1.58 0 0 0-1.428 0l-47.864 27.583a1.58 1.58 0 0 0-.707 1.238Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2534",
    d: "m23.188 282.686 7.483 4.323a1.58 1.58 0 0 0 1.428 0l47.864-27.579a.433.433 0 0 0 0-.821l-7.483-4.323a1.58 1.58 0 0 0-1.428 0l-47.864 27.575a.433.433 0 0 0 0 .821Z",
    fill: "#fff",
    opacity: 0.4
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2535",
    d: "M31.385 287.172v2.576a1.413 1.413 0 0 1-.707-.175l-7.483-4.315a1.588 1.588 0 0 1-.714-1.238v-.927a1.6 1.6 0 0 1 .57-1.132c-.251.228-.2.524.144.722l7.483 4.323a1.52 1.52 0 0 0 .707.166Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2536",
    d: "m27.974 285.439-2.082-1.2a2.826 2.826 0 0 1-1.269-2.051l-4.292-74.409a2.416 2.416 0 0 1 1.109-2.055l46.891-27.028a2.674 2.674 0 0 1 2.378 0l2.082 1.246a2.826 2.826 0 0 1 1.269 2.051l4.293 74.409a2.439 2.439 0 0 1-1.109 2.051l-46.9 26.986a2.606 2.606 0 0 1-2.37 0Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2537",
    d: "M74.03 181.75a.76.76 0 0 0-1.238-.479l-46.9 27.024a2.279 2.279 0 0 0-.821.9l-4.451-2.572a2.279 2.279 0 0 1 .843-.9l46.876-27.019a2.614 2.614 0 0 1 2.363 0l2.1 1.238a2.864 2.864 0 0 1 1.228 1.808Z",
    fill: "#fafafa"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2538",
    d: "m24.783 210.331 4.277 74.455a.76.76 0 0 0 1.269.676l46.9-27.024a2.439 2.439 0 0 0 1.109-2.051l-4.293-74.408a.76.76 0 0 0-1.269-.684l-46.884 27a2.439 2.439 0 0 0-1.109 2.036Z",
    fill: "#f0f0f0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2539",
    d: "M60.62 188.877v3.981a1.079 1.079 0 0 1-.5.859l-14.55 8.353a1.147 1.147 0 0 1-1 0l-1.231-.714a1.117 1.117 0 0 1-.5-.866v-1.965l-4.452-2.568-2.223 1.277v-4.559a1.079 1.079 0 0 1 .494-.866l14.549-8.357a1.094 1.094 0 0 1 1 0l7.907 4.559a1.079 1.079 0 0 1 .506.866Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2540",
    d: "M60.62 188.876v3.981a1.1 1.1 0 0 1-.5.859l-14.55 8.357a1.033 1.033 0 0 1-.494.114v-5.113a1.033 1.033 0 0 0 .494-.122l14.549-8.357c.243-.137.274-.357.091-.509a1.1 1.1 0 0 1 .41.79Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2541",
    d: "m36.658 192.379 7.909 4.558a1.094 1.094 0 0 0 1 0l14.544-8.357c.281-.152.281-.41 0-.57l-7.909-4.558a1.094 1.094 0 0 0-1 0l-14.544 8.357c-.273.161-.273.418 0 .57Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2542",
    d: "m36.954 253.637 2.743-1.618a.517.517 0 0 1 .836.448l.843 14.481a1.6 1.6 0 0 1-.722 1.345l-2.75 1.588a.517.517 0 0 1-.836-.448l-.843-14.481a1.58 1.58 0 0 1 .729-1.315Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2543",
    d: "m38.064 272.631 2.75-1.588c.433-.251.8-.144.821.228a1.443 1.443 0 0 1-.76 1.132l-2.7 1.557c-.433.251-.8.144-.821-.228a1.443 1.443 0 0 1 .707-1.1Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2544",
    d: "m46.755 255.058 2.75-1.588a.509.509 0 0 1 .828.448l.441 7.6a1.6 1.6 0 0 1-.76 1.345l-2.72 1.588a.517.517 0 0 1-.836-.448l-.441-7.6a1.6 1.6 0 0 1 .737-1.345Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2545",
    d: "m46.755 255.058 2.75-1.588a.509.509 0 0 1 .828.448l.441 7.6a1.6 1.6 0 0 1-.76 1.345l-2.72 1.588a.517.517 0 0 1-.836-.448l-.441-7.6a1.6 1.6 0 0 1 .737-1.345Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2546",
    d: "m47.454 267.168 2.75-1.588c.433-.251.76-.144.821.228a1.443 1.443 0 0 1-.76 1.132l-2.75 1.588c-.433.251-.76.144-.821-.228a1.444 1.444 0 0 1 .76-1.132Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2547",
    d: "m55.537 238.579 2.75-1.588a.509.509 0 0 1 .828.448l1.094 18.644a1.626 1.626 0 0 1-.76 1.352l-2.75 1.588a.509.509 0 0 1-.828-.448l-1.063-18.614a1.6 1.6 0 0 1 .729-1.383Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2548",
    d: "m55.537 238.579 2.75-1.588a.509.509 0 0 1 .828.448l1.094 18.644a1.626 1.626 0 0 1-.76 1.352l-2.75 1.588a.509.509 0 0 1-.828-.448l-1.063-18.614a1.6 1.6 0 0 1 .729-1.383Z",
    opacity: 0.2
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2549",
    d: "m56.845 261.736 2.75-1.588c.433-.251.76-.144.821.228a1.443 1.443 0 0 1-.76 1.132l-2.75 1.588c-.433.251-.8.144-.821-.228a1.443 1.443 0 0 1 .76-1.132Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2550",
    d: "m65.407 241.383 2.75-1.588a.509.509 0 0 1 .828.448l.577 10.408a1.626 1.626 0 0 1-.76 1.345l-2.75 1.588a.509.509 0 0 1-.828-.448l-.577-10.408a1.618 1.618 0 0 1 .76-1.345Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2551",
    d: "m65.407 241.383 2.75-1.588a.509.509 0 0 1 .828.448l.577 10.408a1.626 1.626 0 0 1-.76 1.345l-2.75 1.588a.509.509 0 0 1-.828-.448l-.577-10.408a1.618 1.618 0 0 1 .76-1.345Z",
    opacity: 0.3
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2552",
    d: "m66.234 256.304 2.75-1.588c.433-.251.76-.144.821.228a1.444 1.444 0 0 1-.76 1.132l-2.758 1.588c-.433.251-.8.144-.821-.228a1.444 1.444 0 0 1 .767-1.132Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2553",
    d: "M52.992 217.329c.387 6.465-3.8 14.435-9.269 17.656s-10.158.6-10.5-5.888c-.311-6.032 3.259-13.311 8.152-16.9v.479l.3.167c-4.642 3.282-7.924 10.158-7.765 15.841.182 6.283 4.558 8.714 9.755 5.463 4.984-3.13 8.919-10.363 8.6-16.388a.593.593 0 0 1 .152-.441c.196-.149.515-.232.575.011Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2554",
    d: "M53.98 216.804c-.372-7.073-5.5-9.945-11.442-6.412a20.612 20.612 0 0 0-6.906 7.369l1.74 1.254a15.886 15.886 0 0 1 5.364-5.645c4.558-2.72 8.524-.5 8.805 4.938s-3.236 12.057-7.81 14.815-8.524.509-8.813-4.938l-2.469 1.474c.365 7.073 5.5 9.945 11.434 6.412s10.469-12.201 10.097-19.267Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2555",
    d: "M42.827 215.764a13.452 13.452 0 0 0-5.873 11.183c.205 4.118 3.2 5.782 6.655 3.723a13.452 13.452 0 0 0 5.873-11.183c-.205-4.118-3.198-5.793-6.655-3.723Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 197",
    opacity: 0.3
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2556",
    d: "M42.827 215.764a13.452 13.452 0 0 0-5.873 11.183c.205 4.118 3.2 5.782 6.655 3.723a13.452 13.452 0 0 0 5.873-11.183c-.205-4.118-3.198-5.793-6.655-3.723Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2557",
    d: "m67.305 196.459-10.712 6.374a2.044 2.044 0 0 0-.942 1.664c0 .577.509.76 1.071.448l10.712-6.382a2.036 2.036 0 0 0 .957-1.656c-.04-.585-.523-.783-1.086-.448Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2558",
    d: "m67.594 201.913-10.712 6.374a2.059 2.059 0 0 0-.965 1.664c0 .585.517.76 1.079.448l10.7-6.374a2.051 2.051 0 0 0 .965-1.664c-.026-.577-.505-.782-1.067-.448Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2559",
    d: "m67.876 207.376-10.7 6.374a2.051 2.051 0 0 0-.965 1.664c0 .577.509.76 1.071.448l10.712-6.382a2.044 2.044 0 0 0 .965-1.656c-.035-.585-.521-.783-1.083-.448Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2560",
    d: "m68.165 212.831-10.712 6.374a2.044 2.044 0 0 0-.957 1.664c0 .585.509.76 1.071.448l10.712-6.374a2.044 2.044 0 0 0 .957-1.664c-.031-.587-.509-.787-1.071-.448Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2561",
    d: "m68.453 218.293-10.712 6.376a2.044 2.044 0 0 0-.965 1.656c0 .585.517.76 1.079.448l10.712-6.374a2.044 2.044 0 0 0 .965-1.656c-.036-.586-.517-.814-1.079-.45Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--board--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--board--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2562",
    d: "m221.571 169.814-.669.38v92.2a7.1 7.1 0 0 0 2.955 5.66l90.865 52.44a1.945 1.945 0 0 0 1.854.2c.144-.068.653-.372.76-.441a2.6 2.6 0 0 0 1.01-2.378v-92.197Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2563",
    d: "m314.722 320.494-90.865-52.422a7.1 7.1 0 0 1-2.955-5.66v-92.218l96.768 55.871v92.2c0 2.175-1.329 3.178-2.948 2.229Z",
    fill: "#fff",
    opacity: 0.8
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    opacity: 0.15
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 198",
    opacity: 0.15
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2564",
    d: "m288.671 282.818-6.617-3.814v-10.188l6.617 3.822Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 199",
    opacity: 0.15
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2565",
    d: "m298.275 288.372-6.61-3.822v-10.188l6.61 3.822Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 200",
    opacity: 0.15
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2566",
    d: "m307.885 293.918-6.617-3.822v-10.188l6.617 3.822Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 201",
    opacity: 0.15
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2567",
    d: "m288.671 296.828-6.617-3.82v-10.19l6.617 3.821Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2568",
    d: "m299.733 301.675-7.833-2.781-.82-9.474 7.833 2.781Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2569",
    d: "m308.607 308.186-6.617-3.822v-10.188l6.617 3.821Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2570",
    d: "m281.15 278.663 4.558 2.553c.509.289.843-.532.843-1.033.517.327 1.557.532 1.611-.122l.425-5.774-6.86-3.936Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2571",
    d: "m281.727 270.313 6.876 3.973v-1.276l-6.876-3.966Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2572",
    d: "m287.965 280.41-1.884.836.585-1.542Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--note--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2573",
    d: "m290.761 284.209 6.845 3.9.608-8.274-6.876-3.973Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2574",
    d: "m291.338 275.859 6.876 3.973v-1.269l-6.876-3.973Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2575",
    d: "m291.338 275.859 6.876 3.973v-1.269l-6.876-3.973Z",
    opacity: 0.1
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--note--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2576",
    d: "m300.941 304.098 6.838 3.9.615-8.274-6.876-3.966Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2577",
    d: "m301.518 295.756 6.88 3.964v-1.269l-6.876-3.973Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2578",
    d: "m301.518 295.756 6.88 3.964v-1.269l-6.876-3.973Z",
    opacity: 0.1
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--note--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2579",
    d: "m291.771 299.343 7.4 2.674-.8-8.251-7.453-2.75Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2580",
    d: "m290.92 291.012 7.453 2.75-.22-1.261-7.453-2.743Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2581",
    d: "m290.92 291.012 7.453 2.75-.22-1.261-7.453-2.743Z",
    opacity: 0.1
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--note--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2582",
    d: "m281.15 292.574 6.838 3.9.615-8.274-6.876-3.973Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2583",
    d: "m281.727 284.231 6.876 3.966v-1.269l-6.876-3.973Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2584",
    d: "m281.727 284.231 6.876 3.966v-1.269l-6.876-3.973Z",
    fill: "#37474f"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--note--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2585",
    d: "m300.371 289.752 4.558 2.56c.509.281.843-.539.851-1.041.509.327 1.557.532 1.611-.114l.425-5.782-6.883-3.966Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2586",
    d: "m300.941 281.412 6.883 3.966v-1.269l-6.883-3.973Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2587",
    d: "m307.178 291.502-1.884.836.593-1.535Z",
    fill: "#37474f"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2588",
    d: "m300.691 276.505-41.626-24.03v-47.393l41.626 24.031Z",
    opacity: 0.15
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2589",
    d: "m298.989 275.974.19-.114a1.216 1.216 0 0 0 .555-.957v-44.575a1.231 1.231 0 0 0-.555-.957l-40.13-23.218a1.238 1.238 0 0 0-1.109 0l-.19.114a1.231 1.231 0 0 0-.555.957v44.571a1.216 1.216 0 0 0 .555.957l40.13 23.218a1.238 1.238 0 0 0 1.109 0Z",
    fill: "#f0f0f0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2590",
    d: "M299.726 230.329v44.582a1.238 1.238 0 0 1-.547.965l-.19.106a1.269 1.269 0 0 1-.988.061c.251.068.433-.076.433-.38v-44.579a1.087 1.087 0 0 0-.167-.547l1.307-.76a1.239 1.239 0 0 1 .152.555Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2591",
    d: "m257.743 206.905 40.13 23.218a1.216 1.216 0 0 1 .555.957v44.589c0 .349-.251.494-.555.319l-40.13-23.233a1.215 1.215 0 0 1-.555-.957v-44.573c.008-.35.258-.494.555-.32Z",
    fill: "#fafafa"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2592",
    d: "M259.718 249.078c1.352.76 3.426.942 4.984-2.872s2.963-6.891 4.87-5.607c1.337.9 1.155 2.12 2.355 2.811 1.877 1.079 3.343-3.578 4-7.932.942-6.169 1.846-7.787 3.533-6.838 2.5 1.383 2.279 5.493 2.279 9.269 0 3.381 0 5.143 1.831 5.9 1.216.494 2.4-2.439 2.879-4.7s1.519-3.35 2.629-2.727 2.279 2.12 2.279 8.106c.053 5.318.137 12.916.228 14.557a8.251 8.251 0 0 0 4.4 7.058v6.01l-36.267-20.953Z",
    fill: "#ffc0c0",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2593",
    d: "M295.843 266.431a8.608 8.608 0 0 1-4.558-7.354c-.1-1.747-.182-9.877-.228-14.579-.061-5.842-1.17-7.233-2.127-7.787a.76.76 0 0 0-.714-.061 3.66 3.66 0 0 0-1.368 2.545c-.4 1.884-1.276 4.3-2.408 4.9a1.124 1.124 0 0 1-.972.061c-2.066-.851-2.066-2.765-2.066-6.237v-.836c0-3.4 0-6.929-2.1-8.106-.494-.281-.76-.205-.9-.137-1.018.5-1.649 3.859-2.082 6.731-.258 1.694-1.254 7.309-3.221 8.258a1.4 1.4 0 0 1-1.337-.068 3.275 3.275 0 0 1-1.254-1.459 3.267 3.267 0 0 0-1.117-1.36 1.033 1.033 0 0 0-.927-.2c-1.246.38-2.492 3.411-3.4 5.63-.76 1.869-1.732 3.039-2.887 3.4a3.115 3.115 0 0 1-2.621-.349l.365-.638a2.446 2.446 0 0 0 2.021.289c.942-.319 1.763-1.322 2.439-2.986 1.292-3.153 2.4-5.607 3.867-6.078a1.778 1.778 0 0 1 1.519.289 3.988 3.988 0 0 1 1.352 1.626 2.614 2.614 0 0 0 .98 1.17.638.638 0 0 0 .646.038c1.056-.509 2.188-3.6 2.811-7.7.714-4.71 1.413-6.747 2.492-7.278a1.626 1.626 0 0 1 1.58.152c2.507 1.383 2.492 5.136 2.477 8.76v.828c0 3.358 0 4.893 1.611 5.554a.4.4 0 0 0 .349 0c.7-.372 1.573-2.279 2.029-4.406.349-1.611.98-2.7 1.793-3.039a1.459 1.459 0 0 1 1.375.091c1.2.691 2.439 2.234 2.5 8.418.046 4.688.129 12.817.228 14.549a7.81 7.81 0 0 0 4.209 6.754Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 202",
    opacity: 0.3
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2594",
    d: "M295.843 266.431a8.608 8.608 0 0 1-4.558-7.354c-.1-1.747-.182-9.877-.228-14.579-.061-5.842-1.17-7.233-2.127-7.787a.76.76 0 0 0-.714-.061 3.66 3.66 0 0 0-1.368 2.545c-.4 1.884-1.276 4.3-2.408 4.9a1.124 1.124 0 0 1-.972.061c-2.066-.851-2.066-2.765-2.066-6.237v-.836c0-3.4 0-6.929-2.1-8.106-.494-.281-.76-.205-.9-.137-1.018.5-1.649 3.859-2.082 6.731-.258 1.694-1.254 7.309-3.221 8.258a1.4 1.4 0 0 1-1.337-.068 3.275 3.275 0 0 1-1.254-1.459 3.267 3.267 0 0 0-1.117-1.36 1.033 1.033 0 0 0-.927-.2c-1.246.38-2.492 3.411-3.4 5.63-.76 1.869-1.732 3.039-2.887 3.4a3.115 3.115 0 0 1-2.621-.349l.365-.638a2.446 2.446 0 0 0 2.021.289c.942-.319 1.763-1.322 2.439-2.986 1.292-3.153 2.4-5.607 3.867-6.078a1.778 1.778 0 0 1 1.519.289 3.988 3.988 0 0 1 1.352 1.626 2.614 2.614 0 0 0 .98 1.17.638.638 0 0 0 .646.038c1.056-.509 2.188-3.6 2.811-7.7.714-4.71 1.413-6.747 2.492-7.278a1.626 1.626 0 0 1 1.58.152c2.507 1.383 2.492 5.136 2.477 8.76v.828c0 3.358 0 4.893 1.611 5.554a.4.4 0 0 0 .349 0c.7-.372 1.573-2.279 2.029-4.406.349-1.611.98-2.7 1.793-3.039a1.459 1.459 0 0 1 1.375.091c1.2.691 2.439 2.234 2.5 8.418.046 4.688.129 12.817.228 14.549a7.81 7.81 0 0 0 4.209 6.754Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2595",
    d: "M259.718 240.63c0 1.3 2.56 8.129 8.319 8.479s7.886-6.078 10.682-4.558 2.279 6.139 4.862 7.711 5.394-7.225 8.532-5.827 2.051 11.016 3.913 12.771v12.916l-36.308-20.962Z",
    fill: "#ffc0c0",
    opacity: 0.15
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2596",
    d: "M295.775 259.502c-.9-.843-1.147-3.039-1.444-5.523-.357-3.039-.76-6.465-2.363-7.18-1.352-.6-2.765 1.231-4.141 3.039s-2.887 3.738-4.437 2.8c-1.383-.828-1.937-2.416-2.477-3.951s-1.071-3.039-2.378-3.753c-1.018-.555-1.93.16-3.449 1.474-1.709 1.474-3.8 3.312-7.073 3.107-5.82-.357-8.646-7.195-8.661-8.843h.76c0 1.086 2.355 7.772 7.97 8.114 2.94.175 4.938-1.519 6.541-2.925 1.52-1.284 2.773-2.393 4.293-1.565s2.142 2.53 2.712 4.156c.524 1.474 1.01 2.872 2.165 3.563.988.593 2.2-.965 3.48-2.621 1.474-1.9 3.145-4.057 5.014-3.229 1.991.889 2.4 4.384 2.8 7.765.258 2.173.517 4.422 1.216 5.083Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2597",
    d: "M262.043 213.242a2.1 2.1 0 0 1 .95 1.641c0 .608-.425.851-.95.547a2.089 2.089 0 0 1-.942-1.641c0-.6.441-.843.942-.547Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2598",
    d: "M263.714 215.096a1.52 1.52 0 0 0 .7 1.162l6.465 3.73c.387.22.7.061.7-.357a1.519 1.519 0 0 0-.7-1.155l-6.465-3.73c-.381-.228-.692-.068-.7.35Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2599",
    d: "M262.043 217.785a2.082 2.082 0 0 1 .95 1.641c0 .6-.425.843-.95.547a2.112 2.112 0 0 1-.942-1.641c0-.608.441-.851.942-.547Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2600",
    d: "M262.043 217.785a2.082 2.082 0 0 1 .95 1.641c0 .6-.425.843-.95.547a2.112 2.112 0 0 1-.942-1.641c0-.608.441-.851.942-.547Z",
    opacity: 0.3
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2601",
    d: "M263.714 219.634a1.52 1.52 0 0 0 .7 1.162l6.465 3.73c.387.22.7.061.7-.357a1.519 1.519 0 0 0-.7-1.155l-6.465-3.73c-.381-.231-.692-.071-.7.35Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2602",
    d: "m275.627 288.076-13.569-7.836v-22.82l13.569 7.833Z",
    opacity: 0.15
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2603",
    d: "m274.631 288.288-12.916-7.438a.76.76 0 0 1-.342-.593v-22.062c0-.22.152-.3.342-.2l12.916 7.445a.76.76 0 0 1 .342.585v22.033c0 .253-.152.337-.342.23Z",
    fill: "#fff"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2604",
    d: "m273.332 268.832-10.272-5.964a.76.76 0 0 1-.387-.532c0-.175.175-.213.387-.091l10.279 5.934a.76.76 0 0 1 .38.532c-.022.174-.174.212-.387.121Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2605",
    d: "m273.332 270.423-10.272-5.934a.76.76 0 0 1-.387-.532c0-.175.175-.213.387-.091l10.279 5.934a.76.76 0 0 1 .38.532c-.022.179-.174.217-.387.091Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2606",
    d: "m273.332 273.808-10.272-5.941a.76.76 0 0 1-.387-.532c0-.175.175-.213.387-.091l10.279 5.934a.759.759 0 0 1 .38.539c-.022.167-.174.212-.387.091Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2607",
    d: "m273.332 275.434-10.272-5.941a.76.76 0 0 1-.387-.532c0-.175.175-.213.387-.091l10.279 5.934a.76.76 0 0 1 .38.532c-.022.174-.174.219-.387.098Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2608",
    d: "m273.332 280.432-10.272-5.934a.76.76 0 0 1-.387-.539c0-.167.175-.213.387-.091l10.279 5.941a.76.76 0 0 1 .38.532c-.022.175-.174.213-.387.091Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2609",
    d: "m273.332 278.806-10.272-5.932a.76.76 0 0 1-.387-.539c0-.167.175-.213.387-.091l10.279 5.941a.76.76 0 0 1 .38.532c-.022.173-.174.211-.387.089Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2610",
    d: "M267.437 263.832h.129l.258-.152c.106-.061.235-.129.365-.213l.418-.258c.038 0-.038-.16-.084-.137l-.425.228-.372.205-.258.152a.06.06 0 0 0-.061.061.084.084 0 0 0 0 .061Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2611",
    d: "M267.171 264.022c.205.342.532.532.874.349a.4.4 0 0 0 .144-.334 1.155 1.155 0 0 0-.524-.9.38.38 0 0 0-.349-.046.631.631 0 0 0-.144.934Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 203",
    opacity: 0.15
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2612",
    d: "M267.171 264.022c.205.342.532.532.874.349a.4.4 0 0 0 .144-.334 1.155 1.155 0 0 0-.524-.9.38.38 0 0 0-.349-.046.631.631 0 0 0-.144.934Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2613",
    d: "m266.752 264.706-.387-.661a3.686 3.686 0 0 0 .821-.562.22.22 0 0 1 .258 0 .76.76 0 0 1 .342.585.228.228 0 0 1-.1.22h-.071a3.525 3.525 0 0 0-.866.418Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2614",
    d: "M266.039 264.173a.41.41 0 0 1 .4-.41.44.44 0 0 1 .144 0h.068a.9.9 0 0 1 .41.714.466.466 0 0 1 0 .106.418.418 0 0 1-.4.334.41.41 0 0 1-.41-.41.329.329 0 0 0 0-.038.4.4 0 0 1-.212-.296Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 204",
    opacity: 0.15
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2615",
    d: "M266.039 264.174a.41.41 0 0 1 .4-.41.44.44 0 0 1 .144 0h.068a.9.9 0 0 1 .41.714.466.466 0 0 1 0 .106.418.418 0 0 1-.4.334.41.41 0 0 1-.41-.41.329.329 0 0 0 0-.038.4.4 0 0 1-.212-.296Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2616",
    d: "M266.441 263.969a.253.253 0 0 0-.41.236.9.9 0 0 0 .41.714.254.254 0 0 0 .41-.236.9.9 0 0 0-.41-.714Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--sheet--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2617",
    d: "m315.589 259.077-13.569-7.841v-22.815l13.569 7.833Z",
    opacity: 0.15
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2618",
    d: "m314.601 259.289-12.916-7.438a.76.76 0 0 1-.342-.593v-22.032c0-.22.152-.3.342-.2l12.916 7.438a.76.76 0 0 1 .342.593v22.033c0 .222-.152.305-.342.199Z",
    fill: "#fff"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2619",
    d: "m313.295 239.803-10.279-5.918a.76.76 0 0 1-.38-.532c0-.175.167-.213.38-.091l10.279 5.941a.76.76 0 0 1 .38.532c0 .151-.167.227-.38.068Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2620",
    d: "m313.295 241.428-10.279-5.934a.76.76 0 0 1-.38-.532c0-.175.167-.213.38-.091l10.279 5.934a.76.76 0 0 1 .38.532c0 .144-.167.213-.38.091Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2621",
    d: "m313.295 244.809-10.279-5.941a.76.76 0 0 1-.38-.532c0-.175.167-.213.38-.091l10.279 5.934a.76.76 0 0 1 .38.532c0 .174-.167.216-.38.098Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2622",
    d: "m313.295 246.435-10.279-5.941a.76.76 0 0 1-.38-.532c0-.175.167-.213.38-.091l10.279 5.934a.76.76 0 0 1 .38.532c0 .176-.167.219-.38.098Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2623",
    d: "m313.295 251.431-10.279-5.934a.76.76 0 0 1-.38-.539c0-.167.167-.213.38-.091l10.279 5.941a.76.76 0 0 1 .38.532c0 .169-.167.215-.38.091Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2624",
    d: "m313.295 249.836-10.279-5.934a.76.76 0 0 1-.38-.539c0-.167.167-.213.38-.091l10.279 5.941a.76.76 0 0 1 .38.532c0 .147-.167.185-.38.091Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--pushpin--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2625",
    d: "M307.407 234.833h.137l.258-.152.365-.213.41-.258c.038 0-.038-.16-.084-.137l-.425.228-.372.205-.258.152a.06.06 0 0 0-.061.061.166.166 0 0 0 0 .061Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2626",
    d: "M307.126 235.026a.638.638 0 0 0 .866.349.38.38 0 0 0 .144-.334 1.155 1.155 0 0 0-.524-.9.372.372 0 0 0-.349-.046.631.631 0 0 0-.137.934Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 205",
    opacity: 0.15
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2627",
    d: "M307.126 235.026a.638.638 0 0 0 .866.349.38.38 0 0 0 .144-.334 1.155 1.155 0 0 0-.524-.9.372.372 0 0 0-.349-.046.631.631 0 0 0-.137.934Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2628",
    d: "m306.723 235.707-.387-.661a3.7 3.7 0 0 0 .813-.562.213.213 0 0 1 .258 0 .76.76 0 0 1 .334.585.228.228 0 0 1-.1.22h-.061a3.388 3.388 0 0 0-.859.418Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2629",
    d: "M306.002 235.175a.41.41 0 0 1 .41-.41.493.493 0 0 1 .144 0h.061a.9.9 0 0 1 .41.714.5.5 0 0 1 0 .106.404.404 0 1 1-.805-.076.4.4 0 0 1-.22-.334Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 206",
    opacity: 0.15
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2630",
    d: "M306.002 235.175a.41.41 0 0 1 .41-.41.493.493 0 0 1 .144 0h.061a.9.9 0 0 1 .41.714.5.5 0 0 1 0 .106.404.404 0 1 1-.805-.076.4.4 0 0 1-.22-.334Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2631",
    d: "M306.412 234.97a.258.258 0 0 0-.418.236.912.912 0 0 0 .418.714.254.254 0 0 0 .41-.236.9.9 0 0 0-.41-.714Z",
    fill: "#ffc0c0"
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2632",
    d: "m256.124 279.179-30.374-17.535v-54.177l30.374 17.535Z",
    opacity: 0.15
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2633",
    d: "m255.235 253.925-30.374-17.534v-28.354l30.374 17.535Z",
    fill: "#fafafa"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2634",
    d: "m254.118 250.135-28.133-16.236v-22.253l28.133 16.236Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2635",
    d: "m254.118 250.135-28.133-16.236v-22.253l28.133 16.236Z",
    fill: "#fff",
    opacity: 0.8
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2636",
    d: "m225.985 222.723 28.133 16.236v11.176l-28.133-16.236Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2637",
    d: "m254.111 238.959-16.448-9.5s-6.587-1.922-5.136.4 7.043 4.042 9.915 9.679c2.234 4.384 11.67 9.117 11.67 9.117Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2638",
    d: "m254.111 238.959-16.448-9.5s-6.587-1.922-5.136.4 7.043 4.042 9.915 9.679c2.234 4.384 11.67 9.117 11.67 9.117Z",
    fill: "#fff",
    opacity: 0.65
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2639",
    d: "M239.653 230.609s-6.359-12.262-8.19-14.063-2.667.509-3.145.3-2.332-5.2-2.332-5.2v11.07Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2640",
    d: "M239.653 230.609s-6.359-12.262-8.19-14.063-2.667.509-3.145.3-2.332-5.2-2.332-5.2v11.07Z",
    opacity: 0.3
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2641",
    d: "M246.597 234.643a4.855 4.855 0 0 0-1.861-2.188 9.1 9.1 0 0 1-3.723-4c-.532-1.573-2.029-5.318-3.5-5.888s-4.8 4.065-4.8 4.065Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2642",
    d: "M248.838 228.702c0-1.436.76-2.165 1.694-1.626a4.457 4.457 0 0 1 1.687 3.578c0 1.436-.76 2.165-1.687 1.626a4.483 4.483 0 0 1-1.694-3.578Z",
    fill: "#fff"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--calendar--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2643",
    d: "m254.369 254.487-30.473-17.6v26.144l30.473 17.6Z",
    fill: "#fafafa"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2644",
    d: "M255.235 253.986v26.14l-.866.509v-26.148Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2645",
    d: "m223.896 236.89.866-.5 30.473 17.6-.866.5Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 207",
    opacity: 0.5
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2646",
    d: "m223.896 236.89.866-.5 30.473 17.6-.866.5Z",
    fill: "#fff"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2647",
    d: "m255.235 253.986-.866.5v5.029l.866-.509Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 208",
    opacity: 0.5
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2648",
    d: "m255.235 253.986-.866.5v5.029l.866-.509Z",
    fill: "#455a64"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2649",
    d: "m254.369 259.516-30.473-17.6v-5.025l30.473 17.6Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2650",
    d: "M252.295 261.134c0 .281-.205.387-.463.236l-2.279-1.322a.98.98 0 0 1-.471-.76c0-.274.213-.38.471-.236l2.279 1.322a.988.988 0 0 1 .463.76Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2651",
    d: "M248.443 258.909c0 .281-.205.387-.463.236l-2.283-1.315a1.018 1.018 0 0 1-.463-.76c0-.273.213-.38.463-.236l2.279 1.322a.988.988 0 0 1 .463.752Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2652",
    d: "M244.591 256.675c0 .281-.213.387-.463.236l-2.279-1.314a1 1 0 0 1-.463-.76c0-.274.205-.38.463-.236l2.279 1.322a1 1 0 0 1 .463.752Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2653",
    d: "M240.736 254.453c0 .281-.213.387-.471.236l-2.279-1.314a1 1 0 0 1-.463-.76c0-.274.205-.38.463-.236l2.279 1.322a1.01 1.01 0 0 1 .471.752Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2654",
    d: "M236.88 252.231c0 .281-.205.387-.463.236l-2.279-1.314a1.018 1.018 0 0 1-.463-.76c0-.274.213-.38.463-.228l2.279 1.314a1 1 0 0 1 .463.752Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2655",
    d: "M233.028 250.012c0 .273-.205.38-.463.228l-2.279-1.314a1 1 0 0 1-.463-.76c0-.274.205-.38.463-.228l2.279 1.314a1 1 0 0 1 .463.76Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2656",
    d: "M229.176 247.786c0 .273-.213.38-.463.236l-2.279-1.322a.988.988 0 0 1-.463-.76c0-.281.205-.387.463-.236l2.279 1.314a1 1 0 0 1 .463.768Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2657",
    d: "m252.097 263.778-2.8-1.618v2.53l2.8 1.656Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2658",
    d: "m252.097 267.327-2.8-1.611v2.522l2.8 1.656Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2659",
    d: "m252.097 270.875-2.8-1.611v2.522l2.8 1.656Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2660",
    d: "m252.097 274.423-2.8-1.611v2.522l2.8 1.656Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2661",
    d: "m248.246 261.552-2.811-1.618v2.53l2.811 1.656Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2662",
    d: "m248.246 265.101-2.811-1.611v2.522l2.811 1.656Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2663",
    d: "m248.246 268.648-2.811-1.618v2.53l2.811 1.656Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2664",
    d: "m248.246 272.197-2.811-1.611v2.522l2.811 1.656Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2665",
    d: "m244.386 259.326-2.8-1.618v2.53l2.8 1.656Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2666",
    d: "m244.386 262.874-2.8-1.618v2.53l2.8 1.656Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2667",
    d: "m244.386 266.422-2.8-1.618v2.53l2.8 1.656Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2668",
    d: "m244.386 269.971-2.8-1.611v2.52l2.8 1.656Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2669",
    d: "m240.526 257.1-2.8-1.618v2.53l2.8 1.649Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2670",
    d: "m240.526 260.648-2.8-1.618v2.53l2.8 1.649Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2671",
    d: "m240.526 264.196-2.8-1.618v2.53l2.8 1.656Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2672",
    d: "m240.526 267.744-2.8-1.618v2.53l2.8 1.656Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2673",
    d: "m236.667 254.867-2.8-1.611v2.522l2.8 1.656Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2674",
    d: "m236.667 258.415-2.8-1.611v2.53l2.8 1.649Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2675",
    d: "m236.667 261.97-2.8-1.618v2.53l2.8 1.649Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2676",
    d: "m236.667 265.518-2.8-1.618v2.53l2.8 1.649Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2677",
    d: "m232.812 252.641-2.8-1.611v2.522l2.8 1.656Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2678",
    d: "m232.812 256.189-2.8-1.611v2.522l2.8 1.656Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2679",
    d: "m232.812 259.737-2.8-1.611v2.53l2.8 1.649Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2680",
    d: "m232.812 263.294-2.8-1.618v2.53l2.8 1.649Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2681",
    d: "m228.955 250.415-2.8-1.611v2.522l2.8 1.656Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2682",
    d: "m228.955 253.963-2.8-1.611v2.522l2.8 1.656Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2683",
    d: "m228.955 257.511-2.8-1.611v2.53l2.8 1.649Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2684",
    d: "m228.955 261.059-2.8-1.611v2.53l2.8 1.649Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2685",
    d: "m226.228 247.9-.22.463a.053.053 0 0 1-.076 0l-.486-.182c-.076 0-.106.076-.053.182l.357.661a.205.205 0 0 1 0 .129l-.084.6c0 .1.068.22.137.213l.441-.053a.1.1 0 0 1 .084.053l.441.555c.068.091.152.061.137-.053l-.084-.691a.1.1 0 0 1 0-.1l.349-.258c.061 0 0-.182-.053-.243l-.486-.38a.175.175 0 0 1-.068-.106l-.22-.714c.013-.091-.085-.152-.116-.076Z",
    fill: "#f28f8f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2686",
    d: "M237.101 263.508a1.216 1.216 0 0 1 .76-1.185c.631-.228 1.162.273 1.519.7.106.114-.084.167-.167.084-.4-.38-1.155-.76-1.588-.251s-.213 1.269 0 1.823a2.6 2.6 0 0 0 2.386 1.74c2.355-.182-.2-4.323-1.588-4.558-.114 0-.2-.2-.046-.22.707-.114 1.208.517 1.649.988a5.378 5.378 0 0 1 1.124 1.793c.471 1.246-.22 2.788-1.747 2.279a3.305 3.305 0 0 1-2.302-3.193Z",
    fill: "#f28f8f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2687",
    d: "M241.355 261.993a3.312 3.312 0 0 1 .425-.494.1.1 0 0 1 .16.1c-.03.1-.251.3-.349.479a.755.755 0 0 0-.061.084 2.841 2.841 0 0 1 .988-.327 3.472 3.472 0 0 1 2.021.182c.068 0 .038.084 0 .091a.661.661 0 0 1-.3-.053 3.8 3.8 0 0 0-1.056-.076 3.51 3.51 0 0 0-1.482.38.98.98 0 0 1 .942.236s0 .084 0 .091a5.864 5.864 0 0 1-.631-.046 2.567 2.567 0 0 0-.76.129.156.156 0 0 1-.167-.152 1.52 1.52 0 0 1 .27-.624Z",
    fill: "#f28f8f"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--pushpin--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2688",
    d: "M239.395 219.061h.129l.258-.152.365-.22.41-.251c.046 0 0-.167-.084-.144l-.425.228-.365.213-.266.144a.06.06 0 0 0-.061.061v.061Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2689",
    d: "M239.129 219.25a.638.638 0 0 0 .874.349.38.38 0 0 0 .144-.334 1.17 1.17 0 0 0-.517-.9.38.38 0 0 0-.349-.046.638.638 0 0 0-.152.934Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2690",
    d: "m238.749 219.934-.387-.661a3.526 3.526 0 0 0 .813-.562.213.213 0 0 1 .258 0 .76.76 0 0 1 .334.585.228.228 0 0 1-.1.22.084.084 0 0 1-.061 0 3.678 3.678 0 0 0-.859.418Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2691",
    d: "M237.99 219.403a.41.41 0 0 1 .41-.41.493.493 0 0 1 .144 0h.061a.919.919 0 0 1 .418.714.449.449 0 0 1 0 .106.404.404 0 1 1-.805-.068v-.051a.4.4 0 0 1-.228-.291Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2692",
    d: "M238.4 219.197a.258.258 0 0 0-.418.236.912.912 0 0 0 .418.714.254.254 0 0 0 .41-.236.9.9 0 0 0-.41-.714Z",
    fill: "#455a64"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2693",
    d: "m318.149 228.93 2.279-3.928-99.055-57.178a1.109 1.109 0 0 0-1.162.091 3.54 3.54 0 0 0-1.6 2.773 1.14 1.14 0 0 0 .433 1.01Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2694",
    d: "M317.671 227.881a3.54 3.54 0 0 1 1.6-2.773c.881-.509 1.6-.091 1.6.927a3.533 3.533 0 0 1-1.6 2.773c-.886.519-1.6.099-1.6-.927Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--sheet--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2695",
    d: "m253.753 211.988-13.569-7.833v-22.823l13.569 7.841Z",
    opacity: 0.15
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2696",
    d: "m252.766 212.208-12.916-7.445a.76.76 0 0 1-.342-.593v-22.033a.213.213 0 0 1 .342-.2l12.916 7.445a.76.76 0 0 1 .342.593v22.033c.001.216-.152.306-.342.2Z",
    fill: "#fff"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2697",
    d: "m251.459 192.721-10.279-5.941a.76.76 0 0 1-.38-.532c0-.175.167-.213.38-.091l10.279 5.942a.76.76 0 0 1 .387.539c.001.161-.182.22-.387.083Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2698",
    d: "m251.459 194.377-10.279-5.971a.76.76 0 0 1-.38-.532c0-.175.167-.213.38-.091l10.279 5.934a.76.76 0 0 1 .387.539c.001.167-.182.212-.387.121Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2699",
    d: "m251.459 197.717-10.279-5.931a.76.76 0 0 1-.38-.532c0-.175.167-.22.38-.1l10.279 5.941a.76.76 0 0 1 .387.532c.001.176-.182.214-.387.09Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2700",
    d: "m251.459 199.345-10.279-5.933a.76.76 0 0 1-.38-.539c0-.167.167-.213.38-.091l10.279 5.941a.76.76 0 0 1 .387.532c.001.174-.182.212-.387.09Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2701",
    d: "m251.459 204.344-10.279-5.933a.76.76 0 0 1-.38-.532c0-.175.167-.213.38-.091l10.279 5.934a.76.76 0 0 1 .387.532c.001.174-.182.212-.387.09Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2702",
    d: "m251.459 202.735-10.279-5.949a.76.76 0 0 1-.38-.532c0-.175.167-.213.38-.091l10.279 5.934a.76.76 0 0 1 .387.532c.001.174-.182.212-.387.106Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--pushpin--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2703",
    d: "M245.586 187.752h.137l.258-.152.365-.22c.129-.076.273-.16.41-.251s0-.167-.084-.144l-.425.236-.372.205-.258.144a.062.062 0 0 0-.061.068v.053Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2704",
    d: "M245.305 187.934c.2.349.524.539.874.349a.365.365 0 0 0 .144-.334 1.17 1.17 0 0 0-.517-.9.4.4 0 0 0-.349-.046.638.638 0 0 0-.152.934Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 209",
    opacity: 0.15
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2705",
    d: "M245.305 187.934c.2.349.524.539.874.349a.365.365 0 0 0 .144-.334 1.17 1.17 0 0 0-.517-.9.4.4 0 0 0-.349-.046.638.638 0 0 0-.152.934Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2706",
    d: "m244.887 188.618-.387-.653a3.639 3.639 0 0 0 .813-.57.243.243 0 0 1 .258 0 .76.76 0 0 1 .334.593.243.243 0 0 1-.1.22h-.061a3.677 3.677 0 0 0-.857.41Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2707",
    d: "M244.166 188.086a.41.41 0 0 1 .41-.4.478.478 0 0 1 .144 0h.061a.935.935 0 0 1 .418.714.449.449 0 0 1 0 .106.404.404 0 1 1-.805-.068v-.043a.418.418 0 0 1-.228-.311Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 210",
    opacity: 0.15
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2708",
    d: "M244.166 188.086a.41.41 0 0 1 .41-.4.478.478 0 0 1 .144 0h.061a.935.935 0 0 1 .418.714.449.449 0 0 1 0 .106.404.404 0 1 1-.805-.068v-.043a.418.418 0 0 1-.228-.311Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2709",
    d: "M244.576 187.881a.259.259 0 0 0-.418.236.912.912 0 0 0 .418.714.253.253 0 0 0 .41-.236.9.9 0 0 0-.41-.714Z",
    fill: "#ffc0c0"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2710",
    d: "m251.497 189.978-1.117-.646v-4.239l1.117.646Z",
    fill: "#ffc0c0"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--sheet--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2711",
    d: "m238.088 202.94-13.569-7.833v-22.823l13.569 7.841Z",
    opacity: 0.15
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2712",
    d: "m237.1 203.16-12.916-7.445a.76.76 0 0 1-.342-.593v-22.017c0-.22.16-.311.342-.2l12.916 7.438a.76.76 0 0 1 .342.593v22.034c0 .206-.152.297-.342.19Z",
    fill: "#fff"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2713",
    d: "m235.794 183.672-10.279-5.933a.76.76 0 0 1-.38-.539c0-.167.167-.213.38-.091l10.279 5.941a.76.76 0 0 1 .387.532c.001.159-.174.212-.387.09Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2714",
    d: "m235.794 185.298-10.279-5.933a.76.76 0 0 1-.38-.539c0-.167.167-.213.38-.091l10.279 5.941a.76.76 0 0 1 .387.532c.001.166-.174.212-.387.09Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2715",
    d: "m235.794 188.671-10.279-5.933a.76.76 0 0 1-.38-.532c0-.175.167-.213.38-.091l10.279 5.934a.76.76 0 0 1 .387.532c.001.174-.174.212-.387.09Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2716",
    d: "m235.794 190.297-10.279-5.934a.76.76 0 0 1-.38-.532c0-.175.167-.213.38-.091l10.279 5.934a.76.76 0 0 1 .387.532c.001.175-.174.213-.387.091Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2717",
    d: "m235.794 195.296-10.279-5.933a.76.76 0 0 1-.38-.532c0-.175.167-.213.38-.091l10.279 5.934a.76.76 0 0 1 .387.532c.001.176-.174.219-.387.09Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2718",
    d: "m235.794 193.671-10.279-5.933a.76.76 0 0 1-.38-.532c0-.175.167-.213.38-.091l10.279 5.934a.76.76 0 0 1 .387.532c.001.174-.174.216-.387.09Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--pushpin--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2719",
    d: "M229.906 178.704h.137l.258-.152.365-.213.41-.258c.046 0 0-.167-.084-.144l-.425.236-.372.205-.258.152a.06.06 0 0 0-.061.061v.053Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2720",
    d: "M229.633 178.886c.2.349.524.539.874.349a.365.365 0 0 0 .144-.334 1.178 1.178 0 0 0-.517-.9.4.4 0 0 0-.349-.046.638.638 0 0 0-.152.934Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 211",
    opacity: 0.15
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2721",
    d: "M229.633 178.886c.2.349.524.539.874.349a.365.365 0 0 0 .144-.334 1.178 1.178 0 0 0-.517-.9.4.4 0 0 0-.349-.046.638.638 0 0 0-.152.934Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2722",
    d: "m229.222 179.577-.387-.661a3.8 3.8 0 0 0 .813-.562.228.228 0 0 1 .258 0 .76.76 0 0 1 .334.585.243.243 0 0 1-.1.22h-.055a3.313 3.313 0 0 0-.858.418Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2723",
    d: "M228.501 179.038a.41.41 0 0 1 .41-.4.478.478 0 0 1 .144 0h.061a.912.912 0 0 1 .418.714.385.385 0 0 1 0 .1.404.404 0 0 1-.805-.068.418.418 0 0 1-.228-.342Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 212",
    opacity: 0.15
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2724",
    d: "M228.501 179.038a.41.41 0 0 1 .41-.4.478.478 0 0 1 .144 0h.061a.912.912 0 0 1 .418.714.385.385 0 0 1 0 .1.404.404 0 0 1-.805-.068.418.418 0 0 1-.228-.342Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2725",
    d: "M228.911 178.833a.26.26 0 0 0-.418.243.934.934 0 0 0 .418.714.256.256 0 0 0 .41-.243.927.927 0 0 0-.41-.714Z",
    fill: "#ffc0c0"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2726",
    d: "m235.832 180.93-1.117-.646v-4.232l1.117.638Z",
    fill: "#ffc0c0"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--note--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2727",
    d: "m254.528 220.588-6.617-3.821v-10.189l6.617 3.822Z",
    opacity: 0.15
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--note--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2728",
    d: "m246.802 216.447 4.558 2.56c.509.281.843-.539.843-1.033.509.327 1.52.524 1.611-.122l.425-5.774-6.876-3.973Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2729",
    d: "m247.379 208.105 6.876 3.973v-1.276l-6.876-3.973Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2730",
    d: "m253.617 218.203-1.884.828.585-1.535Z",
    fill: "#37474f"
  })))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--water--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2731",
    d: "m314.175 339.251 12.391-7.149a7.5 7.5 0 0 1 6.838 0l12.391 7.149a7.544 7.544 0 0 1 3.411 5.911v58.9l-19.214 11.092-19.227-11.089v-58.9a7.544 7.544 0 0 1 3.41-5.914Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2732",
    d: "M329.975 356.254a7.544 7.544 0 0 0-3.411-5.911l-12.389-7.149c-1.884-1.094-3.411-.205-3.411 1.968v58.9l19.211 11.095Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2733",
    d: "M349.193 345.162v58.9l-19.214 11.095v-58.9a7.3 7.3 0 0 0-1.39-3.973l19.206-11.092a7.308 7.308 0 0 1 1.398 3.97Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2734",
    d: "m312.368 353.329 16.015 9.246-.008 21.28-16.007-9.246Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2735",
    d: "m312.368 353.329 16.015 9.246-.008 21.28-16.007-9.246Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2736",
    d: "M316.79 372.057v-16.19l11.594 6.709-.008 16.182Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2737",
    d: "m316.79 372.057-4.422 2.553 16.008 9.246v-5.1Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2738",
    d: "m314.723 354.682.585 2.826.638.365a1.945 1.945 0 0 0 1.96 0l.122-.068.243-1.079Z",
    fill: "#fafafa"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2739",
    d: "m322.465 359.149.593 2.872.638.365a1.96 1.96 0 0 0 1.96 0l.122-.068.243-1.109Z",
    fill: "#fafafa"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2740",
    d: "M346.1 334.063c0-2.127-1.611-4.27-4.406-5.888a26.036 26.036 0 0 0-23.415 0c-2.8 1.618-4.406 3.761-4.406 5.888v2.621c0 2.127 1.611 4.27 4.406 5.888a26.036 26.036 0 0 0 23.415 0c2.8-1.618 4.406-3.761 4.406-5.888Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2741",
    d: "M329.986 342.731a24.114 24.114 0 0 1-11.708-2.781c-2.8-1.618-4.407-3.761-4.407-5.888s1.611-4.27 4.406-5.888a26.036 26.036 0 0 1 23.415 0c2.8 1.618 4.406 3.761 4.406 5.888s-1.611 4.27-4.406 5.888a24.2 24.2 0 0 1-11.708 2.781Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2742",
    d: "M347.552 330.461v-34.043c.342-2.841-1.352-5.744-5.105-7.909-6.883-3.973-18.036-3.973-24.92 0-3.449 1.991-5.166 4.6-5.159 7.21v36.262h.076c.319 2.325 2.013 4.6 5.1 6.389 6.883 3.973 18.036 3.973 24.92 0 3.085-1.785 4.779-4.065 5.1-6.389v-.091a6.345 6.345 0 0 0-.008-1.428Z",
    fill: "#ffc0c0",
    opacity: 0.4
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2743",
    d: "M329.986 339.084a23.058 23.058 0 0 1-11.328-2.636c-2.34-1.352-3.753-3.039-3.989-4.741l-.038-.327v-23.5c0-1.854 1.459-3.8 4.027-5.25a25.262 25.262 0 0 1 22.656 0c2.781 1.6 4.232 3.67 3.989 5.675v22.428a3.419 3.419 0 0 1 0 .881v.144c-.289 1.649-1.709 3.32-3.989 4.688a23.058 23.058 0 0 1-11.328 2.636Z",
    fill: "#fff",
    opacity: 0.4
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2744",
    d: "M341.314 302.631a23.765 23.765 0 0 0-11.328-2.65 26.789 26.789 0 0 0-11.328 2.682 6.351 6.351 0 0 0-4.027 5.675 6.426 6.426 0 0 0 4.027 5.675 26.788 26.788 0 0 0 11.328 2.682 23.058 23.058 0 0 0 11.328-2.714c2.781-1.6 3.989-3.594 3.989-5.675.129-2.149-1.14-4.11-3.989-5.675Z",
    fill: "#fff",
    opacity: 0.2
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2745",
    d: "M329.986 304.374a24.2 24.2 0 0 1-11.708-2.781c-2.8-1.618-4.407-3.8-4.407-5.888s1.611-4.27 4.406-5.888a26.036 26.036 0 0 1 23.415 0c2.8 1.618 4.406 3.761 4.406 5.888s-1.611 4.27-4.406 5.888a24.2 24.2 0 0 1-11.708 2.781Z",
    fill: "#ffc0c0",
    opacity: 0.2
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2746",
    d: "m323.84 353.451-.684.4v.053a.98.98 0 0 0-.122.5 2.34 2.34 0 0 0 1.061 1.82 1.01 1.01 0 0 0 .494.144v.053l.684-.4a.76.76 0 0 0 .312-.676 2.34 2.34 0 0 0-1.056-1.831.76.76 0 0 0-.689-.063Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2747",
    d: "m323.84 353.451-.684.4v.053a.98.98 0 0 0-.122.5 2.34 2.34 0 0 0 1.061 1.82 1.01 1.01 0 0 0 .494.144v.053l.684-.4a.76.76 0 0 0 .312-.676 2.34 2.34 0 0 0-1.056-1.831.76.76 0 0 0-.689-.063Z",
    opacity: 0.15
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2748",
    d: "M324.955 355.745c0 .669-.471.942-1.056.608a2.34 2.34 0 0 1-1.056-1.831c0-.669.471-.942 1.056-.608a2.34 2.34 0 0 1 1.056 1.831Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2749",
    d: "m316.091 349.021-.684.4.038.061a.866.866 0 0 0-.122.494 2.347 2.347 0 0 0 1.048 1.831.957.957 0 0 0 .494.137v.061l.684-.4a.76.76 0 0 0 .311-.684 2.325 2.325 0 0 0-1.056-1.823.76.76 0 0 0-.713-.077Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2750",
    d: "M317.203 351.316c0 .676-.471.95-1.056.608a2.325 2.325 0 0 1-1.048-1.823c0-.669.471-.942 1.048-.608a2.325 2.325 0 0 1 1.056 1.823Z",
    fill: "#fafafa"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--clock--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2751",
    d: "m333.109 231.605 2.135-1.269c2.112-1.064 4.931-.76 7.962 1.2 6.078 3.928 10.758 12.984 10.4 20.224-.175 3.609-1.557 6.078-3.662 7.18l-2.135 1.269c-2.112 1.079-4.931.76-7.97-1.193-6.078-3.928-10.75-12.984-10.4-20.224.183-3.609 1.573-6.086 3.67-7.187Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2752",
    d: "m347.992 260.117 1.983-1.162c2.1-1.094 3.487-3.571 3.662-7.18a22.587 22.587 0 0 0-2.2-10.15l-2.142 1.269a22.4 22.4 0 0 1 2.2 10.15c-.137 3.491-1.474 5.911-3.503 7.073Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2753",
    d: "M339.848 259.016c-6.078-3.928-10.75-12.984-10.4-20.224s5.576-9.93 11.677-6.01 10.75 12.984 10.4 20.224-5.576 9.938-11.677 6.01Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2754",
    d: "M344.961 258.507c3.594.175 4.179-3.867 4.262-5.607.311-6.389-3.973-14.716-9.345-18.173a8.145 8.145 0 0 0-3.867-1.436c-3.594-.175-4.179 3.867-4.262 5.615-.311 6.382 3.973 14.709 9.345 18.173a8.129 8.129 0 0 0 3.867 1.428Z",
    fill: "#fafafa"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2755",
    d: "M340.045 247.559a1.065 1.065 0 0 1-.129-.167 1.428 1.428 0 0 1-.266-.676v-9.276c0-.22.175-.19.4.061a1.611 1.611 0 0 1 .387.843v8.1l4.315-.555c.129 0 .372.236.547.562s.2.615.068.631l-5.014.653c-.072.006-.194-.077-.308-.176Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2756",
    d: "M337.834 251.798a.266.266 0 0 1-.053-.068.509.509 0 0 1-.114-.334l2.173-4.8c0-.061.114 0 .205.122s.137.281.106.334l-2.165 4.809c-.019.043-.084.01-.152-.063Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2757",
    d: "M339.917 245.143a2.917 2.917 0 0 1 1.375 2.279c.046.9-.5 1.33-1.223.965a2.971 2.971 0 0 1-1.375-2.279c-.039-.904.508-1.33 1.223-.965Z",
    fill: "#ffc0c0"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--window--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--window--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2758",
    d: "m210.722 249.215-2.743 1.588-68.627-39.629 2.743-1.58 28.825 16.638 2.75 1.588 1.368.79h.008l32.936 19.024Z",
    fill: "#f5f5f5"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2759",
    d: "M173.669 165.681v63.72l-2.75-1.58v-63.728Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2760",
    d: "M175.044 164.891v63.72h-.008l-1.368.79v-63.72Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2761",
    d: "m173.669 165.681-2.75-1.58 1.375-.8 2.743 1.588Z",
    fill: "#fafafa"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2762",
    d: "m175.049 164.891-2.75-1.6-35.69-20.577v70.048l74.113 42.789v-70.064Zm32.935 85.912-68.635-39.629v-63.719l2.75 1.58 28.82 16.638 2.735 1.58 1.368.76 32.935 18.994Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2763",
    d: "M207.979 187.075v60.559l-32.935-19.024v-60.551Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2764",
    d: "M207.979 187.075v60.559l-32.935-19.024v-60.551Z",
    fill: "#fff",
    opacity: 0.8
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2765",
    d: "M170.914 165.681v60.552l-28.82-16.639.008-60.551Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2766",
    d: "M170.914 165.681v60.552l-28.82-16.639.008-60.551Z",
    fill: "#fff",
    opacity: 0.8
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2767",
    d: "M142.102 149.035v.008l-.008 60.551-2.743 1.58v-63.719Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2768",
    d: "m136.609 142.699 2.74-1.588 74.12 42.8-2.75 1.58Z",
    fill: "#f5f5f5"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2769",
    d: "m213.472 183.907-2.75 1.58v70.063l2.743-1.58Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2770",
    d: "m173.67 167.261-2.743-1.58v1.588l2.743 1.58Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2771",
    d: "m173.669 168.851 1.368-.79-1.368-.8Z",
    opacity: 0.1
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2772",
    d: "m191.728 185.282 16.251 9.4-.023 52.954-16.258-9.406Z",
    opacity: 0.05
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2773",
    d: "m207.979 204.595-16.258-9.4.008-5.485 16.251 9.4Z",
    opacity: 0.05
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2774",
    d: "m207.972 214.662-16.251-9.4v-5.491l16.258 9.4Z",
    opacity: 0.05
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2775",
    d: "m207.971 224.728-16.258-9.4.008-5.493 16.251 9.4Z",
    opacity: 0.05
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2776",
    d: "m207.964 234.787-16.251-9.4v-5.483l16.258 9.4Z",
    opacity: 0.05
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2777",
    d: "m207.963 244.854-16.258-9.4.008-5.493 16.251 9.406Z",
    opacity: 0.05
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2778",
    d: "m184.64 234.156 7.058 4.072.023-35.708-7.061-4.079Z",
    opacity: 0.05
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2779",
    d: "M159.15 173.861v-8.5l-3.67-2.135v8.486l-3.837-2.226v-8.447l-9.526-5.508v54.078l20.878 12.052v-45.587Z",
    opacity: 0.05
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 213",
    opacity: 0.05
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2780",
    d: "m158.231 187.957 2.378 1.375v-9.588l-2.378-1.375Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2781",
    d: "m154.022 185.518 2.378 1.375v-9.58l-2.378-1.375Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2782",
    d: "m158.231 202.303 2.378 1.368v-9.58l-2.378-1.378Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2783",
    d: "m154.022 199.872 2.378 1.368v-9.58l-2.378-1.378Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2784",
    d: "m158.231 216.645 2.378 1.375v-9.588l-2.378-1.375Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2785",
    d: "m154.022 214.214 2.378 1.375v-9.588l-2.378-1.375Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2786",
    d: "m148.347 182.243 2.378 1.375v-9.587l-2.378-1.368Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2787",
    d: "m144.13 179.812 2.386 1.375V171.6l-2.386-1.368Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2788",
    d: "m148.347 196.587 2.378 1.375v-9.58l-2.378-1.375Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2789",
    d: "m144.13 194.156 2.386 1.375v-9.58l-2.386-1.375Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2790",
    d: "m148.347 210.931 2.378 1.375v-9.58l-2.378-1.375Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2791",
    d: "m144.13 208.5 2.386 1.375v-9.58l-2.386-1.375Z"
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2792",
    d: "M197.724 368.548a.707.707 0 0 0 .707-.707v-45.447a.707.707 0 0 0-1.413 0v45.448a.707.707 0 0 0 .706.706Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2793",
    d: "M169.612 352.008a.706.706 0 0 0 .661-.448l13.934-35.275a.708.708 0 1 0-1.314-.524l-13.964 35.271a.714.714 0 0 0 .4.919.631.631 0 0 0 .283.057Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2794",
    d: "M171.262 347.767a.7.7 0 0 0 .509-.22l25.949-27.44 25.884 27.351a.707.707 0 1 0 1.026-.965l-26.416-27.9a.692.692 0 0 0-.509-.228.706.706 0 0 0-.517.228l-26.447 27.981a.714.714 0 0 0 0 1 .76.76 0 0 0 .521.193Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2795",
    d: "M225.834 352.008a.63.63 0 0 0 .258-.053.707.707 0 0 0 .4-.919l-13.934-35.275a.708.708 0 1 0-1.314.524l13.934 35.275a.76.76 0 0 0 .661.448Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2796",
    d: "m170.547 346.682-1.846 4.862a.593.593 0 0 0 0 .122v.091c0 .1.144.22.281.3a1.254 1.254 0 0 0 1.117 0 .479.479 0 0 0 .22-.228v-.068l1.709-4.558Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2797",
    d: "m224.862 346.682 1.846 4.862a.6.6 0 0 1 0 .122v.091c0 .1-.144.22-.281.3a1.254 1.254 0 0 1-1.117 0 .479.479 0 0 1-.22-.228v-.068l-1.709-4.558Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2798",
    d: "M196.888 364.324v4.034a.41.41 0 0 0 .243.334 1.269 1.269 0 0 0 1.147 0 .41.41 0 0 0 .243-.334v-4.019a1.732 1.732 0 0 0-1.633-.015Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2799",
    d: "M171.132 317.941c0-1.071.934-2.2 2.91-3.487 3.647-2.363 11.8-7.111 16.9-9.945a.038.038 0 0 1 .038-.038c3.928-2.386 7.6-13.736 10.31-22.359.927-2.94 2.066-4.6 3.411-5.387l1.755-.988c2.667-1.6 6.169.319 10.53 2.7 4.019 2.2 7.157 5.014 7.787 12.483a109.807 109.807 0 0 1-.9 19.822c-1.337 11-2.978 11.016-5.364 12.862-4.1 3.168-13.333 7.6-17.223 9.117-7.066 2.781-12.832-1.52-17.132-3.624a100.38 100.38 0 0 1-11.4-6.754 3.079 3.079 0 0 1-1.618-2.4c-.004-.309-.004-1.66-.004-2.002Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2800",
    d: "M171.132 317.941c0-1.071.934-2.2 2.91-3.487 3.647-2.363 11.8-7.111 16.9-9.945a.038.038 0 0 1 .038-.038c3.928-2.386 7.6-13.736 10.31-22.359.927-2.94 2.066-4.6 3.411-5.387l1.755-.988c2.667-1.6 6.169.319 10.53 2.7 4.019 2.2 7.157 5.014 7.787 12.483a109.807 109.807 0 0 1-.9 19.822c-1.337 11-2.978 11.016-5.364 12.862-4.1 3.168-13.333 7.6-17.223 9.117-7.066 2.781-12.832-1.52-17.132-3.624a100.38 100.38 0 0 1-11.4-6.754 3.079 3.079 0 0 1-1.618-2.4c-.004-.309-.004-1.66-.004-2.002Z",
    opacity: 0.25
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2801",
    d: "M204.819 276.634c2.644-1.383 6.078.5 10.325 2.826 2.72 1.52 5.045 3.259 6.45 6.572l1.793-1.041c-1.406-3.3-3.723-5.06-6.435-6.549-4.361-2.386-7.863-4.308-10.53-2.7Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2802",
    d: "M174.004 314.453c2.37-1.519 2.424-1.922 17.018-10.013h-.068c3.928-2.386 7.6-13.729 10.3-22.352 2.765-8.76 7.362-6.222 13.888-2.651 4.019 2.2 7.157 5.014 7.787 12.483s-.76 25.983-3.3 28.224c-2.781 3.039-13.934 8.783-18.386 10.538-7.066 2.773-12.832-1.52-17.132-3.632a99.405 99.405 0 0 1-11.4-6.747c-2.437-1.755-2.209-3.57 1.293-5.85Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2803",
    d: "M190.954 304.463Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 214",
    opacity: 0.1
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2804",
    d: "M215.144 279.468c-6.526-3.571-11.123-6.078-13.888 2.651-2.72 8.623-6.382 19.974-10.31 22.359 0 0 6.739 0 16.5 5.265 10.143 5.478 11.692 10.842 12.156 10.454 2.56-2.127 3.951-20.779 3.32-28.247s-3.756-10.287-7.778-12.482Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--character--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2805",
    d: "M172.431 285.226a10.842 10.842 0 0 0-2.454-1.808c-.631-.365-1.36-.585-2.021-.912a12.035 12.035 0 0 1-2.781-1.823 5.114 5.114 0 0 1-1.026-1.155 9.162 9.162 0 0 1-.714-1.519 5.107 5.107 0 0 1-.342-1.519 2.682 2.682 0 0 1 .349-1.519 1.329 1.329 0 0 1 .676-.6 1.307 1.307 0 0 1 .957.084 4.557 4.557 0 0 1 .828.539 18.691 18.691 0 0 0 3.6 2.089 1.748 1.748 0 0 0 1.284.2 2.8 2.8 0 0 0-.35-1.056 4.749 4.749 0 0 1-.456-1.026 1.368 1.368 0 0 1 .129-1.079.517.517 0 0 1 .547-.243.759.759 0 0 1 .228.175c.38.4.76.76 1.14 1.178a7.642 7.642 0 0 1 .874 1.193c.38.577.653 1.14.972 1.74a13.3 13.3 0 0 0 2.652 3.145c1.178 1.132 5.652 5.569 6.784 6.564 0 0 6.579-10.522 8.357-13.25 3.153-4.923 9.011-3.837 9.011-3.837l-1.755 7.294s-10.568 15.195-12.353 17.261a3.419 3.419 0 0 1-5.181.167 46.55 46.55 0 0 1-3.138-3.563c-1.519-1.808-3.039-3.624-4.558-5.4-.453-.453-.849-.894-1.259-1.32Z",
    fill: "#ffa8a7"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2806",
    d: "M201.235 270.579s-4.824-.76-7.218 1.269c-2.226 1.93-2.971 3.039-5.934 8.106-2.712 4.627-4.627 7.271-4.627 7.271s1.953 4.878 5.9 4.779l6.564-8.691Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2807",
    d: "M192.192 285.986a23.2 23.2 0 0 1-.281 7.4 82.291 82.291 0 0 1-1.717 6.02 7.445 7.445 0 0 0 6.124 2.279c4.247-.4 3.419-10.469 1.109-13.045a7.954 7.954 0 0 0-5.235-2.654Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2808",
    d: "m188.993 365.196-.524-.114c.076-1.671.274-3.2-.091-4.011l.9-2.006Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2809",
    d: "M190.809 357.668c-.2 1.14-.927 2.279-1.124 4.558a19.037 19.037 0 0 0-.129 2.895l-.562.106.281-6.131Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2810",
    d: "M177.21 365.934a1.519 1.519 0 0 0 .312.859c.273.236 1.14 1.041 4.095 1.064s4.034-.638 5.105-1.519 1.519-3.244 1.717-4.369a8.418 8.418 0 0 1 2.355-4.331 1.96 1.96 0 0 0 .16-1.132 3.715 3.715 0 0 0-3.654 2.325c-1.231 2.621-2.279 5.7-4.7 6.291a37.925 37.925 0 0 1-5.394.813Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2811",
    d: "M178.893 363.472c-.95.714-1.656 1.018-1.626 1.74s.76 1.1 1.368 1.33a10.151 10.151 0 0 0 4.558.3c1.519-.167 3.13-.76 3.8-2.082a5.9 5.9 0 0 0 .433-1.246 18.43 18.43 0 0 1 1.383-4.125 9.515 9.515 0 0 1 .912-1.573 4.088 4.088 0 0 0 1.041-1.77 4.217 4.217 0 0 0-.805-2.279 3.472 3.472 0 0 1-.524-2.689l.425-4.148-6.64 1.124s.357 3.654.357 4.6a16.167 16.167 0 0 1-.608 4.125 20.986 20.986 0 0 1-1.991 4.6 4.5 4.5 0 0 1-.76 1.018 12.682 12.682 0 0 1-1.323 1.075Z",
    fill: "#ffa8a7"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2812",
    d: "M190.825 354.837c-.365-.76-.912-1.254-1.269-1.915a7.1 7.1 0 0 0-.881 1.74c-.22.577-.889 3.434-1.747 5.683a4.369 4.369 0 0 1-2.872 2.933 5 5 0 0 1-2.439.114c-1.52-.311-1.086-1.383-1.086-1.383a19.819 19.819 0 0 1-3.039 2.2 1.246 1.246 0 0 0-.236 1.725c.4.4 1.793 1.383 5.485 1.094 3.274-.251 4.133-1.7 4.482-2.355a15.461 15.461 0 0 0 .874-3 9.7 9.7 0 0 1 1.352-3.153c.084-.122.16-.236.236-.327.243-.3.524-.638.843-.972s.425-.38.509-.638a2.454 2.454 0 0 0-.212-1.746Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2813",
    d: "m173.024 359.628-.517-.152c.2-1.664.509-3.168.205-4.011l1.041-1.93Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2814",
    d: "M175.394 352.259c-.281 1.117-1.094 2.2-1.459 4.429a18.69 18.69 0 0 0-.342 2.872l-.57.068.76-6.078Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2815",
    d: "M161.255 359.491a1.519 1.519 0 0 0 .251.881c.251.258 1.064 1.086 4 1.322s4.072-.3 5.2-1.064 1.725-3.123 2.036-4.232a8.357 8.357 0 0 1 2.674-4.141 1.983 1.983 0 0 0 .243-1.124 3.715 3.715 0 0 0-3.8 2.051c-1.421 2.522-2.674 5.516-5.143 5.926a38.146 38.146 0 0 1-5.461.381Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2816",
    d: "M163.071 357.159c-1 .646-1.725.889-1.747 1.618s.691 1.155 1.269 1.421a10.067 10.067 0 0 0 4.49.631 4.746 4.746 0 0 0 3.981-1.785 5.7 5.7 0 0 0 .524-1.208 18.311 18.311 0 0 1 1.687-4.019 9.154 9.154 0 0 1 1.026-1.519 4.118 4.118 0 0 0 1.162-1.694 4.2 4.2 0 0 0-.631-2.363 4.215 4.215 0 0 1-.4-3.221l.76-3.616-6.351.6s-.236 2.5-.3 4.376a13.41 13.41 0 0 1-.912 4.338 21.129 21.129 0 0 1-2.279 4.445 4.558 4.558 0 0 1-.821.965 12.678 12.678 0 0 1-1.466 1.033Z",
    fill: "#ffa8a7"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2817",
    d: "M175.553 349.25a18.484 18.484 0 0 0-1.064-1.77 6.534 6.534 0 0 0-1.01 1.52c-.372.707-1.132 3.48-2.158 5.668a4.407 4.407 0 0 1-3.077 2.712 4.939 4.939 0 0 1-2.446-.076c-1.519-.425-.972-1.466-.972-1.466a19.4 19.4 0 0 1-3.214 1.975 1.238 1.238 0 0 0-.365 1.7c.372.425 1.687 1.519 5.387 1.519 3.282 0 4.247-1.39 4.65-2.021a15.888 15.888 0 0 0 1.094-2.925 9.877 9.877 0 0 1 1.58-3.039l.258-.3c.266-.281.57-.6.912-.912s.456-.342.562-.593a2.758 2.758 0 0 0-.137-1.992Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2818",
    d: "M169.092 314.066c2.317-2.758 7.233-5.06 11.351-6.929s7.21-3.746 11.776-5.6c6.222 2.279 15.894 0 22.291-2.712 1.588 2.135 3.4 10.393 2.811 14.063-.57 3.54-1.823 7.734-10.15 11.107-4.961 2.013-15.248 6.078-15.248 6.078a27.519 27.519 0 0 1-.281 7.932c-.76 5.356-1.839 11.168-1.839 11.168a7.536 7.536 0 0 1-6.458.243s-1.922-15.635-2.4-20.65c-.251-2.621.19-4.384.874-5.151a24.143 24.143 0 0 1 5.045-4.148l-8.676 2.492s1.17 3.632-.22 9.466c-1.254 5.235-3.191 11.989-3.191 11.989s-2.059 1.519-6.275-.228c0 0-.236-16.069-.357-21.106-.12-4.496-.098-6.76.947-8.014Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2819",
    d: "M169.092 314.066c2.317-2.758 7.233-5.06 11.351-6.929s7.21-3.746 11.776-5.6c6.222 2.279 15.894 0 22.291-2.712 1.588 2.135 3.4 10.393 2.811 14.063-.57 3.54-1.823 7.734-10.15 11.107-4.961 2.013-15.248 6.078-15.248 6.078a27.519 27.519 0 0 1-.281 7.932c-.76 5.356-1.839 11.168-1.839 11.168a7.536 7.536 0 0 1-6.458.243s-1.922-15.635-2.4-20.65c-.251-2.621.19-4.384.874-5.151a24.143 24.143 0 0 1 5.045-4.148l-8.676 2.492s1.17 3.632-.22 9.466c-1.254 5.235-3.191 11.989-3.191 11.989s-2.059 1.519-6.275-.228c0 0-.236-16.069-.357-21.106-.12-4.496-.098-6.76.947-8.014Z",
    opacity: 0.5
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2820",
    d: "M208.595 271.111s7 1.132 7.825 1.519c-6.838 4.338-1.945 14.906-1.945 14.906l-1.421 7.468c.919 2.834 3.191 7.119 4.369 11.4-9.413 5.083-24.768 2.4-25.74-4.7.615-2.75 1-6.671 1.39-8.691 0-1.519.19-3.214.129-5.668a7.058 7.058 0 0 1-1.117-8.258c2.857-5.075 7.529-8.646 8.965-8.585Z",
    fill: "#f5f5f5"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2821",
    d: "M198.916 250.225c-2.332.919-3.556 3.662-3.859 10.325-.251 5.652 1.482 7.164 2.37 7.6s2.682.342 4.422.175l-.129 2.332s-3.244 3.274-3.2 4.84 3.875 2.522 6.207 1.155 4.452-4.961 4.452-4.961l.441-7.012s.942 1.056 2.765-.327c1.52-1.147 2.12-3.2 1.086-4.4a2.477 2.477 0 0 0-3.981.517 9.793 9.793 0 0 0-3.35-6.5c-3.099-2.612-4.694-3.706-7.224-3.744Z",
    fill: "#ffa8a7"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2822",
    d: "M210.593 271.468s3.039.274 4.027.433c1.421.22 4.52 5.083 2.872 10.576-1.778 5.911-3.411 11.54-3.275 12.824s3.039 9.033 3.039 9.033a6.039 6.039 0 0 1-4.011 2.029l-1.846-6.382.38 6.838a32.326 32.326 0 0 1-7.415.3s.789-21.9 6.229-35.651Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2823",
    d: "M215.569 272.364c4 .289 5.934 1.664 7.081 6.3 1.033 4.171 3.206 14.367 3.616 17.071.372 2.469.509 3.4-.76 5.569-1.056 1.77-8.714 11.609-9.641 13.083a38.926 38.926 0 0 1-3.51 4.657 9.253 9.253 0 0 1-5.143 2.917c-2.143.266-4.559-1-4.46-2.241s3.753-2.682 5.455-4.984a11.675 11.675 0 0 1-1.9.623c-.889.19-1.785-.053-1.975-.57s.684-.646 1.519-1.238c.517-.357 1.466-1.185 2.614-1.869a17.031 17.031 0 0 0 2.469-1.246 35.2 35.2 0 0 0 3.5-5.219c1.717-3.039 4.407-7.5 4.407-7.5l-3.16-13.691s-1.848-8.881-.112-11.662Z",
    fill: "#ffa8a7"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2824",
    d: "M214.619 271.87a12.49 12.49 0 0 1 4.558.843 6.542 6.542 0 0 1 3.039 3.419c.539 1.307 4.293 19.411 4.293 19.411a6.635 6.635 0 0 1-3.7 1.6 9.679 9.679 0 0 1-4.475 0l-3.328-14.207s-2.476-6.553-.387-11.066Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2825",
    d: "M199.367 247.301a11.474 11.474 0 0 1 7.271-1.656c2.545.167 5.668 1.254 7.347 3.161a12.513 12.513 0 0 1 2.955 5.318 12.049 12.049 0 0 1-.448 6.595c-1.345 4.247-7.073 7.3-7.187 9.117l.319-5.121s.942 1.048 2.765-.334c1.519-1.14 2.12-3.2 1.086-4.4a2.477 2.477 0 0 0-3.981.517l-.084 1.451a1.519 1.519 0 0 1-1.443-1.611l.137-2.363c-2.576-.327-7.6-1.861-7.3-7.468a8.587 8.587 0 0 0 .957 5.766s-3.746-.623-3.578-4.163c0 0-.5 4.133-2.8 4.437a3.358 3.358 0 0 1-1.17-1.413c-1.193-2.887-.023-8.13 5.154-7.833Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2826",
    d: "M222.232 271.02a5.873 5.873 0 0 1-5.88-5.873v-11.214a5.888 5.888 0 0 1 5.88 5.88Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2827",
    d: "M202.516 258.828a.805.805 0 0 0 .691.912.828.828 0 1 0-.691-.912Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2828",
    d: "m203.041 263.376-2.895.714a1.474 1.474 0 0 0 1.77 1.14 1.573 1.573 0 0 0 1.125-1.854Z",
    fill: "#b16668"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2829",
    d: "M201.871 264.357a1.2 1.2 0 0 0-1.071.669 1.383 1.383 0 0 0 1.124.205 1.519 1.519 0 0 0 .8-.517 1.178 1.178 0 0 0-.851-.357Z",
    fill: "#f28f8f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2830",
    d: "m202.874 256.713 1.785 1.018a1.018 1.018 0 0 0-.349-1.413 1.086 1.086 0 0 0-1.436.395Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2831",
    d: "m196.052 256.273 1.907-.76a1.018 1.018 0 0 0-1.314-.608 1.079 1.079 0 0 0-.593 1.368Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2832",
    d: "m199.85 258.104-.76 4.376-2.12-.9Z",
    fill: "#f28f8f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2833",
    d: "M201.848 268.352c1.823-.114 5.63-.934 6.313-2.37a3.852 3.852 0 0 1-1.436 1.793c-1.185.881-4.938 1.679-4.938 1.679Z",
    fill: "#f28f8f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2834",
    d: "M195.99 257.899a.8.8 0 1 0 .9-.729.821.821 0 0 0-.9.729Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2835",
    d: "M186.851 319.468s6.564-4.179 9.3-6.184a15.422 15.422 0 0 1-3.282-3.859 7.688 7.688 0 0 0 1.33 3.8l-6.838 5.113-9.224 3.656Z",
    opacity: 0.2
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--character--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2836",
    d: "M73.125 195.555c.312.319.631.638.957.95.441.418 1.337 1.086 1.778 1.519.129.129.653.463.7.615a9.786 9.786 0 0 1-.517-2.234 1.383 1.383 0 0 1 1.079-1.519c.3 0 .319.714.934 1.755.76 1.33 1.823 2.021 2.279 3.632a2.963 2.963 0 0 0 1.519 1.633l12.353 6.131s9.041-3.35 13.721-5.181c5.44-2.135 11.67-4.163 12.71-3.039l-10.393 9.39s-7.909 4.285-14.063 6.739a4.447 4.447 0 0 1-4.9-.6 112.128 112.128 0 0 1-10.53-6.959 71.93 71.93 0 0 0-6.724-4.346c-1.8-1-3.89-2.355-4.733-4.331a4.163 4.163 0 0 1 0-3.419 4.292 4.292 0 0 0 .6-1.352 8.238 8.238 0 0 0-.046-.858.912.912 0 0 1 .3-.76.76.76 0 0 1 .821 0 2.522 2.522 0 0 1 .623.585Z",
    fill: "#ffbda7"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2837",
    d: "M120.495 199.277c-4.665-.691-7 .76-10.2 2.066-3.8 1.573-16.038 6.321-16.038 6.321l-7.894-3.723s-1.816 4.1-3.8 5.766c0 0 7.1 5.029 9.064 6.253s2.089 1.162 5.189.144 17.1-4.558 17.1-4.558Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2838",
    d: "M141.281 312.676a6.078 6.078 0 0 1-5.394.16l-1.307-10.576 6.412.653Z",
    fill: "#ffbda7"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2839",
    d: "M121.505 306.91c-1.292 3.039-3.8 2.279-6.686.448l.175-10.682 6.784-.205Z",
    fill: "#ffbda7"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2840",
    d: "M129.626 323.076a2.507 2.507 0 0 0 .122 1.641 5.2 5.2 0 0 0 3.7 1.428 8.965 8.965 0 0 0 5.212-1.079 3.662 3.662 0 0 0 1.877-2.925c.084-1.208-.091-2.363.456-3.312s1.322-1.861 1.519-2.332a4.748 4.748 0 0 0-.061-2.454Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2841",
    d: "M135.12 312.387a6.078 6.078 0 0 1-.22 1.352 12.535 12.535 0 0 1-1.216 2.682 11.951 11.951 0 0 1-.843 1.276c-.623.76-1.4 1.428-2.051 2.173a4.346 4.346 0 0 0-1.231 2.636c-.038 1.664 1.778 2.173 3.168 2.378a10.234 10.234 0 0 0 4.5-.357 4.148 4.148 0 0 0 2.94-3.4c.061-.463 0-.934.061-1.4a6.473 6.473 0 0 1 1.2-2.94 8.828 8.828 0 0 0 .942-1.611 5.154 5.154 0 0 0-.281-3.2c-.266-.874-.57-1.869-.874-1.778a1.132 1.132 0 0 1-.061.532 2.386 2.386 0 0 0-.228.532 3.707 3.707 0 0 1-.236.691 1.808 1.808 0 0 1-.707.836c-.038-.631-.084-1.254-.122-1.877a.843.843 0 0 0-.16-.547.882.882 0 0 0-.539-.213 11.434 11.434 0 0 0-3.556-.19.631.631 0 0 0-.471.22.676.676 0 0 0-.061.425c.031.617.069 1.202.046 1.78Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2842",
    d: "M133.471 316.779a4.724 4.724 0 0 1 2.743-.471 4.65 4.65 0 0 1 2.173.691.486.486 0 0 0 .631-.068.463.463 0 0 0-.061-.707 4.763 4.763 0 0 0-2.454-.821 4.859 4.859 0 0 0-2.4.258s-.829.571-.632 1.118Z",
    fill: "#f5f5f5"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2843",
    d: "M132.096 318.518a6.039 6.039 0 0 1 3.039-.4 4.308 4.308 0 0 1 2.12.76.494.494 0 0 0 .631-.068.471.471 0 0 0-.068-.707 4.832 4.832 0 0 0-2.5-.9c-1.869-.076-2.34.319-2.34.319a1.519 1.519 0 0 0-.882.996Z",
    fill: "#f5f5f5"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2844",
    d: "M137.194 313.596a4.68 4.68 0 0 0-2.332.266c-.327.2-.524.722-.312.843a4.391 4.391 0 0 1 2.066-.342 6.078 6.078 0 0 1 2.029.494 5.383 5.383 0 0 1 .524.243.441.441 0 0 0 .608-.205.425.425 0 0 0-.175-.532 6.078 6.078 0 0 0-2.408-.767Z",
    fill: "#f5f5f5"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2845",
    d: "M103.902 314.264a2.021 2.021 0 0 0 .129 1.474c.22.425 2.515 1.633 5.546 1.337a12.741 12.741 0 0 0 6.23-2.386 7.316 7.316 0 0 1 3.844-1.117c1.519-.129 3.464-.942 3.8-1.656a3.381 3.381 0 0 0-.106-1.915Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2846",
    d: "m115.85 304.539-.8-.273a.707.707 0 0 0-.448-.038.661.661 0 0 0-.312.517 7.514 7.514 0 0 1-.289 1.33 3.442 3.442 0 0 1-.828.927 13.911 13.911 0 0 1-2.393 1.641c-.972.562-1.937 1.01-2.948 1.52a28.434 28.434 0 0 0-3.221 1.413 2.2 2.2 0 0 0 .122 3.624 10.781 10.781 0 0 0 7.521.3c1.747-.555 3.647-2.5 5.956-2.75 1.474-.16 4.247-.653 5.159-1.8.334-.509-.175-2.066-.6-3.411-.463-1.466-.691-3.8-1.178-3.639 0 .494-.441.8-.684 1.216a8.2 8.2 0 0 0-.494 1.193 2.143 2.143 0 0 1-.76 1.033.965.965 0 0 1-1.193 0c-.448-.433-.213-1.231-.547-1.755a1.869 1.869 0 0 0-1.056-.653Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2847",
    d: "M112.138 307.806a1.383 1.383 0 0 1 1.071-.76 3.951 3.951 0 0 1 2.614.9.547.547 0 0 1-.053.912.524.524 0 0 1-.623-.053 4.247 4.247 0 0 0-3.009-.999Z",
    fill: "#f5f5f5"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2848",
    d: "M110.101 309.029a1.573 1.573 0 0 1 1.269-.7 4.931 4.931 0 0 1 2.864.972.539.539 0 0 1-.053.881.517.517 0 0 1-.6-.053 4.239 4.239 0 0 0-3.48-1.1Z",
    fill: "#f5f5f5"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2849",
    d: "M107.837 310.146a1.77 1.77 0 0 1 1.322-.638 4.741 4.741 0 0 1 2.743.988.539.539 0 0 1-.03.881.524.524 0 0 1-.608-.053 4.034 4.034 0 0 0-3.426-1.178Z",
    fill: "#f5f5f5"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2850",
    d: "M138.789 235.213c.76 11.609 1.907 37.227 1.907 37.227.167 1.443.7 4.908.957 10.1.387 7.544-.213 24.2-.213 24.2a8.129 8.129 0 0 1-6.443.509s-4.285-23.75-5.66-31.149c-1.208-6.5-3.556-18.766-3.556-18.766l-1.1 15.859a52.419 52.419 0 0 1-.258 9.588c-.433 3.442-2.5 18.378-2.5 18.378a13.744 13.744 0 0 1-7.286.061s-.661-24.38-.821-27.556c-.175-3.609-.934-40.76-.934-40.76Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2851",
    d: "m125.782 257.313-2.006-9.466s-4.771-.281-7.483-2.857c0 0 .547 2.591 6.579 3.973l2.006 9.58.2 8.912Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2852",
    d: "M136.602 200.683c2.279.4 2.431 1.519 2.925 3.8a18.408 18.408 0 0 1 .585 5.561l-1.7 13.379.585 15.4c-3.67 4-18.348 5.273-26.363-.577 0 0 .084-25.307.456-29.364.646-7.1 3.859-9.618 8.585-9.6l8.076.684Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2853",
    d: "M128.062 182.745a7.157 7.157 0 1 1-2.077-5.08 7.172 7.172 0 0 1 2.077 5.08Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2854",
    d: "m130.311 184.143 1.519-4.11a2.712 2.712 0 0 1 2.226.76c.95.98.41 4.042-.76 7.035a61.8 61.8 0 0 1-1.656 6.351 2.446 2.446 0 0 1-1.428 1.147Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2855",
    d: "M130.425 188.101c.441.266 1.064-.577 1.611-1.14a1.907 1.907 0 0 1 3.183.524c.9 1.9-.76 4.391-2.18 4.824-2.4.76-2.758-.76-2.758-.76l-.175 8.608a7.711 7.711 0 0 1-5.835 4.4c-4.247.562-3.358-2.94-1.96-4.65v-2.636a15.013 15.013 0 0 1-3.229.16c-1.763-.281-2.864-1.679-3.4-3.586-.843-3.039-1.162-5.546-.418-11.563.821-6.61 8.509-6.648 12.65-4.019s2.511 9.838 2.511 9.838Z",
    fill: "#ffbda7"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2856",
    d: "M130.379 188.678c.691-.2 1.2-1.307 1.656-1.717.76-.684-.2-6.929-.2-6.929a2.94 2.94 0 0 0-.714-3.153c-1.033-1.147-2.765-1.276-5.728-1.755-1.459-.236-3.176-.349-4.619-.615a14.435 14.435 0 0 1-4.3-1.406 1.3 1.3 0 0 0-.821-.213.76.76 0 0 0-.517.433 1.376 1.376 0 0 0-.122.676 2.523 2.523 0 0 0 .122.76c.046.144.327.562.266.684-.144.3-1.284-.205-1.519-.274a.251.251 0 0 0-.167 0c-.046 0-.068.061-.091.106a2.758 2.758 0 0 0 .129 2.393 8.122 8.122 0 0 0 4.072 3.464 11.267 11.267 0 0 0 5.546.76 10.545 10.545 0 0 0 2.37-.555 6.7 6.7 0 0 0 .517.813 4.049 4.049 0 0 0 .76.676 3.26 3.26 0 0 0 .919.425c.342.091.661.046.851.41a1.71 1.71 0 0 1 .137.76l.068 2.279a3.874 3.874 0 0 0 .152 1.147 1.269 1.269 0 0 0 .76.813.76.76 0 0 0 .471.015Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2857",
    d: "M122.288 197.271a27.889 27.889 0 0 0 5.318-1.519 4.558 4.558 0 0 0 1.907-1.877 6.138 6.138 0 0 1-1.086 2.218c-1.01 1.284-6.139 2.211-6.139 2.211Z",
    fill: "#f0997a"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2858",
    d: "M122.873 186.908a.76.76 0 1 0 .76-.813.8.8 0 0 0-.76.813Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2859",
    d: "m123.815 184.5 1.747 1.132a1.094 1.094 0 0 0-.327-1.519 1.01 1.01 0 0 0-1.421.387Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2860",
    d: "m124.187 191.702-2.773 1.193a1.519 1.519 0 0 0 2.036.805 1.474 1.474 0 0 0 .737-2Z",
    fill: "#f0997a"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2861",
    d: "m115.671 185.344 1.664-1.01a.934.934 0 0 0-1.307-.349 1.018 1.018 0 0 0-.357 1.359Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2862",
    d: "M116.294 186.666a.787.787 0 0 0 1.573 0 .76.76 0 0 0-.76-.821.805.805 0 0 0-.813.821Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2863",
    d: "m120.685 186.24-.669 5.029-2.568-1.1Z",
    fill: "#f0997a"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2864",
    d: "M115.784 238.382v1.717a.524.524 0 0 1-.691.509 10.051 10.051 0 0 1-1.907-.76 4.49 4.49 0 0 1-1.406-1.132l-.084-2.614Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2865",
    d: "M111.701 236.086c.965 1.565 4.087 2.279 4.087 2.279s-.068-1.124 0-7.3.3-17.626 1.649-22.792a27.647 27.647 0 0 1 3.556-7.916 1.6 1.6 0 0 1 1.246-.76v-.3c-4.665-.076-5.622.4-7.6 2.872s-2.363 7.142-2.6 12.422c-.167 5.115-1.687 17.633-.338 21.495Zm14.7-13.485c-.372 14.177.539 21.235.707 22.39 0 0 10.515-.4 13.06-3.844-.3-4.467-.7-12.475-.972-17.535l1.52-17.307a5.6 5.6 0 0 0-3.229-5.569l-7.324-.957c-.615 1.428-1.991 3.29-2.659 6.078-.84 3.608-.903 8.767-1.103 16.743Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2866",
    d: "M122.281 198.874a6.078 6.078 0 0 0-3.662 2.188 21.22 21.22 0 0 0-2.727 5.037 1.953 1.953 0 0 0 .4 1.892s-1.383 3.51-1.155 5.2a18.181 18.181 0 0 0 1.132 3.8s1.778-10.492 3.442-13.675c1.755-3.411 2.56-3.4 2.56-3.4Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2867",
    d: "M130.106 198.935c1.026.243 3.692 1.314 3.692 1.314s-2.4 5.569-3.244 7a3.67 3.67 0 0 1-2.082 1.732 22.793 22.793 0 0 1 .205 4.923 26.5 26.5 0 0 1-2.188 5.463 36.6 36.6 0 0 1 .577-12.748 20.285 20.285 0 0 1 3.039-6.838Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2868",
    d: "m92.377 221.036 19.67 1.352 3.715 22.6-18.659-1.778Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2869",
    d: "m92.377 221.036 19.67 1.352 3.715 22.6-18.659-1.778Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2870",
    d: "M107.633 235.668c-.122.448.182 1.094 1.079 1.854.714.615 1.185 1.687 2.416 1.983a8.281 8.281 0 0 0 3.8.258l-.5-3.092Z",
    opacity: 0.15
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2871",
    d: "M97.946 223.393a3.143 3.143 0 0 0-.1-.7c-.1-.387 1.132-.615 2.644-.517l2.9.182c1.519.1 2.788.494 2.841.874l.1.7Z",
    opacity: 0.15
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2872",
    d: "M96.814 220.899c-.038-.243.448-.4 1.079-.342l1.147.091s-.205-1.519 2.355-1.436 2.955 1.755 2.955 1.755l1.223.114c.676.061 1.269.3 1.33.532l.106.425-10.135-.691s-.029-.205-.06-.448Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2873",
    d: "M98.197 221.423c.927.046 1.314.091 1.4.684s.114 1.185.114 1.185l4.482.312s-.137-.851-.175-1.193.137-.57.851-.524l.091-.289-7.035-.418Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2874",
    d: "M97.817 223.482s-.046-.311-.1-.7 1.132-.615 2.644-.517l2.9.182c1.519.1 2.781.494 2.834.874l.1.7Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2875",
    d: "M113.292 230.008a46.365 46.365 0 0 1 4.748.76 6.077 6.077 0 0 0 1.892.106 9.115 9.115 0 0 0 1.519-.3c1.717-.76 15.446-6.4 15.446-6.4l-2.332-13.508s-.547-8.676 3.236-9.588c2.917 1.322 3.844 3.89 5.181 9.6 1.519 6.534 2.712 14.162 2.1 16.228-.41 1.428-.494 2.955-3.677 4.186-3.366 1.307-7.119 2.188-18.234 5.364a54.974 54.974 0 0 1-6.367 1.816c-5.652.889-7.909-.137-9.033-2.325-.327-.631-.372-1.337-.669-1.983a4.558 4.558 0 0 1-.463-1.086.828.828 0 0 1 .471-.965 1.3 1.3 0 0 1 .539 0c.9.175 1.785.349 2.682.471a17.725 17.725 0 0 0 3.107.114.592.592 0 0 0 .16 0c.152-.068.114-.129 0-.182",
    fill: "#ffbda7"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2876",
    d: "M137.491 200.736c2.629.327 4.353 2.53 4.908 5.128.874 4.08 1.284 6.412 2.279 11.578.912 4.7 1.269 10.044.684 11.51s-3.578 2.431-5.463 2.986c-2.811.836-11.168 2.91-11.168 2.91.061-1.96-1.056-5.318-2.773-6.481l10.545-4.688-2.7-11.981s-1.167-8.721 3.688-10.962Z",
    fill: "#37474f"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--table--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--table--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2877",
    d: "m72.647 405.197-1.436-.828V346.15l1.436.828Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2878",
    d: "m72.647 405.197 1.436-.828V346.15l-1.436.828Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2879",
    d: "m110.74 369.048-1.436-.828v-42.439l1.436.828Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2880",
    d: "m110.74 369.049 1.436-.858v-42.432l-1.436.851Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2881",
    d: "m112.177 325.781-39.53 22.846v-1.656l39.53-22.846Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2882",
    d: "m149.548 361.436-1.428-.8-.517-56.973 1.436.8Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2883",
    d: "m149.548 361.436 1.436-.8-.509-56.965-1.436.79Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2884",
    d: "m150.475 303.666-39.742 22.982v-1.656l39.742-22.952Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2885",
    d: "m149.123 320.053-38.306 22.146-.008-1.6 38.314-22.146Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2886",
    d: "M110.741 339.047 74.083 360.16v1.649l36.658-21.166",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2887",
    d: "m112.176 339.821 36.863-21.318v-1.626l-36.863 21.288",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2888",
    d: "m110.816 342.199-38.169 22.04v-1.6l38.162-22.033Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2889",
    d: "m110.953 373.98 86.664 49.923v-4.809l-86.664-50.045Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2890",
    d: "m72.647 351.787 39.742 22.937v-4.806l-39.742-22.94Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2891",
    d: "m197.616 477.304-1.428-.828v-58.211l1.428.836Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2892",
    d: "m197.617 477.304 1.436-.828v-58.204l-1.436.828Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2893",
    d: "m235.71 455.485-1.428-.828v-56.753l1.428.828Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2894",
    d: "m235.71 455.484 1.436-.851v-56.76l-1.436.859Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2895",
    d: "m237.146 400.988-39.529 22.914v-4.809l39.529-22.845Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2896",
    d: "m274.008 433.338-1.428-.79v-56.76l1.428.8Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2897",
    d: "m274.009 433.338 1.436-.79v-56.753l-1.436.79Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2898",
    d: "m275.444 378.88-39.734 22.842v-4.612l39.734-22.944Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2899",
    d: "m274.092 392.175-38.306 22.147v-1.6l38.306-22.146Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2900",
    d: "m235.718 411.169-36.665 21.113v1.649l36.658-21.166",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2901",
    d: "m237.146 411.944 36.87-21.314V389l-36.87 21.288",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2902",
    d: "m235.786 414.326-38.169 22.04v-1.611l38.169-22.029Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2903",
    d: "m197.617 419.1 77.828-44.939-126.406-72.942-77.828 44.931Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2904",
    d: "m197.617 419.1 77.828-44.939-126.406-72.942-77.828 44.931Z",
    fill: "#fff",
    opacity: 0.8
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2905",
    d: "M197.616 477.306v-.76l-1.428-.828v.76Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2906",
    d: "M197.617 477.306v-.76l1.436-.828v.76Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2907",
    d: "M235.718 455.484v-.767l-1.436-.828v.767Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2908",
    d: "M235.718 455.484v-.767l1.428-.828v.767Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2909",
    d: "M274.008 433.338v-.76l-1.428-.828v.76Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2910",
    d: "M274.009 433.338v-.76l1.436-.828v.76Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2911",
    d: "M72.647 405.197v-.76l-1.436-.828v.76Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2912",
    d: "M72.647 405.197v-.76l1.436-.828v.76Z",
    fill: "#263238"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2913",
    d: "m209.963 341.888 8.471 4.437.175.273v.22a.3.3 0 0 1-.175.273l-11.161 6.45a.63.63 0 0 1-.3.068.6.6 0 0 1-.289-.068l-8.281-4.786v-.22Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2914",
    d: "M206.977 353.413a.631.631 0 0 0 .3-.068l11.161-6.45a.3.3 0 0 0 .175-.273.312.312 0 0 0-.175-.273l-8.1-4.672-11.931 6.881 8.281 4.786a.6.6 0 0 0 .289.069Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2915",
    d: "m210.335 341.007 8.008 4.627.084.114v.859a.137.137 0 0 1-.084.114l-11.161 6.443a.471.471 0 0 1-.4 0l-8.008-4.627v-.859Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2916",
    d: "m198.772 347.7.106.061 1.3.76.243.137 6.359 3.67a.418.418 0 0 0 .4 0l11.161-6.443a.122.122 0 0 0 0-.228l-.106-.091-7.9-4.558-11.464 6.617Z",
    fill: "#f0f0f0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2917",
    d: "M206.977 352.403v.859a.456.456 0 0 0 .205-.046l11.161-6.45a.137.137 0 0 0 .084-.114v-.859a.145.145 0 0 1-.084.114l-11.161 6.443a.38.38 0 0 1-.205.053Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2918",
    d: "m198.772 347.586 1.443.836.228.129 6.336 3.654a.418.418 0 0 0 .4 0l9.991-5.766.258-.144a2.553 2.553 0 0 0 .805-.729v-.061a.182.182 0 0 0-.144-.205 3.531 3.531 0 0 1-.76-.311l-7.037-4.066Z",
    fill: "#fff"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2919",
    d: "M200.268 347.488a.114.114 0 0 1 0 .213.4.4 0 0 1-.372 0c-.106-.061-.106-.152 0-.213a.4.4 0 0 1 .372 0Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2920",
    d: "M198.817 347.366a1.616 1.616 0 0 0 0 .19l.129-.076a.578.578 0 0 1 0-.114.5.5 0 0 1 .19-.456.258.258 0 0 1 .129 0 .44.44 0 0 1 .228.068 1.39 1.39 0 0 1 .562.805h.137a1.519 1.519 0 0 0-.631-.9.471.471 0 0 0-.494-.038.631.631 0 0 0-.25.521Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2921",
    d: "M198.84 347.624Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2922",
    d: "M201.385 346.842a.114.114 0 0 1 0 .213.4.4 0 0 1-.372 0 .114.114 0 0 1 0-.213.4.4 0 0 1 .372 0Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2923",
    d: "M199.934 346.72a1.59 1.59 0 0 0 0 .19l.129-.076v-.114a.5.5 0 0 1 .19-.456.266.266 0 0 1 .137-.038.486.486 0 0 1 .228.068 1.382 1.382 0 0 1 .555.805h.137a1.519 1.519 0 0 0-.623-.9.486.486 0 0 0-.5-.038.631.631 0 0 0-.253.559Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2924",
    d: "M202.502 346.196c.106.053.106.152 0 .213a.4.4 0 0 1-.372 0c-.1-.061-.1-.16 0-.213a.4.4 0 0 1 .372 0Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2925",
    d: "M201.051 346.074a1.746 1.746 0 0 0 0 .19l.129-.076v-.114a.517.517 0 0 1 .182-.456.311.311 0 0 1 .16-.053.486.486 0 0 1 .228.068 1.39 1.39 0 0 1 .562.805h.137a1.519 1.519 0 0 0-.631-.9.486.486 0 0 0-.5 0 .638.638 0 0 0-.266.539Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2926",
    d: "M203.626 345.565c.1.053.1.152 0 .213a.4.4 0 0 1-.372 0c-.106-.061-.106-.16 0-.213a.4.4 0 0 1 .372 0Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2927",
    d: "M202.175 345.429a.837.837 0 0 0 0 .19l.129-.076a.583.583 0 0 1 0-.114.5.5 0 0 1 .19-.456.259.259 0 0 1 .129-.038.463.463 0 0 1 .228.068 1.39 1.39 0 0 1 .562.805h.137a1.519 1.519 0 0 0-.631-.9.471.471 0 0 0-.494-.038.623.623 0 0 0-.25.559Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2928",
    d: "M204.746 344.904c.1.053.1.152 0 .213a.4.4 0 0 1-.372 0c-.106-.061-.106-.16 0-.213a.4.4 0 0 1 .372 0Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2929",
    d: "M203.292 344.805a1.745 1.745 0 0 0 0 .19l.129-.076a.578.578 0 0 1 0-.114.5.5 0 0 1 .19-.456.266.266 0 0 1 .137-.038.486.486 0 0 1 .228.068 1.421 1.421 0 0 1 .555.805.4.4 0 0 0 .137 0 1.58 1.58 0 0 0-.623-.9.486.486 0 0 0-.5-.038.623.623 0 0 0-.253.559Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2930",
    d: "M205.86 344.259c.106.053.106.152 0 .213a.4.4 0 0 1-.372 0c-.1-.061-.1-.16 0-.213a.4.4 0 0 1 .372 0Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2931",
    d: "M204.41 344.137a1.737 1.737 0 0 0 0 .19l.129-.076v-.114a.5.5 0 0 1 .19-.456.281.281 0 0 1 .137 0 .486.486 0 0 1 .228.068 1.428 1.428 0 0 1 .562.805.432.432 0 0 0 .137 0 1.52 1.52 0 0 0-.631-.9.486.486 0 0 0-.5-.038.638.638 0 0 0-.251.517Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2932",
    d: "M206.976 343.613c.106.053.106.152 0 .213a.388.388 0 0 1-.365 0c-.106-.061-.106-.16 0-.213a.388.388 0 0 1 .365 0Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2933",
    d: "M205.533 343.491a1.671 1.671 0 0 0 0 .19l.137-.076a.573.573 0 0 1 0-.114.517.517 0 0 1 .182-.456.311.311 0 0 1 .137-.038.486.486 0 0 1 .228.068 1.391 1.391 0 0 1 .562.805h.137a1.52 1.52 0 0 0-.631-.9.486.486 0 0 0-.5-.038.638.638 0 0 0-.252.559Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2934",
    d: "M208.101 342.967c.1.053.1.152 0 .213a.4.4 0 0 1-.372 0c-.106-.061-.106-.16 0-.213a.4.4 0 0 1 .372 0Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2935",
    d: "M206.65 342.845a.836.836 0 0 0 0 .19l.129-.076a.578.578 0 0 1 0-.114.5.5 0 0 1 .19-.456.258.258 0 0 1 .129-.038.44.44 0 0 1 .228.068 1.39 1.39 0 0 1 .562.805.4.4 0 0 0 .137 0 1.572 1.572 0 0 0-.631-.9.486.486 0 0 0-.494 0 .623.623 0 0 0-.25.521Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2936",
    d: "M209.218 342.313a.122.122 0 0 1 0 .22.4.4 0 0 1-.372 0 .122.122 0 0 1 0-.22.456.456 0 0 1 .372 0Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2937",
    d: "M207.767 342.199a1.746 1.746 0 0 0 0 .19l.129-.076a.578.578 0 0 1 0-.114.5.5 0 0 1 .19-.456.266.266 0 0 1 .137-.038.486.486 0 0 1 .228.068 1.383 1.383 0 0 1 .555.805.4.4 0 0 0 .137 0 1.565 1.565 0 0 0-.623-.9.5.5 0 0 0-.5 0 .623.623 0 0 0-.253.521Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2938",
    d: "M210.335 341.667a.114.114 0 0 1 0 .22.4.4 0 0 1-.372 0 .122.122 0 0 1 0-.22.456.456 0 0 1 .372 0Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2939",
    d: "M208.884 341.554a1.737 1.737 0 0 0 0 .19l.129-.076v-.114a.517.517 0 0 1 .182-.456.312.312 0 0 1 .137-.038.486.486 0 0 1 .228.068 1.39 1.39 0 0 1 .562.805h.137a1.573 1.573 0 0 0-.631-.9.5.5 0 0 0-.5 0 .638.638 0 0 0-.243.524Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2940",
    d: "M208.102 351.165a.221.221 0 0 1-.122 0l-6.161-3.556a.243.243 0 0 1-.084-.319.236.236 0 0 1 .319-.091l6.161 3.563a.228.228 0 0 1 .084.319.235.235 0 0 1-.2.084Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2941",
    d: "M208.846 350.731a.242.242 0 0 1-.122 0l-6.154-3.556a.236.236 0 1 1 .236-.4l6.154 3.556a.21.21 0 0 1-.114.4Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2942",
    d: "M209.592 350.306a.2.2 0 0 1-.114-.038l-6.161-3.556a.228.228 0 0 1-.084-.319.243.243 0 0 1 .319-.084l6.154 3.556a.236.236 0 0 1-.114.441Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2943",
    d: "M210.335 349.873a.212.212 0 0 1-.114 0l-6.162-3.548a.228.228 0 0 1-.084-.319.236.236 0 0 1 .319-.091l6.161 3.556a.236.236 0 0 1-.122.441Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2944",
    d: "M211.079 349.44a.213.213 0 0 1-.114 0l-6.161-3.556a.243.243 0 0 1-.084-.319.228.228 0 0 1 .319-.084l6.161 3.556a.236.236 0 0 1-.122.433Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2945",
    d: "M211.832 349.014a.228.228 0 0 1-.122-.038l-6.161-3.556a.243.243 0 0 1-.084-.319.236.236 0 0 1 .319-.084l6.161 3.556a.236.236 0 0 1-.114.441Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2946",
    d: "M212.577 348.604a.243.243 0 0 1-.122 0l-6.154-3.556a.236.236 0 0 1 .228-.41l6.161 3.556a.235.235 0 0 1-.114.441Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2947",
    d: "M213.321 348.148a.2.2 0 0 1-.114 0l-6.162-3.556a.236.236 0 0 1 .236-.4l6.154 3.556a.21.21 0 0 1-.114.4Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2948",
    d: "M214.065 347.715a.213.213 0 0 1-.114 0l-6.161-3.556a.228.228 0 0 1-.084-.319.236.236 0 0 1 .319-.084l6.161 3.556a.243.243 0 0 1 .084.319.235.235 0 0 1-.205.084Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2949",
    d: "M214.81 347.29a.32.32 0 0 1-.114 0l-6.161-3.556a.243.243 0 0 1-.084-.319.235.235 0 0 1 .319-.091l6.162 3.556a.235.235 0 0 1 .084.319.243.243 0 0 1-.206.091Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2950",
    d: "M215.562 346.857a.221.221 0 0 1-.122 0l-6.162-3.571a.243.243 0 0 1-.084-.319.228.228 0 0 1 .319-.084l6.161 3.556a.228.228 0 0 1 .084.319.22.22 0 0 1-.196.099Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2951",
    d: "M216.306 346.424a.243.243 0 0 1-.122 0l-6.154-3.556a.235.235 0 0 1-.091-.319.228.228 0 0 1 .319-.084l6.161 3.556a.228.228 0 0 1 .084.319.22.22 0 0 1-.197.084Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2952",
    d: "M217.051 345.998a.281.281 0 0 1-.114 0l-6.161-3.563a.228.228 0 0 1-.084-.319.243.243 0 0 1 .319-.084l6.154 3.556a.236.236 0 0 1-.114.441Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2953",
    d: "M207.341 351.597a.28.28 0 0 1-.114 0l-6.519-3.8a.236.236 0 0 1-.084-.327.243.243 0 0 1 .319-.084l6.511 3.8a.236.236 0 0 1-.114.441Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 215",
    opacity: 0.25,
    fill: "#455a64"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2954",
    d: "M204.234 346.93a1 1 0 0 0 .312-.327.274.274 0 0 1 .144 0c.175 0 0 .091 0 .16v.038c0-.008.433-.091.349.114.038 0 .213.038.19.084s0 .038 0 .038a3.426 3.426 0 0 1 .4 0h.182a.166.166 0 0 1-.046.19v.038c.068.038.122.076.076.144s0 .046 0 .046c.167.053.471-.091.524.114s0 .152.16.137c0 0 .053-.053 0-.053-.167 0-.046-.19-.137-.251s-.319.061-.418 0 0-.068-.046-.144-.053 0-.068 0v-.1c.038-.19-.266-.144-.387-.152a2.065 2.065 0 0 1-.228 0v-.053l-.182-.068s.038-.076 0-.114a.479.479 0 0 0-.342 0h-.061a.053.053 0 0 0 .053-.053v-.068c0-.068-.061-.061-.114-.068a.3.3 0 0 0-.16 0 .357.357 0 0 0 0-.175c-.046-.182-.258-.046-.365 0s0 .061 0 .053a.548.548 0 0 1 .243-.068c.061.015 0 .167-.038.258l-.122.061a.593.593 0 0 0-.251.16.288.288 0 0 0 .332.059Zm.068-.2.091-.053a.425.425 0 0 1-.16.167s-.129.053-.091 0a.311.311 0 0 1 .16-.114Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2955",
    d: "M206.885 348.407c.144.046.281-.129.334-.3.046 0 .167 0 .182.061v.084c.076 0 .327-.091.289.046s.213 0 .236.068-.091.091-.038.16.114 0 .16 0h.091c.03 0 0 0 0 .053s0 .038.038.046a.249.249 0 0 0 .076 0h.152s.137.061.129.038-.068.106 0 .167.258 0 .319 0 .046-.068 0-.068h-.152c-.129-.053-.091-.1-.068-.16v-.031c-.091 0-.152-.076-.213-.076s-.091.038-.106.038-.053 0-.053-.1h-.036c-.061 0-.213.137-.213 0a.346.346 0 0 0 .068-.091c.008-.03 0-.084-.084-.091a.6.6 0 0 0-.122 0c-.16 0 0 0-.084-.046s-.061-.046-.152-.046h-.1c-.084 0 0 0 0-.061v-.114c0-.046-.068-.068-.144-.053l-.137.046c0-.122 0-.213-.129-.213s-.061.053 0 .061.084.106.061.2a.532.532 0 0 0-.304.382Zm.144-.1a.388.388 0 0 1 .1-.106s-.13.191-.104.107Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2956",
    d: "M205.077 349.129a.965.965 0 0 0 .311-.319.417.417 0 0 1 .137 0c.182 0 0 .1 0 .167v.038s.433-.1.349.106v.038s.213.038.19.076 0 .038 0 .038a3.4 3.4 0 0 1 .4 0h.182c.038.046 0 .152-.046.182v.046a.091.091 0 0 1 .076.144c-.046.076 0 .038 0 .046.175.046.479-.091.524.106s0 .16.167.144c0 0 .053-.053 0-.053-.167 0-.046-.19-.137-.258s-.319.061-.418 0 0-.076-.046-.144-.061 0-.068 0v-.1c.038-.19-.266-.137-.387-.152a1.142 1.142 0 0 1-.228 0v-.053l-.182-.076s.038-.068 0-.106a.89.89 0 0 0-.334-.046h-.061a.056.056 0 0 0 .053-.053.248.248 0 0 0 0-.076c0-.038-.061-.061-.114-.068a.707.707 0 0 0-.167 0 .281.281 0 0 0 0-.167c-.046-.19-.258-.053-.365 0s-.038.061 0 .053a.814.814 0 0 1 .243-.076c.1 0 0 .167 0 .258l-.122.061a.607.607 0 0 0-.251.167.213.213 0 0 0 .294.077Zm.068-.2.091-.046a.479.479 0 0 1-.16.167s-.129.046-.091 0a.319.319 0 0 1 .161-.119Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2957",
    d: "M202.76 347.754c.144.046.281-.129.334-.3.053 0 .167 0 .182.061v.084c.076 0 .334-.091.289.046.061.046.205 0 .228.068s-.091.091 0 .16.114 0 .167 0 .053-.038.084 0 0 0 0 .046 0 .038.038.053h.228s.144.061.129.038-.068.106 0 .16.258 0 .319 0 .053-.061 0-.061h-.152c-.129-.061-.091-.1-.068-.16s0-.038 0-.038a.672.672 0 0 0-.213-.084l-.106.046c-.1 0-.053 0-.053-.106s0 0-.038 0-.205.144-.213 0c0 0 .068-.053.068-.084a.085.085 0 0 0-.076-.1.359.359 0 0 0-.129 0c-.16 0 0 0-.084-.046a.137.137 0 0 0-.144-.046.543.543 0 0 1-.106 0c-.084 0 0 0 0-.053v-.114c0-.046-.068-.076-.144-.061l-.137.046c0-.114 0-.213-.129-.205s-.061.053 0 .061.084.106.061.2c-.198.161-.327.275-.335.389Zm.137-.106a.341.341 0 0 1 .106-.1v.038s-.137.145-.106.061Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2958",
    d: "M208.784 344.41a1.079 1.079 0 0 0 .311-.327.266.266 0 0 1 .137 0c.182 0 0 .091 0 .16 0-.046.433-.091.349.114.038 0 .213.038.19.084s0 .038 0 .038a3.412 3.412 0 0 1 .4 0h.182a.166.166 0 0 1-.046.19c-.046.038 0 0 0 .038s.122.076.076.144 0 .046 0 .046c.175.053.479-.091.524.114s0 .152.167.137c0 0 .053-.053 0-.053-.167 0-.046-.19-.137-.251s-.319.053-.418 0 0-.068-.046-.144-.061 0-.068 0v-.1c.038-.19-.266-.144-.387-.152a2.072 2.072 0 0 1-.228 0v-.053l-.182-.068s.038-.076 0-.114a.459.459 0 0 0-.334 0h-.061a.068.068 0 0 0 .053-.053v-.068c0-.068-.061-.068-.114-.068a.342.342 0 0 0-.167 0 .3.3 0 0 0 0-.175c-.046-.182-.258-.046-.365 0s-.038.061 0 .053.182-.084.243-.068 0 .167 0 .258l-.122.061a.592.592 0 0 0-.251.16.2.2 0 0 0 .294.097Zm.068-.2.091-.053a.478.478 0 0 1-.16.167s-.129.053-.091 0a.312.312 0 0 1 .16-.114Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2959",
    d: "M211.436 345.892c.144.046.281-.129.327-.3.053 0 .175 0 .19.061v.084c.076 0 .327-.091.289.046s.213 0 .236.068-.091.091 0 .16.114 0 .16 0h.091c.03 0 0 .038 0 .053s0 .038.038.046a.252.252 0 0 0 .076 0h.152s.137.061.122.038-.061.106 0 .167.258 0 .311 0a.035.035 0 1 0 0-.068h-.142c-.129-.053-.1-.1-.068-.16s0-.038 0-.038a.731.731 0 0 0-.205-.076.831.831 0 0 0-.106.038c-.106 0-.053 0-.053-.1s0 0-.038 0-.213.137-.213 0a.346.346 0 0 0 .068-.091c.008-.03 0-.084-.084-.091a.6.6 0 0 0-.122 0c-.167 0 0 0-.084-.046s-.061-.046-.152-.046a.431.431 0 0 1-.1 0c-.091 0 0 0 0-.053v-.114c0-.046-.068-.068-.144-.053a.411.411 0 0 0-.137.046c0-.122 0-.213-.129-.213s-.061.053 0 .061.084.106.061.2a.532.532 0 0 0-.344.381Zm.144-.106a.388.388 0 0 1 .1-.1s-.13.191-.1.1Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2960",
    d: "M209.628 346.614a.965.965 0 0 0 .311-.319.418.418 0 0 1 .137 0c.182 0 0 .1 0 .167l.038.038c.129 0 .433-.1.349.106v.038c.038 0 .213.038.19.076a3.574 3.574 0 0 1 .4 0h.182c0 .046 0 .152-.046.182v.046a.091.091 0 0 1 .076.144v.046c.175.046.479-.1.524.106s0 .16.167.144c0 0 .053-.053 0-.061-.167 0-.046-.182-.137-.251s-.319.061-.425 0 0-.076-.038-.152-.061 0-.068 0a.169.169 0 0 0 0-.046v-.053c0-.19-.266-.137-.4-.152a1.066 1.066 0 0 1-.22 0v-.053l-.182-.076s.038-.068 0-.106a.89.89 0 0 0-.334-.046h-.061a.056.056 0 0 0 .053-.053.249.249 0 0 0 0-.076c0-.038-.068-.061-.114-.068a.457.457 0 0 0-.167 0 .281.281 0 0 0 0-.167c-.046-.19-.258-.053-.365 0s-.038.061 0 .053a.758.758 0 0 1 .243-.076c.1 0 0 .167-.038.258l-.122.061a.562.562 0 0 0-.251.167.191.191 0 0 0 .298.123Zm.061-.2.1-.046a.478.478 0 0 1-.16.167s-.129.046-.1 0a.41.41 0 0 1 .16-.122Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2961",
    d: "M207.303 345.239c.144.046.281-.129.334-.3.053 0 .167 0 .182.061a.509.509 0 0 0 0 .084c.076 0 .334-.091.289.046.068.046.213 0 .236.068s-.091.091 0 .16.114 0 .16 0 .061-.038.091 0 0 0 0 .046 0 .038.038.053h.228s.137.061.129.038-.068.106 0 .16.258 0 .319 0 .046-.061 0-.061h-.152c-.129-.061-.091-.1-.068-.16s0-.046 0-.038a1.108 1.108 0 0 0-.213-.084l-.106.046c-.1 0-.053-.038-.053-.106s0 0-.038 0-.205.144-.213 0c0 0 .061-.053.068-.084s0-.084-.084-.1a.342.342 0 0 0-.122 0c-.16 0 0 0-.084-.046a.137.137 0 0 0-.144-.046.538.538 0 0 1-.106 0c-.084 0 0 0 0-.053v-.114c0-.046-.068-.076-.144-.061l-.137.046c0-.114 0-.213-.129-.205s-.061.053 0 .061.084.106.061.2c-.198.161-.327.275-.342.389Zm.144-.106a.389.389 0 0 1 .1-.1.061.061 0 0 1 0 .038s-.13.145-.1.061Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2962",
    d: "M209.157 348.133a.934.934 0 0 0 .319-.327.251.251 0 0 1 .137 0c.182 0 0 .1 0 .167v.038s.425-.1.342.106v.038c.038 0 .213.038.2.076a3.412 3.412 0 0 1 .4 0 .666.666 0 0 1 .182 0c.046.046 0 .152-.038.182v.046a.091.091 0 0 1 .076.144v.046c.167.046.471-.1.524.106s0 .16.167.144c0 0 .046-.061 0-.061-.16 0-.038-.182-.137-.251s-.319.061-.418 0 0-.068-.046-.144-.053 0-.068 0a.16.16 0 0 1 0-.046v-.053c.038-.19-.266-.144-.387-.152a1.142 1.142 0 0 1-.228 0v-.053l-.182-.076s.038-.068 0-.106a.932.932 0 0 0-.342-.046h-.061a.052.052 0 0 0 .053-.053v-.076c0-.03-.061-.061-.114-.068a.4.4 0 0 0-.16 0 .273.273 0 0 0 0-.167c-.046-.19-.251-.053-.365 0s0 .061 0 .046a1.069 1.069 0 0 1 .243-.068c.1 0 0 .167 0 .258l-.122.061c-.091.046-.2.076-.251.167s.155.183.276.122Zm.068-.2.091-.046a.38.38 0 0 1-.16.167s-.129.046-.091 0a.41.41 0 0 1 .16-.122Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2963",
    d: "M207.235 346.895c.144.046.281-.129.334-.3.053 0 .167 0 .19.061a.757.757 0 0 1-.038.084c.084 0 .334-.091.289.046s.205 0 .228.068-.091.091-.038.16.114 0 .167 0h.091c.038 0 0 .038 0 .053v.046c0 .046.053 0 .076 0h.053a.38.38 0 0 1 .1 0s.144.061.129.038-.068.106 0 .167.258 0 .319 0 .053-.061 0-.061h-.152c-.129-.061-.091-.1-.068-.16s0-.038 0-.038a.547.547 0 0 0-.213-.076.35.35 0 0 0-.106.038c-.015 0-.053 0-.053-.106s-.205.137-.213 0 .068-.061.068-.091a.085.085 0 0 0-.076-.1.356.356 0 0 0-.129 0c-.16 0 0 0-.084-.046a.137.137 0 0 0-.144-.046.538.538 0 0 1-.106 0c-.084 0 0 0 0-.053v-.114c0-.046-.068-.068-.137-.061a.674.674 0 0 0-.144.053c0-.122 0-.213-.129-.213s-.061.053 0 .061.076.106.053.2-.259.283-.267.39Zm.137-.106a.341.341 0 0 1 .106-.1s-.137.182-.106.1Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2964",
    d: "M205.799 345.474a.372.372 0 0 1 0 .182s.334-.1.3 0v.038c.068.038.213-.038.228.068s-.084.091 0 .16.114 0 .16 0 .061-.046.091 0 0 0 0 .046v.046c0 .008.046 0 .076 0h.046a.243.243 0 0 1 .106 0s.137.068.122.038-.061.106 0 .167.258 0 .311 0 .053-.061 0-.061h-.16c-.129-.053-.1-.091-.076-.16v-.038c-.084 0-.144-.076-.213-.076h-.1c-.106 0-.053 0-.061-.1s-.213.144-.213 0a.345.345 0 0 0 .068-.091c.008-.03 0-.076-.084-.091a.379.379 0 0 0-.129 0h-.076a.167.167 0 0 0-.152-.053.228.228 0 0 1-.1 0c-.091 0 0 0-.038-.061s.038-.068 0-.114-.122-.114-.144 0v.038a.222.222 0 0 1 .038.062Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "freepik--shadow--inject-3",
    d: "M204.226 353.922c-.122.327-.471.524-1.048.608l-8.312-4.869-1.079-1.094a.084.084 0 0 1 .091-.137l1.983.661Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2965",
    d: "m195.786 348.315-1.77-.342a.061.061 0 0 0-.053.091l1.208 1.36Z",
    fill: "#ffa8a7"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2966",
    d: "M193.962 348.064a.061.061 0 0 1 .053-.091l.349.068a.3.3 0 0 0-.144.281Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2967",
    d: "m201.764 353.208-.144-.084-.175-.1-6.275-3.6a.912.912 0 0 1 .615-1.1l6.275 3.594.334.19c-.22-.108-.873.979-.63 1.1Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2968",
    d: "m201.21 352.889-.319-.182c-.1-.053-.046-.289.068-.532s.441-.631.562-.562l.243.137.084.046c-.129-.061-.418.251-.562.57s-.167.456-.084.517Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2969",
    d: "M201.134 352.843c-.22-.114.41-1.208.631-1.094l.327.19c-.22-.122-.859.972-.638 1.086Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2970",
    d: "m201.761 353.208-.319-.182c-.22-.114.387-1.178.615-1.109l.319.182c-.201-.099-.854.987-.615 1.109Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2971",
    d: "M193.925 348.003h.061l1.284.7 6.64 3.8c-.19.289-.327.661-.205.76l-.144-.084-.175-.1-6.276-3.6-1.2-1.36a.061.061 0 0 1 .015-.114Z",
    opacity: 0.15
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2972",
    d: "m203.117 353.982-1.352-.76c-.1-.053-.046-.281.068-.524s.433-.638.562-.577l1.36.76c.273.16 0 .76-.281 1a.327.327 0 0 1-.357.101Z",
    fill: "#f28f8f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2973",
    d: "M203.041 353.556a.988.988 0 0 1 .555-.669.213.213 0 0 1 .2 0c.205.19 0 .76-.319.972a.319.319 0 0 1-.349.091c-.087-.028-.14-.18-.087-.394Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2974",
    d: "m152.268 328.151 15.195-8.76a.858.858 0 0 1 .874 0l26.333 15.195a.2.2 0 0 1 0 .342l-15.324 8.843Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2975",
    d: "M153.4 326.305v.342a1.405 1.405 0 0 0 .7 1.216l24.532 14.162a1.345 1.345 0 0 0 .7.19 1.391 1.391 0 0 0 .707-.19l13.371-7.7a1.413 1.413 0 0 0 .7-1.216v-.463a.167.167 0 0 1-.084.152l-14.686 8.482Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2976",
    d: "m153.4 326.305 14.541-8.357a.821.821 0 0 1 .836 0l25.239 14.572a.182.182 0 0 1 0 .319l-14.686 8.479Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2977",
    d: "m179.464 340.042 7.841-4.52-22.935-13.243-7.886 4.5Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2978",
    d: "m156.484 326.777.3.175 7.59-4.331 22.64 13.075.3-.175-22.944-13.242Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2979",
    d: "m156.484 326.777.3.175 7.59-4.331 22.64 13.075.3-.175-22.944-13.242Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2980",
    d: "m183.319 327.46-.144.084-3.844 2.218-6.838-3.951-.144-.084 3.989-2.3Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2981",
    d: "m183.174 327.544-3.844 2.218-6.838-3.949 3.844-2.218Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2982",
    d: "M179.33 341.279v.935a1.345 1.345 0 0 1-.7-.19l-24.532-14.162a1.406 1.406 0 0 1-.7-1.216v-.342Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2983",
    d: "M179.33 341.279v.935a1.345 1.345 0 0 1-.7-.19l-24.532-14.162a1.406 1.406 0 0 1-.7-1.216v-.342Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2984",
    d: "M178.934 341.485a1.656 1.656 0 0 1-1.428-.106l-24.426-14.1a1.664 1.664 0 0 1-.805-1.162l-2.674-15.955a1.664 1.664 0 0 1 .463-1.451l25.384 14.654a1.215 1.215 0 0 1 .6.859Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2985",
    d: "m179.329 341.28-.167.1-.228.106-2.887-17.254a1.216 1.216 0 0 0-.6-.859l-25.383-14.656a1.445 1.445 0 0 1 .342-.258l25.429 14.678a1.246 1.246 0 0 1 .6.859Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2986",
    d: "m175.812 323.691.387-.22a1.132 1.132 0 0 1 .236.524l2.895 17.284-.167.1-.228.106-2.883-17.254a1.375 1.375 0 0 0-.236-.539Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2987",
    d: "M165.174 326.768a5.356 5.356 0 0 0-2.462-3.168c-1.178-.684-1.991-.372-1.808.7a5.379 5.379 0 0 0 2.462 3.168c1.179.676 1.992.364 1.808-.7Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 216",
    opacity: 0.1
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2988",
    d: "M162.874 393.041a1.3 1.3 0 0 0 .646-.167l18.249-10.545a.713.713 0 0 0 .03-1.269l-15.073-9.6a1.345 1.345 0 0 0-.707-.19 1.307 1.307 0 0 0-.653.167l-5.44 3.138a1 1 0 0 0-.387 1.307l.228.425a.19.19 0 0 1-.068.236l-10.959 6.378a.71.71 0 0 0-.023 1.269l13.44 8.653a1.292 1.292 0 0 0 .717.198Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2989",
    d: "m162.608 391.955-13.675-7.924c-.266-.152-.266-.4 0-.562l18.766-10.678a1.071 1.071 0 0 1 .972 0l13.561 7.825c.274.16.274.41 0 .562l-18.644 10.766a1.048 1.048 0 0 1-.98.008Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2990",
    d: "m182.24 380.604-15.4-9.785a1.033 1.033 0 0 0-.965 0l-5.546 3.206a.6.6 0 0 0-.236.76l.228.441a.6.6 0 0 1-.228.76l-11.176 6.5a.319.319 0 0 0 0 .593l13.675 8.828a1.01 1.01 0 0 0 .965 0l18.644-10.766a.311.311 0 0 0 .038-.539Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2991",
    d: "m196.12 387.412 17.049-9.839a.9.9 0 0 1 .874 0l20.863 12.012a.19.19 0 0 1 0 .334l-17.2 9.915Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2992",
    d: "M197.875 387.122a.38.38 0 0 0 .19.289l18.652 10.758a.388.388 0 0 0 .365 0l16.714-8.456v-.372l-18.994-10.971-16.714 8.456a.38.38 0 0 0-.213.3Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2993",
    d: "M216.892 397.842v.365a.5.5 0 0 1-.19-.038l-18.636-10.758a.319.319 0 0 1 0-.585c-.106.053-.106.152 0 .213l18.652 10.758a.387.387 0 0 0 .175.046Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2994",
    d: "m233.788 389.341-16.714 8.456a.418.418 0 0 1-.38 0l-18.636-10.758c-.106-.061-.106-.16 0-.213l16.714-8.456Z",
    opacity: 0.5
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2995",
    d: "M233.788 389.341v.372l-16.714 8.456a.388.388 0 0 1-.19.038v-.365a.388.388 0 0 0 .19-.046Z",
    opacity: 0.2
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2996",
    d: "m233.53 389.493-19.009-10.971v-4.885l19.009 11.024Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2997",
    d: "m233.53 389.493-19.009-10.971v-4.885l19.009 11.024Z",
    opacity: 0.7
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2998",
    d: "M198.111 384.494a.5.5 0 0 0-.235.4v.988a.524.524 0 0 0 .236.4l18.545 10.7a.5.5 0 0 0 .463 0l14.169-7.658v-1.52l-18.994-10.968Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 2999",
    d: "m212.28 376.828-14.169 7.666c-.129.068-.129.19 0 .266l18.545 10.7a.547.547 0 0 0 .463 0l14.169-7.666Z",
    fill: "#fafafa"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3000",
    d: "M229.48 387.921a.394.394 0 0 0 .159.053.471.471 0 0 0 .251 0h.076c.129-.068.114-.2 0-.281a.456.456 0 0 0-.22-.061.433.433 0 0 0-.266.038c-.16.068-.137.175 0 .251Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3001",
    d: "M216.891 395.51v1.52a.472.472 0 0 1-.236-.053l-18.553-10.69a.517.517 0 0 1-.228-.4v-1a.517.517 0 0 1 .175-.357c-.068.068-.053.16.053.228l18.553 10.7a.4.4 0 0 0 .236.052Z",
    fill: "#e6e6e6"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3002",
    d: "M231.965 385.831a.942.942 0 0 0-.965.053 3.3 3.3 0 0 0-1.307 1.945l.311.046a3.039 3.039 0 0 1 1.147-1.74.835.835 0 0 1 .4-.122.4.4 0 0 1 .236.068 1.185 1.185 0 0 1 .38 1.079 3.32 3.32 0 0 1-1.292 2.553.759.759 0 0 1-.479.114l-.342.2a.76.76 0 0 0 .4.106 1.147 1.147 0 0 0 .555-.16 3.616 3.616 0 0 0 1.451-2.819 1.52 1.52 0 0 0-.495-1.323Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3003",
    d: "M197.875 384.015a.38.38 0 0 0 .19.3l18.652 10.75a.388.388 0 0 0 .365 0l16.714-10.211v-.365l-18.994-10.981-16.714 10.22a.372.372 0 0 0-.213.289Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3004",
    d: "M216.891 394.735v.372a.387.387 0 0 1-.19-.046l-18.636-10.75a.38.38 0 0 1-.19-.3.4.4 0 0 1 .19-.3.114.114 0 0 0 0 .22l18.652 10.768a.388.388 0 0 0 .175.038Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3005",
    d: "m233.788 384.486-16.714 10.211a.494.494 0 0 1-.38 0l-18.636-10.758a.114.114 0 0 1 0-.22l16.714-10.211Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3006",
    d: "M233.788 384.486v.365l-16.714 10.211a.319.319 0 0 1-.19.046v-.372a.387.387 0 0 0 .19-.038Z",
    opacity: 0.2
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3007",
    d: "M233.788 389.349v-4.855l-.258.167v4.832Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3008",
    d: "M233.788 389.349v-4.855l-.258.167v4.832Z",
    opacity: 0.2
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3009",
    d: "M233.18 384.411a.3.3 0 0 0 .182-.251v-.377l-18.333-10.355a.98.98 0 0 0-.851 0l-16.455 9.524 18.994 10.963Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3010",
    d: "M233.18 384.411a.3.3 0 0 0 .182-.251v-.377l-18.333-10.355a.98.98 0 0 0-.851 0l-16.455 9.524 18.994 10.963Z",
    opacity: 0.2
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3011",
    d: "M233.18 384.038a.258.258 0 0 0 0-.494l-18.15-10.477a.934.934 0 0 0-.851 0l-16.456 9.513 18.994 10.971Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3012",
    d: "M233.18 384.038a.258.258 0 0 0 0-.494l-18.15-10.477a.934.934 0 0 0-.851 0l-16.456 9.513 18.994 10.971Z",
    opacity: 0.5
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3013",
    d: "m201.522 380.094 12.156-7.043a.935.935 0 0 1 .851 0l16.714 9.671 1.588-.927v1.877c.053.114 0 .243-.144.334l-13.972 8.061-18.994-10.97v-2.051Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3014",
    d: "M232.671 381.971c.236-.137.236-.357 0-.486l-18.158-10.484a.934.934 0 0 0-.851 0l-13.979 8.068 18.994 10.963Z",
    fill: "#fafafa"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3015",
    d: "M218.73 390.04v2.051l-19.016-10.971v-2.051Z",
    fill: "#e6e6e6"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3016",
    d: "M218.502 389.234a.561.561 0 0 0 .16.053.4.4 0 0 0 .251 0 .129.129 0 0 0 .076 0c.129-.068.114-.2 0-.281a.57.57 0 0 0-.22-.068.494.494 0 0 0-.266.046s-.138.174-.001.25Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3017",
    d: "M216.351 390.838a1.11 1.11 0 0 0 .213.714.76.76 0 0 0 .615.289 1.208 1.208 0 0 0 .593-.175l.106-.068-.235-.137c-.585.327-1.048.053-1.048-.623a2.325 2.325 0 0 1 1.056-1.823.691.691 0 0 1 .76-.038.547.547 0 0 1 .22.311.4.4 0 0 0 .251 0 .942.942 0 0 0-.175-.372.76.76 0 0 0-.615-.281 1.148 1.148 0 0 0-.593.175 2.56 2.56 0 0 0-1.148 2.028Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3018",
    d: "m216.96 388.87 16.4-8.015v.273a.486.486 0 0 1-.213.365l-16.19 7.749Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3019",
    d: "m216.96 388.87 16.4-8.015v.273a.486.486 0 0 1-.213.365l-16.19 7.749Z",
    opacity: 0.2
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3020",
    d: "M233.18 381.128a.258.258 0 0 0 0-.486l-18.15-10.484a.934.934 0 0 0-.851 0l-16.456 7.908 18.994 10.971Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3021",
    d: "M216.716 393.915 197.7 382.944v-4.885l19.016 10.978Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3022",
    d: "M216.716 393.915 197.7 382.944v-4.885l19.016 10.978Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3023",
    d: "M212.966 390.783a.76.76 0 0 0 .615-.289 1.17 1.17 0 0 0 .213-.714 2.591 2.591 0 0 0-1.178-2.044 1.23 1.23 0 0 0-.593-.175c-.5 0-.836.4-.836 1a2.6 2.6 0 0 0 1.185 2.044 1.231 1.231 0 0 0 .594.178Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3024",
    d: "M213.548 389.782c0 .676-.471.95-1.056.615a2.348 2.348 0 0 1-1.056-1.831c0-.676.471-.95 1.056-.608a2.325 2.325 0 0 1 1.056 1.824Z",
    fill: "#f5f5f5"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3025",
    d: "M209.711 387.351v.365c0 .76-.517 1.041-1.155.669l-8.243-4.756a2.576 2.576 0 0 1-1.162-2.006v-.349c0-.76.524-1.041 1.162-.669l8.243 4.756a2.568 2.568 0 0 1 1.155 1.991Z",
    fill: "#f5f5f5"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3026",
    d: "M216.968 393.771v-4.855l-.251.122v4.878Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3027",
    d: "M216.968 393.771v-4.855l-.251.122v4.878Z",
    opacity: 0.2
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "freepik--shadow--inject-3",
    d: "M202.67 339.024c1.793.988 1.793 2.6 0 3.594a7.438 7.438 0 0 1-6.5 0c-1.793-1-1.793-2.606 0-3.594a7.438 7.438 0 0 1 6.5 0Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3028",
    d: "M196.204 340.672a4.449 4.449 0 0 1 3.373-1.208h-.114c-1.519.023-2.818.509-3.259 1.208Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--coffee--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3029",
    d: "M196.636 333.143a9.451 9.451 0 0 1 5.713.152c1.519.631 1.519 1.588-.053 2.135a9.436 9.436 0 0 1-5.721-.144c-1.587-.631-1.565-1.588.061-2.143Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 217",
    opacity: 0.3
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3030",
    d: "M196.637 333.143a9.451 9.451 0 0 1 5.713.152c1.519.631 1.519 1.588-.053 2.135a9.436 9.436 0 0 1-5.721-.144c-1.587-.631-1.565-1.588.061-2.143Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3031",
    d: "m195.444 331.168 8.236.22-.874 9.687c-.053.349-.387.691-1.026.942a7.263 7.263 0 0 1-4.938-.122c-.646-.289-.98-.646-1.01-1Z",
    fill: "#fafafa"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3032",
    d: "m203.642 331.388-.186 1.968a3.442 3.442 0 0 1-.691.349 10.036 10.036 0 0 1-6.564-.167l-.213-.106a4.068 4.068 0 0 1-.509-.3l-.076-1.96Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3033",
    d: "m194.874 331.441.038-1.519h.965a2.757 2.757 0 0 1 .425-.182 9.991 9.991 0 0 1 6.557.167c.152.068.281.137.4.205h.927l-.038 1.52c0 .486-.471.957-1.368 1.307a9.96 9.96 0 0 1-6.557-.175c-.908-.345-1.357-.875-1.349-1.323Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 218",
    opacity: 0.2
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3034",
    d: "m194.874 331.441.038-1.519h.965a2.757 2.757 0 0 1 .425-.182 9.991 9.991 0 0 1 6.557.167c.152.068.281.137.4.205h.927l-.038 1.52c0 .486-.471.957-1.368 1.307a9.96 9.96 0 0 1-6.557-.175c-.908-.345-1.357-.875-1.349-1.323Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3035",
    d: "M196.333 328.66a9.99 9.99 0 0 1 6.557.167c1.763.76 1.732 1.975-.068 2.667a10.014 10.014 0 0 1-6.557-.167c-1.824-.782-1.793-1.983.068-2.667Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3036",
    d: "m195.778 329.611.334-1.216 2.355.061a9.27 9.27 0 0 1 2.34.061l2.279.053.266 1.231c.129.448-.228.9-1.1 1.223a8.57 8.57 0 0 1-5.409-.137c-.875-.35-1.232-.821-1.065-1.276Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3037",
    d: "m195.778 329.611.334-1.216 2.355.061a9.27 9.27 0 0 1 2.34.061l2.279.053.266 1.231c.129.448-.228.9-1.1 1.223a8.57 8.57 0 0 1-5.409-.137c-.875-.35-1.232-.821-1.065-1.276Z",
    opacity: 0.2
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3038",
    d: "M197.144 327.65a8.357 8.357 0 0 1 4.969.129c1.337.539 1.314 1.368-.046 1.839a8.357 8.357 0 0 1-4.969-.129c-1.38-.547-1.354-1.398.046-1.839Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3039",
    d: "M196.561 328.554s0 .091.152.182a2.332 2.332 0 0 0 .562.3 7.325 7.325 0 0 0 2.332.41 6.907 6.907 0 0 0 2.279-.289 1.977 1.977 0 0 0 .562-.281c.114-.084.144-.152.144-.167s-.114-.258-.684-.486a6.951 6.951 0 0 0-2.279-.41 7.3 7.3 0 0 0-2.348.289c-.568.201-.712.414-.72.452Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 219",
    opacity: 0.5
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3040",
    d: "M196.561 328.554s0 .091.152.182a2.332 2.332 0 0 0 .562.3 7.325 7.325 0 0 0 2.332.41 6.907 6.907 0 0 0 2.279-.289 1.977 1.977 0 0 0 .562-.281c.114-.084.144-.152.144-.167s-.114-.258-.684-.486a6.951 6.951 0 0 0-2.279-.41 7.3 7.3 0 0 0-2.348.289c-.568.201-.712.414-.72.452Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3041",
    d: "M196.713 328.737a2.333 2.333 0 0 0 .562.3 7.325 7.325 0 0 0 2.332.41 6.905 6.905 0 0 0 2.279-.289 1.977 1.977 0 0 0 .562-.281 2.158 2.158 0 0 0-.547-.3 6.951 6.951 0 0 0-2.279-.41 7.087 7.087 0 0 0-2.348.3 2.043 2.043 0 0 0-.562.273Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 220",
    opacity: 0.2
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3042",
    d: "M196.713 328.737a2.333 2.333 0 0 0 .562.3 7.325 7.325 0 0 0 2.332.41 6.905 6.905 0 0 0 2.279-.289 1.977 1.977 0 0 0 .562-.281 2.158 2.158 0 0 0-.547-.3 6.951 6.951 0 0 0-2.279-.41 7.087 7.087 0 0 0-2.348.3 2.043 2.043 0 0 0-.562.273Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 221",
    opacity: 0.5
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3043",
    d: "M198.11 328.807a.759.759 0 0 0-.555-.122c-.1.053 0 .2.182.319a.707.707 0 0 0 .547.122c.104-.062.024-.207-.174-.319Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3044",
    d: "M203.158 337.968c0 .365-.387.722-1.124.98a8.881 8.881 0 0 1-5.387-.137c-.76-.3-1.117-.669-1.109-1.033l-.144-3.571c0 .387.387.76 1.178 1.1a9.436 9.436 0 0 0 5.721.144c.76-.274 1.178-.653 1.193-1.033Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3045",
    d: "M200.641 338.089a4.105 4.105 0 0 0 .334-.593 1.853 1.853 0 0 1 .957-.8.122.122 0 0 1 .144.061 1.4 1.4 0 0 1-1.785 1.709.046.046 0 0 1 0-.068 1.132 1.132 0 0 0 .349-.312Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3046",
    d: "M201.712 336.584a1.955 1.955 0 0 0-.6.342 2.013 2.013 0 0 0-.441.57 1.748 1.748 0 0 1-.547.7.122.122 0 0 1-.16 0 1.223 1.223 0 0 1 .319-1.519 1.254 1.254 0 0 1 1.443-.289.114.114 0 0 1-.015.2Z",
    fill: "#37474f"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 222",
    opacity: 0.1
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3047",
    d: "m191.843 385.915-16.866 9.74a1.048 1.048 0 0 1-.95 0l-12.42-7.172a.289.289 0 0 1 0-.547l16.874-9.7a1.048 1.048 0 0 1 .95 0l12.414 7.172c.262.104.262.355-.002.507Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3048",
    d: "m191.843 385.193-16.866 9.755a1.049 1.049 0 0 1-.95 0l-12.42-7.164a.289.289 0 0 1 0-.547l16.874-9.763a1.048 1.048 0 0 1 .95 0l12.414 7.172c.262.152.262.425-.002.547Z",
    fill: "#ebebeb"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3049",
    d: "m179.429 377.474 11.791 6.838-16.243 9.383a1.049 1.049 0 0 1-.95 0l-11.791-6.838 16.243-9.383a1.048 1.048 0 0 1 .95 0Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3050",
    d: "m191.843 383.476-16.866 9.747a1.094 1.094 0 0 1-.95 0l-12.42-7.172a.289.289 0 0 1 0-.547l16.874-9.74a1.049 1.049 0 0 1 .95 0l12.414 7.164c.262.153.262.396-.002.548Z",
    fill: "#fafafa"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 223",
    opacity: 0.1
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3051",
    d: "M176.214 364.407c2.1.889 2.12 2.363 0 3.29a10.811 10.811 0 0 1-7.6.068c-2.1-.889-2.112-2.363 0-3.29a10.872 10.872 0 0 1 7.6-.068Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3052",
    d: "M177.134 364.467a2.606 2.606 0 0 0 1.413-.16c.57-.251.919-.934 1.322-2.036.342-.935.9-3.594.5-4.262-.6-1.026-1.884-.874-2.94-.843h-.365v1.292h.4c.593 0 1.588-.038 1.747.289.251.638-.486 4.049-1.01 4.414a2.6 2.6 0 0 1-1.519 0l-.456 1.124a3.994 3.994 0 0 0 .908.182Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 224",
    opacity: 0.15
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3053",
    d: "M177.134 364.468a2.606 2.606 0 0 0 1.413-.16c.57-.251.919-.934 1.322-2.036.342-.935.9-3.594.5-4.262-.6-1.026-1.884-.874-2.94-.843h-.365v1.292h.4c.593 0 1.588-.038 1.747.289.251.638-.486 4.049-1.01 4.414a2.6 2.6 0 0 1-1.519 0l-.456 1.124a3.994 3.994 0 0 0 .908.182Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3054",
    d: "M177.772 355.442c-.129-.517-.646-1.01-1.557-1.4a10.872 10.872 0 0 0-7.6.068c-.9.4-1.413.912-1.519 1.421-.327 3.4.311 7.309 1.519 9.474v.076a2.622 2.622 0 0 0 1 .919 6.367 6.367 0 0 0 5.751-.046 2.606 2.606 0 0 0 .98-.942v-.053c1.185-2.18 1.755-6.078 1.368-9.489Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 225",
    opacity: 0.4
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3055",
    d: "M176.214 354.029c2.1.9 2.12 2.37 0 3.3a10.9 10.9 0 0 1-7.6.068c-2.1-.889-2.112-2.363 0-3.3a10.872 10.872 0 0 1 7.6-.068Z",
    fill: "#fff"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3056",
    d: "M175.493 354.606c1.694.585 1.7 1.519 0 2.158a10.743 10.743 0 0 1-6.078.053c-1.694-.577-1.7-1.52 0-2.15a10.674 10.674 0 0 1 6.078-.061Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 226",
    opacity: 0.1
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3057",
    d: "M175.493 354.606c1.694.585 1.7 1.519 0 2.158a10.743 10.743 0 0 1-6.078.053c-1.694-.577-1.7-1.52 0-2.15a10.674 10.674 0 0 1 6.078-.061Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3058",
    d: "M175.5 355.913a3.04 3.04 0 0 1 .851.418 3.441 3.441 0 0 1-.843.433 10.742 10.742 0 0 1-6.078.053 3.038 3.038 0 0 1-.851-.418 3.1 3.1 0 0 1 .843-.433 10.675 10.675 0 0 1 6.078-.053Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "Group 227",
    opacity: 0.2
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3059",
    d: "M86.261 347.845a.114.114 0 0 0 .061.16l15.294 8.836a.387.387 0 0 0 .19.038.3.3 0 0 0 .19-.038l21.349-12.331a.122.122 0 0 0 .068-.068.091.091 0 0 0 0-.106l-15.338-8.852a.38.38 0 0 0-.38 0l-21.372 12.361a.091.091 0 0 0-.053 0Z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3060",
    d: "M122.622 343.446v.365a.4.4 0 0 1-.182.319l-20.445 11.822a.388.388 0 0 1-.365 0l-14.678-8.471a.4.4 0 0 1-.182-.312v-.372a.4.4 0 0 1 .182-.312l20.513-11.829a.388.388 0 0 1 .365 0l14.671 8.471a.387.387 0 0 1 .122.319Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3061",
    d: "M86.899 346.5a.11.11 0 0 0 0 .19l14.678 8.471a.335.335 0 0 0 .175.046v.76a.342.342 0 0 1-.182-.046l-14.678-8.471a.4.4 0 0 1-.182-.312v-.368a.387.387 0 0 1 .19-.266Z",
    fill: "#fff",
    opacity: 0.4
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3062",
    d: "M122.509 343.15a.4.4 0 0 1 .091.2v.41a.433.433 0 0 1-.182.319l-20.513 11.822a.38.38 0 0 1-.182.046v-.76a.387.387 0 0 0 .19-.046l20.513-11.822a.213.213 0 0 0 .068-.076.122.122 0 0 0 0-.1Z",
    opacity: 0.15
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3063",
    d: "M117.076 337.968c0-.137-.076-.273-.3-.4a1.383 1.383 0 0 0-.653-.175h-.061a11.212 11.212 0 0 0-1.671.342 3.86 3.86 0 0 1-1.436-.16h-.41a4.426 4.426 0 0 1-.927 0h-.615a.653.653 0 0 0-.41.084l-.821.471v.273l6.146 3.548.821-.471a.243.243 0 0 0 .137-.251v-.266a1.064 1.064 0 0 0-.068-.349 1.512 1.512 0 0 1-.046-.205 1.047 1.047 0 0 0 0-.2v-.273a.524.524 0 0 0 0-.1c-.046-.137-.236-.281-.3-.494v-.068c.129-.3.593-.646.585-.972a1.636 1.636 0 0 0 .029-.334Zm-1.261.76a1.574 1.574 0 0 1-.441.175 1.208 1.208 0 0 1-.836-.068.4.4 0 0 1-.152-.144.851.851 0 0 1 .334-.319 1.52 1.52 0 0 1 1.124-.167l.152.061a.4.4 0 0 1 .152.144.76.76 0 0 1-.334.319Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3064",
    d: "m110.581 337.558-.821.471 6.146 3.548.821-.471c.106-.061.213-.144.068-.593a1.277 1.277 0 0 1 0-.76c0-.19-.456-.418-.274-.836s1.033-.942.289-1.375a1.383 1.383 0 0 0-.653-.175h-.061a11.207 11.207 0 0 0-1.671.342 3.861 3.861 0 0 1-1.436-.16h-.41a4.428 4.428 0 0 1-.927 0h-.612a.653.653 0 0 0-.456.008Zm5.067 3.176a.4.4 0 0 1 .342 0c.076.046.053.129-.053.19a.357.357 0 0 1-.334 0c-.084-.038-.061-.129.068-.19Zm-.927-2.651a1.519 1.519 0 0 1 1.124-.167l.152.061c.3.175.22.509-.182.76a1.574 1.574 0 0 1-.441.175 1.208 1.208 0 0 1-.836-.068c-.303-.2-.22-.526.183-.762Zm-3.8-.084a.38.38 0 0 1 .334 0c.084.046.061.137-.046.2a.4.4 0 0 1-.342 0c-.091-.053-.068-.137.038-.228Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3065",
    d: "m102.345 353.877-12.764-7.37a.251.251 0 0 1-.114-.19v-.144a.251.251 0 0 1 .114-.19l16.866-9.74a.281.281 0 0 1 .22 0l12.8 7.377a.243.243 0 0 1 .106.182v.144a.258.258 0 0 1-.106.19l-16.874 9.74a.228.228 0 0 1-.251 0Z",
    fill: "#f5f5f5"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3066",
    d: "M89.55 346.006v.106l12.764 7.37a.19.19 0 0 0 .114 0v.441a.28.28 0 0 1-.114 0l-12.764-7.369a.228.228 0 0 1-.106-.19v-.144a.273.273 0 0 1 .106-.213Z",
    fill: "#fafafa"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3067",
    d: "M119.472 343.636a.152.152 0 0 1 0 .061v.167a.266.266 0 0 1-.106.19l-16.874 9.74a.244.244 0 0 1-.106 0v-.4a.244.244 0 0 0 .106 0l16.98-9.656Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3068",
    d: "m105.369 338.492-.152.084a.091.091 0 0 0 0 .167l10.249 5.918a.3.3 0 0 0 .3 0l.144-.084c.084-.046.084-.122 0-.167l-10.249-5.918a.319.319 0 0 0-.289 0Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3069",
    d: "m104.472 339.009-.144.084c-.084.046-.084.122 0 .167l10.249 5.918a.281.281 0 0 0 .289 0l.152-.084a.091.091 0 0 0 0-.167l-10.257-5.918a.319.319 0 0 0-.289 0Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3070",
    d: "m103.583 339.525-.152.084a.091.091 0 0 0 0 .167l10.249 5.918a.342.342 0 0 0 .3 0l.144-.084c.084-.046.084-.122 0-.167l-10.249-5.918a.319.319 0 0 0-.292 0Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3071",
    d: "m101.608 340.665-.144.084c-.084.046-.084.122 0 .167l10.249 5.918a.319.319 0 0 0 .289 0l.152-.084a.091.091 0 0 0 0-.167l-10.257-5.918a.319.319 0 0 0-.289 0Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3072",
    d: "m100.712 341.181-.144.084c-.084.046-.084.122 0 .167l10.249 5.918a.319.319 0 0 0 .289 0l.152-.084a.091.091 0 0 0 0-.167l-10.249-5.918a.342.342 0 0 0-.297 0Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3073",
    d: "m99.823 341.691-.152.091a.091.091 0 0 0 0 .167l10.257 5.918a.319.319 0 0 0 .289 0l.144-.083c.084-.053.084-.129 0-.175l-10.249-5.918a.319.319 0 0 0-.289 0Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3074",
    d: "m97.847 342.83-.144.091c-.084.046-.084.122 0 .167l10.249 5.918a.319.319 0 0 0 .289 0l.152-.091a.091.091 0 0 0 0-.167l-10.249-5.918a.342.342 0 0 0-.3 0Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3075",
    d: "m96.951 343.347-.144.091c-.084.046-.084.122 0 .167l10.249 5.918a.319.319 0 0 0 .289 0l.152-.084c.084-.053.084-.129 0-.175l-10.249-5.918a.342.342 0 0 0-.3 0Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3076",
    d: "m96.062 343.864-.144.084c-.084.053-.084.122 0 .175l10.249 5.918a.319.319 0 0 0 .289 0l.152-.091a.091.091 0 0 0 0-.167l-10.249-5.918a.334.334 0 0 0-.3 0Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3077",
    d: "m114.797 341.311-.912-.714a.546.546 0 0 1-.046-.076l.22-.205.707-.646a.175.175 0 0 0 .068-.137v-.271a.281.281 0 0 0-.084-.182.76.76 0 0 1-.144-.349.616.616 0 0 1 .167-.327 1.007 1.007 0 0 0-.19-1.512 1.686 1.686 0 0 0-.7-.167 1.664 1.664 0 0 0-1.048.372 1.307 1.307 0 0 1-.676.258 2.194 2.194 0 0 1-.623 0 .518.518 0 0 0-.144 0 .38.38 0 0 0-.289.091l-.608.562-.228.205a.577.577 0 0 1-.517.068c-.334-.137-.494-.22-1.041-.463a1.2 1.2 0 0 0-.494-.106 1.641 1.641 0 0 0-.76.182v.273l7.521 4.346a.623.623 0 0 0 .144-.38v-.271a.76.76 0 0 0-.323-.551Zm-1.519-3.8a1 1 0 0 1 .98-.167.265.265 0 0 1 .106.046.5.5 0 0 1 .266.281.6.6 0 0 1-.144.205.859.859 0 0 1-.3.175 1.048 1.048 0 0 1-.76-.046.585.585 0 0 1-.266-.281.555.555 0 0 1 .091-.213Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3078",
    d: "m107.442 337.884 7.521 4.346c.205-.281.228-.57-.167-.919l-.912-.714s-.2-.22 0-.372l.22-.205.707-.646s.16-.114 0-.319a.76.76 0 0 1 0-.942.76.76 0 0 0-.19-1.246 1.687 1.687 0 0 0-.7-.167 1.664 1.664 0 0 0-1.048.372 1.307 1.307 0 0 1-.676.258 2.2 2.2 0 0 1-.623 0 .516.516 0 0 0-.144 0 .38.38 0 0 0-.289.091l-.608.562-.228.205a.577.577 0 0 1-.517.068c-.334-.137-.494-.22-1.041-.463a1.2 1.2 0 0 0-.494-.106 1.641 1.641 0 0 0-.813.2Zm6.785-.813a.266.266 0 0 1 .106.046.441.441 0 0 1 .122.76.859.859 0 0 1-.3.175 1.048 1.048 0 0 1-.76-.046.441.441 0 0 1-.114-.76 1 1 0 0 1 .945-.177Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--laptop--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3079",
    d: "M155.619 367.597a1.383 1.383 0 0 1-.653 1.086l-14.222 8.243a1.466 1.466 0 0 1-1.307 0l-25.071-14.435a1.231 1.231 0 0 1 0-2.173l14.225-8.242a1.421 1.421 0 0 1 1.307 0l25.071 14.435a1.383 1.383 0 0 1 .65 1.086Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3080",
    d: "m154.969 367.293-14.222 8.213a1.421 1.421 0 0 1-1.307 0l-25.071-14.435c-.357-.205-.357-.539 0-.76l14.222-8.236a1.421 1.421 0 0 1 1.307 0l25.071 14.436a.4.4 0 0 1 0 .783Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3081",
    d: "M140.082 375.665v1.413a1.3 1.3 0 0 0 .653-.152l14.23-8.22a1.383 1.383 0 0 0 .653-1.086 1.413 1.413 0 0 0-.585-1.041c.3.213.273.517-.068.714l-14.222 8.22a1.382 1.382 0 0 1-.661.152Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3082",
    d: "M156.234 366.564c.342-.2.319-.524.319-.942v-19.654a1.428 1.428 0 0 0-.615-1.162l-25.07-14.436a1.383 1.383 0 0 0-1.269 0c-.334.19-.319.524-.319.942v19.655a1.474 1.474 0 0 0 .653 1.132l25.071 14.435a1.436 1.436 0 0 0 1.23.03Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3083",
    d: "M129.255 331.29c0-.418.3-.585.653-.38l25.067 14.435a1.3 1.3 0 0 1 .463.486l.934-.539a1.3 1.3 0 0 0-.441-.486l-25.071-14.435a1.368 1.368 0 0 0-1.261 0c-.359.166-.344.501-.344.919Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3084",
    d: "M155.041 366.58a1.42 1.42 0 0 0 1.193 0c.334-.2.319-.524.319-.942v-19.67a1.291 1.291 0 0 0-.19-.646l-.934.539a1.314 1.314 0 0 1 .19.646v19.655c.002.387-.251.562-.578.418Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3085",
    d: "m154.618 346.127-24.16-13.941a.241.241 0 0 0-.387.228v17.155a.858.858 0 0 0 .387.676l24.16 13.949a.246.246 0 0 0 .4-.228v-17.155a.9.9 0 0 0-.4-.684Z",
    fill: "#fafafa"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3086",
    d: "m153.157 366.58-23.256-13.417a.76.76 0 0 0-.653 0l-.387.213a.2.2 0 0 0 0 .38l23.278 13.409a.707.707 0 0 0 .653 0l.38-.213a.2.2 0 0 0-.015-.372Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3087",
    d: "m151.333 367.659-23.256-13.425a.653.653 0 0 0-.6 0l-6.078 3.495c-.152.084-.129.243.053.342l23.233 13.409a.661.661 0 0 0 .593.038l6.078-3.48c.182-.121.159-.273-.023-.379Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3088",
    d: "m131.284 359.878.7-.4v-.061l-.76-.418a.106.106 0 0 0-.106 0l-.7.4v.061l.76.418a.091.091 0 0 0 .106 0Zm.859-1.466-.7.4v.061l.76.425a.114.114 0 0 0 .1 0l.7-.4v-.061l-.76-.418a.137.137 0 0 0-.1-.008Zm2.348 1.36-.691.4v.061l1.238.714a.114.114 0 0 0 .1 0l.7-.4v-.061l-1.231-.707a.106.106 0 0 0-.117-.007Zm-1.284-.76-.7.4v.061l.76.425a.129.129 0 0 0 .106 0l.691-.4v-.061l-.722-.418a.106.106 0 0 0-.137.008Zm2.857 1.649-.7.4v.061l.76.425a.129.129 0 0 0 .106 0l.691-.4v-.061l-.76-.418a.129.129 0 0 0-.1.008Zm1.064.615-.7.4v.061l.76.425a.129.129 0 0 0 .106 0l.691-.4v-.06l-.76-.418a.106.106 0 0 0-.1.008Zm-2.522 1.649.7-.4v-.061l-.76-.418a.106.106 0 0 0-.106 0l-.691.4v.061l.76.425a.129.129 0 0 0 .1.015Zm1.064.615.7-.4v-.061l-.76-.418a.129.129 0 0 0-.106 0l-.691.4v.061l.76.425a.129.129 0 0 0 .1.008Zm1.064.615.7-.4v-.061l-.76-.418a.106.106 0 0 0-.106 0l-.691.4v.061l.76.425a.129.129 0 0 0 .1.008Zm1.064.615.7-.4v-.061l-.76-.418a.091.091 0 0 0-.1 0l-.7.4v.061l.76.418a.091.091 0 0 0 .1.015Zm-5.409-4.277.691-.4v-.061l-.76-.425a.129.129 0 0 0-.106 0l-.7.4v.061l.76.418a.106.106 0 0 0 .114.008Zm1.185 1.831.7-.4v-.061l-.669-.387c-.038 0-.038-.046 0-.061l.9-.517v-.061l-.843-.486a.129.129 0 0 0-.106 0l-1.687.973v.068l1.626.934a.106.106 0 0 0 .053 0Zm4.65-.418-.7.4v.061l.76.425a.129.129 0 0 0 .106 0l.691-.4v-.061l-.76-.418a.106.106 0 0 0-.129-.008Zm1.064.615-.7.4v.061l.76.418a.106.106 0 0 0 .106 0l.691-.4v-.061l-.76-.418a.106.106 0 0 0-.16 0Zm6.693 6.161v-.061l-.76-.418a.106.106 0 0 0-.106 0l-.7.4v.061l.76.425a.129.129 0 0 0 .106 0Zm1.823-1.246-.7.4v.061l.76.418a.091.091 0 0 0 .1 0l.7-.4v-.061l-.76-.418a.091.091 0 0 0-.129 0Zm-.547.836v-.061l-.76-.425a.129.129 0 0 0-.106 0l-.7.4v.061l.76.418a.106.106 0 0 0 .106 0Zm-3.533 1.064.7-.4v-.061l-.76-.418a.106.106 0 0 0-.106 0l-.691.4v.061l.76.425a.13.13 0 0 0 .068-.008Zm1.763.213v-.061l-.76-.418a.106.106 0 0 0-.106 0l-.691.4v.061l.722.425a.129.129 0 0 0 .106 0Zm1.246-2.727-.691.4v.061l.722.425a.129.129 0 0 0 .106 0l.7-.4v-.061l-.76-.418a.106.106 0 0 0-.106.008Zm-5.318-3.039-.7.4v.061l.76.418a.106.106 0 0 0 .106 0l.7-.4v-.06l-.76-.425a.129.129 0 0 0-.137-.023Zm4.255 2.454-.691.4v.065l.76.425a.129.129 0 0 0 .106 0l.7-.4v-.061l-.76-.418a.106.106 0 0 0-.144-.038Zm-5.318-3.039-.7.4v.061l.76.418a.106.106 0 0 0 .106 0l.7-.4v-.061l-.76-.425a.129.129 0 0 0-.137-.053Zm2.127 1.231-.7.4v.061l.76.418a.106.106 0 0 0 .106 0l.7-.4v-.061l-.76-.425a.129.129 0 0 0-.137-.061Zm1.064.615-.691.4v.061l.76.418a.129.129 0 0 0 .106 0l.7-.4v-.061l-.76-.418a.106.106 0 0 0-.144-.061Zm1.064.608-.691.4v.061l.76.425a.129.129 0 0 0 .106 0l.7-.4v-.061l-.76-.418a.129.129 0 0 0-.175-.068Zm-4.642.425.691-.4v-.061l-.76-.425a.129.129 0 0 0-.106 0l-.7.4v.061l.76.418a.106.106 0 0 0 .084-.053Zm-10.143-8.957-.7.4v.061l.76.418a.129.129 0 0 0 .106 0l.7-.4v-.061l-.76-.425a.129.129 0 0 0-.137-.053Zm1.284.76-.691.4v.061l.722.418h.106l.7-.4v-.057l-.76-.418a.129.129 0 0 0-.106-.076Zm-2.348-1.36-.7.4v.061l.76.418a.106.106 0 0 0 .106 0l.691-.4v-.061l-.76-.425a.129.129 0 0 0-.129-.068Zm6.078 5.47.7-.4v-.061l-.76-.418a.106.106 0 0 0-.106 0l-.7.4v.061l.76.425a.129.129 0 0 0 .091-.084Zm-7.871-5.789v.061l.76.418a.106.106 0 0 0 .106 0l.691-.4v-.061l-.76-.425a.129.129 0 0 0-.106 0Zm11.905 9.17.691-.4v-.061l-.76-.425a.129.129 0 0 0-.106 0l-.7.4v.061l.76.418a.106.106 0 0 0 .114.038Zm-13.052-7.537.691-.4v-.061l-.76-.418a.106.106 0 0 0-.106 0l-.7.4v.061l.76.425a.129.129 0 0 0 .114.023Zm2.059.038.691-.4v-.061l-.76-.418a.129.129 0 0 0-.106 0l-.7.4v.061l.76.425a.129.129 0 0 0 .114.023Zm-1.907-1.094v.061l.76.418a.129.129 0 0 0 .106 0l.691-.4v-.061l-.76-.418h-.106Zm.463-.593-.722-.425a.129.129 0 0 0-.106 0l-1.694.972v.061l.76.425a.129.129 0 0 0 .106 0l1.687-.972s.008-.046-.03-.046Zm2.363 1.417-.7.4v.061l.76.425a.129.129 0 0 0 .106 0l.7-.4v-.061l-.76-.418a.106.106 0 0 0-.106.023Zm8.008 4.68-.691.4v.061l.76.418a.106.106 0 0 0 .106 0l.7-.4v-.061l-.76-.418a.106.106 0 0 0-.123-.003Zm-9.231-4.179v-.061l-.76-.418a.106.106 0 0 0-.106 0l-.7.4v.061l.76.418a.106.106 0 0 0 .106 0Zm8.167 3.563-.7.4v.061l.76.418a.106.106 0 0 0 .106 0l.7-.4v-.061l-.76-.418a.106.106 0 0 0-.106-.023Zm9.117 6.427v-.061l-.76-.418a.129.129 0 0 0-.106 0l-.7.4v.061l.76.425a.129.129 0 0 0 .106 0Zm.433-.9-.7.4v.061l.76.418a.106.106 0 0 0 .106 0l.691-.4v-.061l-.76-.418a.106.106 0 0 0-.084-.023Zm-2.2.684.7-.4v-.061l-.76-.418a.106.106 0 0 0-.106 0l-.7.4v.061l.76.425a.129.129 0 0 0 .137-.023Zm-1.064-.615.691-.4v-.06l-.76-.418a.129.129 0 0 0-.106 0l-.7.4v.061l.76.418a.106.106 0 0 0 .144-.023Zm-1.064-.608.691-.4v-.061l-.76-.425a.129.129 0 0 0-.106 0l-.7.4v.061l.76.418a.129.129 0 0 0 .144-.015Zm3.259-.076-.7.4v.061l.76.418a.106.106 0 0 0 .106 0l.691-.4v-.061l-.76-.418a.107.107 0 0 0-.068-.023Zm-1.064-.615-.7.4v.061l.76.425a.129.129 0 0 0 .106 0l.691-.4v-.061l-.722-.418a.106.106 0 0 0-.106-.03Zm-4.262-2.454-.691.4v.061l.722.418a.129.129 0 0 0 .106 0l.7-.4v-.061l-.76-.425a.129.129 0 0 0-.046-.015Zm1.064.615-.691.4v.061l.722.418h.106l.7-.4v-.068l-.76-.418a.129.129 0 0 0-.053-.023Zm-2.127-1.231-.691.4v.061l.76.418a.106.106 0 0 0 .106 0l.7-.4v-.061l-.76-.425a.129.129 0 0 0-.084-.015Zm4.262 2.454-.7.4v.061l.76.425a.129.129 0 0 0 .106 0l.691-.4v-.061l-.691-.456a.137.137 0 0 0-.137 0Zm-1.064-.608-.7.4v.068l.76.418a.114.114 0 0 0 .1 0l.7-.4v-.061l-.76-.418s-.046-.046-.068-.023Zm1.565 4 .7-.4v-.061l-.76-.418a.129.129 0 0 0-.106 0l-.691.4v.061l.76.425a.129.129 0 0 0 .129-.03Zm5.516-.205.76.418a.106.106 0 0 0 .106 0l.691-.4v-.061l-.76-.425a.129.129 0 0 0-.106 0l-.7.4a.076.076 0 0 0 .038.046Zm-1.39.349 1.124.646a.129.129 0 0 0 .106 0l.691-.4v-.061l-1.117-.646a.129.129 0 0 0-.106 0l-.7.4s0 .015.03.038Zm2.431-1.147.9.517a.106.106 0 0 0 .106 0l.691-.4v-.061l-.9-.517a.129.129 0 0 0-.106 0l-.691.4a.047.047 0 0 0 .03.038Zm0-.858v-.061l-.76-.418a.106.106 0 0 0-.106 0l-.691.4v.061l.76.425a.129.129 0 0 0 .106 0Zm-3.708 2.416 1.406.813a.129.129 0 0 0 .106 0l.691-.4v-.061l-1.4-.805a.106.106 0 0 0-.106 0l-.7.4.03.03Zm-.486.866.9.517a.106.106 0 0 0 .106 0l.691-.4v-.061l-.9-.517a.091.091 0 0 0-.1 0l-.7.4a.047.047 0 0 0 .03.038Zm-3.685-7.886v-.061l-.76-.418a.106.106 0 0 0-.106 0l-.7.4v.061l.76.418a.106.106 0 0 0 .106 0Zm2.127 1.231v-.061l-.76-.425a.129.129 0 0 0-.106 0l-.7.4v.061l.76.418a.129.129 0 0 0 .106 0Zm4.718 2.72v-.061l-.76-.418a.129.129 0 0 0-.106 0l-.691.4v.061l.76.425a.129.129 0 0 0 .106 0Zm-5.782-3.335v-.061l-.76-.425a.129.129 0 0 0-.106 0l-.7.4v.061l.76.418a.106.106 0 0 0 .106 0Zm2.127 1.223v-.061l-.76-.418a.129.129 0 0 0-.106 0l-.691.4v.061l.76.418a.106.106 0 0 0 .106 0Zm-.707 6.4v.061l1.124.646a.129.129 0 0 0 .106 0l.691-.4v-.061l-1.117-.646a.129.129 0 0 0-.106 0Zm2.24-5.511v-.061l-.76-.425a.129.129 0 0 0-.106 0l-.691.4v.061l.76.418a.129.129 0 0 0 .106 0Zm1.064.608v-.061l-.76-.418a.129.129 0 0 0-.106 0l-.691.4v.061l.76.418a.129.129 0 0 0 .106 0Zm-23.028-6.473v.061l1.793 1.041a.129.129 0 0 0 .106 0l.7-.4v-.061l-1.793-1.033a.106.106 0 0 0-.106 0Zm2.355 1.36v.061l.76.418a.091.091 0 0 0 .1 0l.7-.4v-.061l-.76-.418a.091.091 0 0 0-.1 0Zm15.195 7.6.7-.4v-.061l-.76-.418a.106.106 0 0 0-.106 0l-.669.38v.061l.76.418a.129.129 0 0 0 .061.03Zm-13.037-6.374v.061l.76.418a.106.106 0 0 0 .106 0l.691-.4v-.061l-.76-.425a.129.129 0 0 0-.106 0Zm-5.546-3.206v.061l.76.425a.129.129 0 0 0 .106 0l.691-.4v-.061l-.76-.418a.129.129 0 0 0-.106 0Zm-1.056-.547.76.418a.129.129 0 0 0 .106 0l1.687-.972v-.061l-.722-.425a.129.129 0 0 0-.106 0l-1.694.98s-.076.046-.046.068Zm10.576 6.078v.061l.9.517a.106.106 0 0 0 .106 0l.7-.4v-.061l-.9-.517a.106.106 0 0 0-.106 0Zm-2.682-1.52v.061l1.124.646a.129.129 0 0 0 .106 0l.691-.4v-.061l-1.124-.646a.129.129 0 0 0-.106 0Zm5.151 2.971v.061l5.994 3.464a.114.114 0 0 0 .1 0l.7-.4v-.061l-5.994-3.457a.114.114 0 0 0-.1 0Zm6.329 3.654v.061l.9.517a.106.106 0 0 0 .106 0l.691-.4v-.061l-.9-.517a.129.129 0 0 0-.106 0Zm-7.559-4.361v.061l.912.463a.129.129 0 0 0 .106 0l.7-.4v-.061l-.9-.517a.129.129 0 0 0-.106 0Zm8.79 5.075v.061l.9.517a.129.129 0 0 0 .106 0l.7-.4v-.061l-.9-.517a.106.106 0 0 0-.106 0Zm-11.259-6.5v.061l.9.524a.129.129 0 0 0 .106 0l.7-.4v-.061l-.9-.517a.129.129 0 0 0-.106 0Zm-3.8-2.2v.061l.76.418a.106.106 0 0 0 .106 0l.691-.4v-.061l-.722-.425a.129.129 0 0 0-.106 0Zm-1.58-2.059.691-.4v-.061l-.76-.425a.129.129 0 0 0-.106 0l-.7.4v.061l.76.418a.129.129 0 0 0 .091-.046Zm4.338.205.7-.4v-.061l-.76-.418a.091.091 0 0 0-.1 0l-.7.4v.061l.722.425a.129.129 0 0 0 .114-.084Zm2.826 3.928.7-.4v-.061l-2.142-1.261a.106.106 0 0 0-.106 0l-.691.4v.061l2.135 1.231a.114.114 0 0 0 .084-.023Zm-5.425-4v-.061l-.76-.418a.129.129 0 0 0-.106 0l-.7.4v.061l.76.418a.129.129 0 0 0 .106 0Zm.3-.167.7-.4v-.061l-.76-.425a.129.129 0 0 0-.106 0l-.7.4v.061l.76.418a.106.106 0 0 0 .106.03Zm6.177 4.71.691-.4v-.061l-.76-.418a.137.137 0 0 0-.106 0l-.7.4v.061l.76.425a.129.129 0 0 0 .114.008Zm-4.129-3.182v-.061l-.76-.418a.106.106 0 0 0-.106 0l-.7.4v.061l.76.425a.114.114 0 0 0 .1 0Zm9.444 6.26.7-.4v-.061l-.76-.425a.129.129 0 0 0-.106 0l-.7.4v.061l.76.418a.129.129 0 0 0 .106.03Zm-1.064-.615.7-.4v-.061l-.76-.425a.129.129 0 0 0-.106 0l-.7.4v.061l.76.418a.106.106 0 0 0 .106.03Zm2.127 1.223.7-.4v-.061l-.76-.425a.129.129 0 0 0-.106 0l-.7.4v.061l.76.418a.106.106 0 0 0 .106.023Zm-4.255-2.454.691-.4v-.061l-.76-.418a.106.106 0 0 0-.106 0l-.646.425v.061l.76.425a.129.129 0 0 0 .061-.008Zm1.064.615.691-.4v-.061l-.76-.418a.106.106 0 0 0-.106 0l-.7.4v.061l.76.418a.106.106 0 0 0 .114.023Zm-2.127-1.231.691-.4v-.061l-.76-.418a.106.106 0 0 0-.106 0l-.7.4v.061l.76.425a.129.129 0 0 0 .114.015Zm-5.728-8.661v-.061l-.76-.418a.129.129 0 0 0-.106 0l-.182.106v.061l.722.418a.129.129 0 0 0 .106 0Zm5.8 3.039v-.061l-.722-.418h-.106l-.7.4v.061l.76.418a.129.129 0 0 0 .106 0Zm-2.127-1.223v-.061l-.76-.425a.129.129 0 0 0-.106 0l-.691.4v.061l.722.418a.137.137 0 0 0 .106 0Zm3.426 1.975v-.061l-.722-.418a.106.106 0 0 0-.106 0l-.7.4v.061l.76.425a.129.129 0 0 0 .106 0Zm-2.363-1.36v-.061l-.76-.425a.114.114 0 0 0-.1 0l-.7.4v.061l.76.418h.1Zm4.49 2.591v-.059l-.76-.418a.106.106 0 0 0-.106 0l-.7.4v.061l.76.418a.106.106 0 0 0 .106 0Zm-1.064-.615v-.061l-.76-.418a.106.106 0 0 0-.106 0l-.7.4v.061l.76.425a.129.129 0 0 0 .106 0Zm-6.032-3.191v-.061l-.76-.418a.106.106 0 0 0-.106 0l-.182.106v.061l.76.425a.114.114 0 0 0 .1 0Zm-3.191-1.839v-.061l-.76-.425a.129.129 0 0 0-.106 0l-.182.106v.061l.76.418a.106.106 0 0 0 .106 0Zm-.957.547v-.061l-.722-.418a.106.106 0 0 0-.106 0l-.7.4v.061l.76.418a.106.106 0 0 0 .106 0Zm-2.644 2.819.691-.4v-.061l-.76-.425a.129.129 0 0 0-.106 0l-.7.4v.061l.76.418a.106.106 0 0 0 .114.008Zm5.7-2.066v-.061l-.76-.418a.129.129 0 0 0-.106 0l-.182.114v.061l.76.418h.106Zm9.231 5.037v-.061l-.76-.425a.129.129 0 0 0-.106 0l-.7.4v.061l.76.418a.106.106 0 0 0 .106 0Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3089",
    d: "m135.896 367.305-.144.091-3.966 2.287-7.058-4.072-.144-.084 4.118-2.378Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3090",
    d: "m135.751 367.392-3.966 2.287-7.058-4.072 3.973-2.287Z",
    fill: "#263238"
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--character--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3091",
    d: "M276.653 327.84c3.472.16 5.432.615 7.195 3.183s7.035 14.633 7.825 16.213 1.519 3.708.372 5.6-10.568 13.956-10.568 13.956l-3.624-5.422 6.792-10.37-7.392-11.586Z",
    fill: "#b16668"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3092",
    d: "M276.166 327.84c1.231-.137 3.495-2 5.713-.4s3.214 4.634 4.558 7.514c.912 1.953 5.85 12.817 6.207 13.85a4.1 4.1 0 0 1-.349 4.171c-1.208 1.74-4.991 6.268-4.991 6.268a7.1 7.1 0 0 1-4.657-5.189l1.611-3.176-5.151-7.666Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3093",
    d: "m286.112 352.691-1.687-2.462s-1.709-3.8-1.269-6.9c.889-6.443.114-9.056-1.155-11.54l-5.007.4 2.112 11.031 5.151 7.658a9.626 9.626 0 0 0 1.855 1.813Z",
    opacity: 0.1
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3094",
    d: "M263.547 450.592s.562 1.519.889 2.849c.251 1.064.631 2.834.289 3.654s-1.785 1.39-4.049 1.459a13.293 13.293 0 0 0-5.242 2.059 14.258 14.258 0 0 1-6.64 1.307c-2.021-.16-4.156-1.246-4.513-2.066s-.669-1.953 4.718-3.905c.038 0 6.511-2.4 8.714-5.022Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3095",
    d: "m263.547 450.732-1.041-.084-4.794.273c-2.2 2.621-8.676 5.007-8.714 5.022l-.866.327c-.919.76-.068 2.066 2.2 2.18s9.17-2.507 10.7-3.312a4.627 4.627 0 0 0 2.522-4.407Z",
    fill: "#b16668"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3096",
    d: "M263.471 448.677s.046 1.314.076 2.059-.805 1.9-3.1 1.907c-1.611 0-2.75-.388-2.735-1.717l-.076-1.907Z",
    fill: "#b16668"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3097",
    d: "M282.396 442.72c.418.152.532.95.615 2.53.061 1.193.342 3.274-1.056 3.708s-3.449.243-4.361-.874a54.224 54.224 0 0 0-3.518-4.323c-1.406-1.474-2.917-2.849-3.5-4.931-.524-1.877-.114-2.7 1.17-3.267s2.469-.182 4.323 1.254a8.738 8.738 0 0 0 1.633.76c1.2.342 4.277 4.991 4.694 5.143Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3098",
    d: "m282.343 437.554.061 5.645s-1.2 2.583-4.9.182c-.084-.182-.456-5.721-.456-5.721Z",
    fill: "#b16668"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3099",
    d: "M277.701 437.6a8.737 8.737 0 0 1-1.633-.76c-1.466-.41-4.505.243-3.039 2.279a16.38 16.38 0 0 0 4.482 4.262c1.664.76 2.2-.273 2.2-.273l-.76-4.52a3.563 3.563 0 0 0-1.246-.988Z",
    fill: "#b16668"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3100",
    d: "M284.463 413.182a65.692 65.692 0 0 1-.912-9.565s.471-9.261.972-18.614c1.109-20.809-.486-20.042-6.215-30.671 0 0-17.907-5.858-20.916 1.968 0 0-.669 7.195-.843 12.232-.448 12.855-1.185 37.075-.8 41.6s.076 6.731.585 16.319c.433 8.046 1.048 22.792 1.048 22.792a6.251 6.251 0 0 0 6.344-.562s4.179-19.411 3.913-24.638c-.334-6.382-.16-11.692-.16-11.692s2.355-16.061 2.765-19.389c.122 8.053 1.861 16.418 3.161 24.243 1.52 9 3.578 21.82 3.578 21.82 3.3 1.74 5.531.805 5.531.805s2.906-20.358 1.949-26.648Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3101",
    d: "M284.463 413.182a65.692 65.692 0 0 1-.912-9.565s.471-9.261.972-18.614c1.109-20.809-.486-20.042-6.215-30.671 0 0-17.907-5.858-20.916 1.968 0 0-.669 7.195-.843 12.232-.448 12.855-1.185 37.075-.8 41.6s.076 6.731.585 16.319c.433 8.046 1.048 22.792 1.048 22.792a6.251 6.251 0 0 0 6.344-.562s4.179-19.411 3.913-24.638c-.334-6.382-.16-11.692-.16-11.692s2.355-16.061 2.765-19.389c.122 8.053 1.861 16.418 3.161 24.243 1.52 9 3.578 21.82 3.578 21.82 3.3 1.74 5.531.805 5.531.805s2.906-20.358 1.949-26.648Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3102",
    d: "M284.463 413.182a65.692 65.692 0 0 1-.912-9.565s.471-9.261.972-18.614c1.109-20.809-.486-20.042-6.215-30.671 0 0-17.907-5.858-20.916 1.968 0 0-.669 7.195-.843 12.232-.448 12.855-1.185 37.075-.8 41.6s.076 6.731.585 16.319c.433 8.046 1.048 22.792 1.048 22.792a6.251 6.251 0 0 0 6.344-.562s4.179-19.411 3.913-24.638c-.334-6.382-.16-11.692-.16-11.692s2.355-16.061 2.765-19.389c.122 8.053 1.861 16.418 3.161 24.243 1.52 9 3.578 21.82 3.578 21.82 3.3 1.74 5.531.805 5.531.805s2.906-20.358 1.949-26.648Z",
    opacity: 0.3
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3103",
    d: "m273.249 375.294-2.993 17.862a129.015 129.015 0 0 0 2.386 19.533 154.5 154.5 0 0 1-.95-19.123l3.3-16.714c4.118-.638 5.546-3.145 5.812-4.224-2.799 3.258-7.555 2.666-7.555 2.666Z",
    opacity: 0.2
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3104",
    d: "m266.335 323.061.471 10.788 8.053-.494-.258-11.221Z",
    fill: "#b16668"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3105",
    d: "M282.64 334.572c-.349-2.507-1.246-5.554-3.662-6.595a9.93 9.93 0 0 0-5.432-.319c-.342 1.147-4.505 2.614-6.564.638-2 .418-4.444.874-7.134 1.52-2.135.517-3.381 8.593-4.779 11.191-1.656 3.039-.046 7.233 2.051 8.843 0 0 .038 2.94.273 6.4 3.677 3.077 10.553 3.92 15.863 2.538 4-1.048 5.113-2.378 5.964-5.227a73.053 73.053 0 0 1 1.421-4.285c1.725-4.782 2.47-11.373 1.999-14.704Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3106",
    d: "M266.45 325.971c-.456 0-.76.19-1.3.9-.76.98-1.823 2.165-1.823 2.165s.942 1.732 3.928 2.325a13.037 13.037 0 0 0 7.066-.3c1.519-.631 1.778-1.14 1.975-1.823a4.778 4.778 0 0 0-.615-2.75c-.441-.957-1-.912-1-.912v.76s-.16.828-2.469 1.231-5.045 0-5.713-.638Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3107",
    d: "M255.107 305.299a4.346 4.346 0 0 1 0-1.368 4.118 4.118 0 0 1 5.44-3.138 4.049 4.049 0 0 1 2.279-4.422 5.136 5.136 0 0 1 3.966.16 3.1 3.1 0 0 1 1.732 1.519 4.353 4.353 0 0 1 7.932 1.071 3.488 3.488 0 0 1 3.753 1.6c.661 1.481-.152 3.32.152 4.878.2 1 .631 1.953.821 2.971a24.765 24.765 0 0 1 .319 3.442c.182 4.764-10.872 7.863-10.636 11.13l-5.9-7.172c0-.3-.836-1.041-1.026-1.3-.349-.471-.661-.98-.988-1.474a9.253 9.253 0 0 0-4.065-3.244 7.529 7.529 0 0 1-2.9-2.386 5.121 5.121 0 0 1-.881-2.264Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3108",
    d: "M259.748 313.223s-1.907 2.841-1.656 3.145a4.665 4.665 0 0 0 1.459.615Z",
    fill: "#9a4a4d"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3109",
    d: "M265.591 304.235c-1.861.942-5.067 2.682-5.9 9.406-.843 6.9.714 9.3 1.671 10.2.653.608 3.981.836 5.721.3 2.18-.669 6.891-2.955 9.117-6.519 2.6-4.186 3.138-9.778.137-11.966a11.415 11.415 0 0 0-10.746-1.421Z",
    fill: "#b16668"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3110",
    d: "M261.541 323.965a9.531 9.531 0 0 0 4.84.342l-.053-1.322a12.438 12.438 0 0 1-2.386.828 7.841 7.841 0 0 1-2.401.152Z",
    fill: "#9a4a4d"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3111",
    d: "M264.771 304.029a7.279 7.279 0 0 0-2.158 1.246 2.841 2.841 0 0 0-.76.98 2.279 2.279 0 0 0-.152 1.109 2.955 2.955 0 0 0 1.732 2.4 2.879 2.879 0 0 0-.463 2.4 5.729 5.729 0 0 0 1.7 2.454.349.349 0 0 0 .137.1.408.408 0 0 0 .311-.091c1.162-.76 1.884-2.127 3.533-1.588 2.165.714 2.059 3.381.357 5.045a3.647 3.647 0 0 1-2.279 1.071 1.762 1.762 0 0 1-1.193-.418 5.726 5.726 0 0 0 3.092 4.862 12 12 0 0 0 6.458.076c1.14-1.451 3.039-3.3 4.634-4.961 5.189-5.455 5.485-13.387-2.165-15.886a10.707 10.707 0 0 0-.8-.236 16.365 16.365 0 0 0-11.123 1.048Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3112",
    d: "M264.527 317.052a1.6 1.6 0 0 1-.98-2.059 1.649 1.649 0 0 1 2.089-.965Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3113",
    d: "M259.558 329.952c-3.882.486-6.952 1.3-8.646 4.992-2.864 6.275-5.972 11.4-8.228 13.835-2.416 2.583-12.3 7.134-14.534 6.769s-4.452-2.925-5.6-2.279.98 3.153.843 3.708-3.905 0-6.078-1.086-3.958 1.565-1.519 4.46 8.456 3 13.5 1.983 14.557-3.662 18.424-6.838c4.688-3.867 6.283-6.792 8.281-10.257 7.249-7.437 3.557-15.287 3.557-15.287Z",
    fill: "#b16668"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3114",
    d: "M260.174 329.747c-1.93-.334-5.858.22-7.362 1.953s-2.386 3.373-4.558 7.947-5.318 10.067-13.014 13.675c0 0 .707 4.824 3.32 6.557 0 0 5.523-1.132 8.775-3.48s7.841-7.909 9.747-10.887 5.363-5.759 3.092-15.765Z",
    fill: "#455a64"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    "data-name": "freepik--character--inject-3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3115",
    d: "m77.228 341.463-.8 8.851-9.854-1.877 1.026-9.147Z",
    fill: "#9e6767"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3116",
    d: "M83.283 330.317s2.142 3.259 1.9 3.578-1.823.608-1.823.608Z",
    fill: "#874c4c"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3117",
    d: "M77.319 321.314c4.346.912 5.6 2.826 6.01 9.725.425 7.2-.312 9.466-1.254 10.439-.646.653-4.194.76-5.987.281-2.279-.615-7.309-2.416-9.687-6.04-2.788-4.27-3.525-10.044-.532-12.422 4.217-3.335 9.687-2.355 11.45-1.983Z",
    fill: "#9e6767"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3118",
    d: "m77.228 340.749-.046 1.216c1.861.228 4.361.053 4.893-.486a9.915 9.915 0 0 1-1.839 0 11.048 11.048 0 0 1-3.009-.729Z",
    fill: "#874c4c"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3119",
    d: "M84.285 324.292a9.953 9.953 0 0 1-4.2 1.322 8.494 8.494 0 0 1-.691 3.419c-.266.76-1.231 3.176-2.188 1.823-.691-.98-1.322-1.869-2.689-1.664-2.279.334-2.568 3.214-1.14 4.969s2.75 1.079 2.75 1.079-.068 3.8-1.755 5.964a11.472 11.472 0 0 1-5.455-.137c-2.173-.456-5.242-3.176-6.534-6.078-2.727-6.078-2.917-11.548.965-13.182.418-2.8 2.621-4.057 5.136-4.634 3.487-.805 7.035 1.451 10.416.091.714-.281 1.375-.7 2.1-.942a1.428 1.428 0 0 1 1.246 0 1.519 1.519 0 0 1 .517.965 2.659 2.659 0 0 1-.182 2 6.033 6.033 0 0 1 1.588-.539 2 2 0 0 1 1.588.4 2.059 2.059 0 0 1 .608 1.4 4.293 4.293 0 0 1-2.08 3.744Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3120",
    d: "m63.248 322.773-2.6-1.52a1.519 1.519 0 0 1 2.6 1.52Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3121",
    d: "M95.583 411.207c0-.091-.524-5.463-.524-5.463s.38.547 3.487.273a17.011 17.011 0 0 0 3.457-.8l.205 3.9c.547 1.58 3.282 1.36 6.207 1.519h1.519c1.565.182 2.963 1.383 1.124 2.424s-4.558 1.094-7.111 1.117c-3.015.069-8.333.046-8.364-2.97Z",
    fill: "#9e6767"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3122",
    d: "M116.43 413.897a12.386 12.386 0 0 1-.129 1.428c-.106.577-1.93 2.454-4.627 3.214s-5.751.327-7.271.494-3.039.6-4.84.722a6.7 6.7 0 0 1-5.265-1.466c-.175-.418-.2-1.079-.076-1.17.355-.244 22.208-3.222 22.208-3.222Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3123",
    d: "M102.574 409.695c.972.95 3.335.805 5.842.95 2.363.137 5.113-.236 6.595.585s2.469 2.834-.068 4.847a14.752 14.752 0 0 1-3.085 1.519c-2.659 1.041-5.447.5-7.225.631-2.279.167-3.685.934-5.782.82-2.7-.144-4.262-1.109-4.6-1.9s.213-6.572 1.33-6.253c0 0 .16 1.93 4.8.874 2.024-.483 2.193-1.625 2.193-2.073Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3124",
    d: "M102.489 376.472c.22 5.379 0 30.39 0 30.39a8.175 8.175 0 0 1-7.469 1.337l-2.59-28.707Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3125",
    d: "M110.352 420.431c0-.091-.98-5.227-.98-5.227s.98.653 4.087.471a14.064 14.064 0 0 0 3.039-.57l.5 3.8c.494 1.6 3.236 1.466 6.161 1.717.486.046 1 .061 1.519.076h.106c1.557.228 2.917 1.466 1.048 2.454s-4.619.95-7.142.9c-3.02-.077-8.338-.613-8.338-3.621Z",
    fill: "#9e6767"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3126",
    d: "M131.63 424.054a2.864 2.864 0 0 1-.144 1.611c-.319.919-2.538 2.234-5.28 2.8s-5.751.114-7.271.243-3.183.691-4.961.76a7.187 7.187 0 0 1-4.885-1.656c-.236-.372-.3-1.086-.182-1.178.291-.232 22.723-2.58 22.723-2.58Z",
    fill: "#263238"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3127",
    d: "M117.41 419.473c.942.972 3.3.912 5.812 1.124 2.355.205 5.113-.076 6.572.76s3 2.773.4 4.71a15.619 15.619 0 0 1-3.8 1.671c-2.743.76-5.44.19-7.218.266-2.279.1-3.715.828-5.8.653-2.7-.228-4.232-1.246-4.558-2.044s.418-6.557 1.52-6.207c0 0 .106 1.93 4.779 1.018 2.073-.371 2.278-1.526 2.293-1.951Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3128",
    d: "M115.602 386.918c.623 5.569 1.216 21.7 1.633 29.751a11.13 11.13 0 0 1-8.046.9l-5.736-28.939Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3129",
    d: "M79.485 452.932a.676.676 0 0 0 .676-.676v-43.214a.676.676 0 0 0-1.345 0v43.214a.669.669 0 0 0 .669.676Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3130",
    d: "M52.749 437.198a.669.669 0 0 0 .623-.425l13.25-33.535a.67.67 0 1 0-1.246-.494l-13.25 33.535a.669.669 0 0 0 .372.874.761.761 0 0 0 .251.045Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3131",
    d: "M54.337 433.171a.669.669 0 0 0 .494-.213l24.654-26.09 24.616 25.983a.672.672 0 1 0 .972-.927l-25.071-26.5a.676.676 0 0 0-.486-.205.691.691 0 0 0-.486.205l-25.149 26.592a.676.676 0 0 0 .486 1.132Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3132",
    d: "M106.22 437.198a.761.761 0 0 0 .251-.046.676.676 0 0 0 .38-.874l-13.257-33.535a.67.67 0 1 0-1.246.494l13.25 33.535a.669.669 0 0 0 .622.426Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3133",
    d: "M106.554 394.189c.479-2.7-1.725-4.824-5.88-7.6a97.474 97.474 0 0 0-12.042-6.762c-3.472-1.6-7.028-1.451-11.48.836-6.184 3.176-24.783 14.435-24.783 14.435s27.807 15.727 33.155 15.043 18.75-9.421 19.791-12.483 1.239-3.469 1.239-3.469Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3134",
    d: "M82.842 406.823c3.989 3.616 8.16.5 14.769-3.8 7.469-4.834 8.941-8.834 8.941-8.834a16.267 16.267 0 0 1-.555 4.369c-.562 1.4-1.77 2.978-7.157 6.693s-9.292 5.577-12.916 6.26l-2.857-.4",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3135",
    d: "M97.612 403.04c7.468-4.851 8.938-8.851 8.938-8.851a16.267 16.267 0 0 1-.555 4.369c-.562 1.4-1.77 2.978-7.157 6.693s-9.292 5.577-12.916 6.26l-2.857-.4-.22-4.323c3.956 3.652 8.157.537 14.767-3.748Z",
    opacity: 0.5
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3136",
    d: "m53.661 432.176-1.747 4.558a.311.311 0 0 0 0 .122.152.152 0 0 0 0 .084.539.539 0 0 0 .258.289 1.162 1.162 0 0 0 1.071 0 .433.433 0 0 0 .205-.22v-.061l1.626-4.331Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3137",
    d: "m105.308 432.176 1.755 4.619a.593.593 0 0 1 0 .122v.084a.555.555 0 0 1-.266.289 1.147 1.147 0 0 1-1.064 0 .425.425 0 0 1-.213-.22v-.061l-1.625-4.333Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3138",
    d: "M78.709 448.891v3.8a.4.4 0 0 0 .228.319 1.208 1.208 0 0 0 1.094 0 .4.4 0 0 0 .228-.319v-3.8a1.649 1.649 0 0 0-1.55 0Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3139",
    d: "M61.091 383.476s22.314-6.739 26.188-7.8 11.32-2.849 13.5-1.877 3.274 2.1 3.472 5.242c.046.593 0 3.464 0 3.464s-11.3 4.6-20.133 4.6-23.027-3.629-23.027-3.629Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3140",
    d: "M61.008 380.681c-1.4 4.771-1.839 9.444 1.52 12.916 2.431 2.507 12.521 11.449 21.356 8.737 9.877-3.039 21.675-11.6 21.675-11.6s7.6.236 7.666-2.006c0-.547 2.408-1.223 2.386-1.823-.311-6.572-4.733-9.307-11.328-8.114-6.921 1.254-22.39 5.668-22.39 5.668Z",
    fill: "#455a64"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3141",
    d: "M72.054 400.571a1187.538 1187.538 0 0 1-3.654-13.782l9.117 2.879c1.884 5.956 2.834 9.193 7.544 8.426s20.513-7.385 20.513-7.385-11.8 8.577-21.675 11.6c-3.979 1.22-8.19.093-11.845-1.738Z",
    fill: "#37474f",
    opacity: 0.5
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3142",
    d: "M63.021 345.566c-3.039-.669-6.291 1.519-8.16 6.253s-6.329 16.433-7.088 19.579c-.342 1.413 11.275 14.139 10.887 13.956-.114-.061 3.411-6.146 3.411-6.146l-5.9-7.81 3.746-8.8Z",
    fill: "#9e6767"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3143",
    d: "M63.249 345.071c-3.966-1.109-6.686.2-8.464 4.482a172.9 172.9 0 0 0-5.66 16.524s7.985 4.931 13.242 3Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3144",
    d: "M58.006 349.038c1.261-2.887 2.781-4.042 5.972-3.973 1.071 0 2.948.243 2.948.243.38 1.519 6.564 2.955 9.877 1.223 1.208.312 4.376.935 5.379 1.269 2.879.957 3.32 4.247 3.8 13.637 0 0 0 19.943-.646 25.535-4.08 5.2-14.032 4.49-18.181 3.677-8.684-1.679-10.036-6.336-10.036-6.336s-.9-16.4-.8-23.21c.092-5.767.981-10.432 1.687-12.065Z",
    fill: "#f5f5f5"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3145",
    d: "M114.797 364.665c-1.4.661-18.279 14.055-20.9 12.688s-12.49-16.152-12.49-16.152a22.283 22.283 0 0 1 1.041-13.219c2.393.228 3.8.091 6.124 4.224 1.982 3.517 8.11 15.395 8.11 15.395q3.533-1.869 7.035-3.8c1.922-1.056 3.852-2.1 5.736-3.237a7.012 7.012 0 0 0 1.474-.957c.919-.95.707-3.191.661-4.414a14.376 14.376 0 0 0-.122-1.717c-.091-.691-.266-2.4 1-1.884a1.6 1.6 0 0 1 .615.486 2.742 2.742 0 0 1 .471.851c.251.76.19 1.519.425 2.279a.676.676 0 0 0 .16.289.539.539 0 0 0 .4.114c1.831-.1 3.51-2.7 4.315-4.08a3.746 3.746 0 0 1 1.375-1.633 2.471 2.471 0 0 1 2.872 1.033 5.812 5.812 0 0 1 1 4.019 8.023 8.023 0 0 1-2.279 5.113 24.541 24.541 0 0 1-7.023 4.602Z",
    fill: "#9e6767"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3146",
    d: "M83.063 411.146c-2.279-.114-4.057-1.778-9.459-4.034-9.983-4.156-17.474-7.483-20.323-12.718s-4.87-20.315-4.163-26.857a8.7 8.7 0 0 1 .494-2.165l-.707-.1 1.823-1.519c1.861-1.519 4.9-.167 7.187 1.079 6.534 3.556 11.647 7 15.689 19.487 3.039 9.383 5.037 17.945 9.238 22.526",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3147",
    d: "m49.612 365.372-.707-.1 1.823-1.519c1.861-1.519 4.9-.167 7.187 1.079 6.534 3.556 11.647 7 15.689 19.487 3.039 9.383 5.037 17.945 9.238 22.526l.22 4.323c-2.279-.114-4.057-1.778-9.459-4.034-9.983-4.156-17.474-7.483-20.323-12.718s-4.878-20.315-4.163-26.857a8.7 8.7 0 0 1 .494-2.188Z",
    opacity: 0.3
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3148",
    d: "M56.024 366.413c6.534 3.556 11.639 7.012 15.681 19.487s6.253 23.506 14.215 25.641c0 0-3.6 1.436-14.633-3.237a118.5 118.5 0 0 1-10.568-5.759c-5.485-3.077-8.805-5.6-9.33-6.541-2.9-5.2-4.855-20.323-4.163-26.887s5.523-4.481 8.798-2.704Z",
    fill: "#ffc0c0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3149",
    d: "M76.924 344.699c-4.034 1.307-8.745.365-9.74-1.717l.084-.76s-.448-.623-1.094.57-1.326 2.282-1.326 2.282-.38 2.462 3.3 3.928a10.56 10.56 0 0 0 8.783-.547 43.063 43.063 0 0 0 2.135-1.405l1.1.243s-1.368-2.1-2.013-3.039-1.1-.919-1.1-.919Z",
    fill: "#e0e0e0"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 3150",
    d: "M82.151 347.799c2.872.251 3.8 0 5.63 2.515s8.965 16.851 8.965 16.851l10.059-5.03 3.935 5.4s-11.4 8.661-13.782 9.922-3.176 1.314-5.227-.988-10.1-14.382-10.1-14.382-3.378-5.885.52-14.288Z",
    fill: "#e0e0e0"
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Line 49",
    fill: "none",
    stroke: "#6d6d6d",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    d: "M184.983 78.823V.5"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 791",
    d: "M192.285 90.233v-11.41h-14.6v11.474a21.834 21.834 0 0 0-13.24 20.392v.539h41.076v-.5a21.8 21.8 0 0 0-13.236-20.495Z",
    fill: "#37474f"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    "data-name": "Path 794",
    d: "M-2.97 0h37.843L61.9 81.091H-30Z",
    transform: "translate(169.197 111.324)",
    fill: "url(#why_utab_vector_svg__a)"
  })))));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgWhyUtabVector);

/***/ })

};
;